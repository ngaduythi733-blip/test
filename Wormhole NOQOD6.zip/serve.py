#!/usr/bin/env python3
"""Analog Canvas - local static server (Python standard library only).

Serves the built web editor from the ./web directory and falls back to
index.html for client-side routes such as /editor.

Usage:
    python serve.py [--port 8000] [--host 127.0.0.1] [--no-browser]

Then open http://localhost:8000/editor
"""

import argparse
import json
import mimetypes
import os
import posixpath
import sys
import threading
import webbrowser
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")

EXTRA_TYPES = {
    ".js": "text/javascript",
    ".mjs": "text/javascript",
    ".css": "text/css",
    ".json": "application/json",
    ".webmanifest": "application/manifest+json",
    ".wasm": "application/wasm",
    ".svg": "image/svg+xml",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".map": "application/json",
}
for _ext, _type in EXTRA_TYPES.items():
    mimetypes.add_type(_type, _ext)


class Handler(SimpleHTTPRequestHandler):
    server_version = "AnalogCanvasPython/1.0"

    def __init__(self, *args, directory=None, **kwargs):
        super().__init__(*args, directory=directory, **kwargs)

    def end_headers(self):
        path = self.path.split("?", 1)[0]
        if path.startswith("/assets/"):
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        elif path in ("/", "/index.html", "/sw.js", "/manifest.webmanifest"):
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def _send_404_json(self):
        body = json.dumps({"error": "not_found"}).encode("utf-8")
        self.send_response(404)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _safe_path(self):
        path = self.path.split("?", 1)[0].split("#", 1)[0]
        path = posixpath.normpath(path)
        parts = [p for p in path.split("/") if p not in ("", ".", "..")]
        return os.path.join(WEB_DIR, *parts) if parts else WEB_DIR

    def _serve(self, write_body=True):
        # Hosted-only backend endpoints: fail fast so the client falls back.
        if self.path.startswith("/api/"):
            self._send_404_json()
            return
        fs_path = self._safe_path()
        if os.path.isdir(fs_path):
            fs_path = os.path.join(fs_path, "index.html")
        if not os.path.isfile(fs_path):
            # SPA fallback: unknown extension-less routes render the app shell.
            if "." not in os.path.basename(fs_path):
                fs_path = os.path.join(WEB_DIR, "index.html")
            else:
                self._send_404_json()
                return
        try:
            with open(fs_path, "rb") as fh:
                body = fh.read()
        except OSError:
            self._send_404_json()
            return
        ctype, _ = mimetypes.guess_type(fs_path)
        self.send_response(200)
        self.send_header("Content-Type", ctype or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if write_body:
            self.wfile.write(body)

    def do_GET(self):
        self._serve(write_body=True)

    def do_HEAD(self):
        self._serve(write_body=False)

    def log_message(self, fmt, *args):
        sys.stdout.write("  %s - %s\n" % (self.address_string(), fmt % args))


def main():
    parser = argparse.ArgumentParser(description="Serve Analog Canvas locally with Python.")
    parser.add_argument("--port", type=int, default=8000, help="port to listen on (default 8000)")
    parser.add_argument("--host", default="127.0.0.1", help="interface to bind (default 127.0.0.1)")
    parser.add_argument("--no-browser", action="store_true", help="do not open a browser automatically")
    args = parser.parse_args()

    if not os.path.isfile(os.path.join(WEB_DIR, "index.html")):
        sys.stderr.write("ERROR: web/index.html not found next to serve.py\n")
        return 1

    handler = partial(Handler, directory=WEB_DIR)
    httpd = ThreadingHTTPServer((args.host, args.port), handler)
    url = "http://%s:%d/editor" % (args.host, args.port)
    print("Analog Canvas is served from: %s" % WEB_DIR)
    print("Open: %s" % url)
    print("Press Ctrl+C to stop.")
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
