import{n as e}from"./dist-weBOQ2AN.js";var t={documents:[{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:400,y:340},kind:`object`,localOffset:{x:10,y:10},objectId:`C1`},id:`instance-label-C1`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1.1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`C`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`GS`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`C1`}},{alignment:`middle`,anchor:{fallbackPosition:{x:480,y:220},kind:`object`,localOffset:{x:0,y:-20},objectId:`C1-copy-1`},id:`instance-label-C1-copy-1`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1.1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`C`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`GD`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`C1-copy-1`}},{alignment:`start`,anchor:{fallbackPosition:{x:540,y:300},kind:`object`,localOffset:{x:20,y:10},objectId:`M2`},binding:{instanceId:`M2`,kind:`instance-reference`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`M`}],kind:`span`,style:`bold`}],kind:`span`,style:`italic`},{children:[{children:[{kind:`text`,value:`1`}],kind:`span`,style:`bold`}],kind:`span`,style:`subscript`}]},id:`instance-label-M2`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1},{alignment:`end`,anchor:{fallbackPosition:{x:560,y:210},kind:`object`,localOffset:{x:30,y:10},objectId:`R3`},id:`instance-label-R3`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1.1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`R`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`D`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`R3`}},{alignment:`middle`,anchor:{fallbackPosition:{x:340,y:270},kind:`object`,localOffset:{x:0,y:-20},objectId:`R3-copy-5`},id:`instance-label-R3-copy-5`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1.1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`R`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`S`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`R3-copy-5`}},{alignment:`end`,anchor:{fallbackPosition:{x:280,y:340},kind:`object`,localOffset:{x:-10,y:10},objectId:`V6`},id:`instance-label-V6`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1.1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`in`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`V6`}},{alignment:`start`,anchor:{fallbackPosition:{x:550,y:160},kind:`object`,localOffset:{x:10,y:10},objectId:`junction-vdd7-end`},content:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`bold`}],kind:`span`,style:`italic`},{children:[{children:[{children:[{kind:`text`,value:`DD`}],kind:`span`,style:`italic`}],kind:`span`,style:`bold`}],kind:`span`,style:`subscript`}]},id:`label-VDD7`,kind:`power-label`,locked:!1,netId:`net-power-vdd7`,rotation:0,sizeScale:1.1},{alignment:`middle`,anchor:{direction:`forward`,fallbackPosition:{x:590,y:270},kind:`route`,legId:`route-leg-a5b59a07cb78c547`,normalOffset:-40,orientation:`follow`,routeId:`route-ui-25`,t:.6996025085449219},content:{runs:[{children:[{children:[{kind:`text`,value:`I`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`out `}],kind:`span`,style:`subscript`},{kind:`text`,value:`= 0`}],kind:`span`,style:`bold`}]},id:`current-4`,kind:`route-marker`,locked:!1,markerKind:`current`,rotation:0,sizeScale:1.1}],connectivityEvidence:[{id:`connectivity-evidence-1e6705e4ac6d8747`,kind:`name-claim`,name:`0`,netId:`net-global-0`,owner:{kind:`power-marker`,objectId:`GND5-copy-2`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-b6abc746278caab4`,kind:`name-claim`,name:`VDD`,netId:`net-power-vdd7`,owner:{kind:`power-marker`,objectId:`route-vdd7-rail-a-21`},powerDomain:`vdd`,scope:`global`},{id:`connectivity-evidence-4abcbfaaa1acf7fc`,kind:`name-claim`,name:`VDD`,netId:`net-power-vdd7`,owner:{kind:`power-marker`,objectId:`junction-vdd7-end`},powerDomain:`vdd`,scope:`global`}],constraints:[],drafting:{objects:[{alignment:`middle`,anchor:{kind:`free`,position:{x:480,y:310}},content:{runs:[{kind:`text`,value:`+`}]},id:`note-5`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},typographyToken:`label`,zIndex:0},{alignment:`middle`,anchor:{kind:`free`,position:{x:500,y:350}},content:{runs:[{kind:`text`,value:`_`}]},id:`note-6`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},typographyToken:`label`,zIndex:0},{alignment:`middle`,anchor:{kind:`free`,position:{x:490,y:340}},content:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`}],kind:`span`,style:`bold`},{children:[{children:[{kind:`text`,value:`1`}],kind:`span`,style:`bold`}],kind:`span`,style:`subscript`}]},id:`note-7`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1.2},typographyToken:`label`,zIndex:0}]},id:`document-main`,instances:[{id:`C1`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:390,y:330},rotation:0},reference:`CGS`,symbolId:`capacitor`},{id:`C1-copy-1`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:480,y:240},rotation:90},reference:`CGD`,symbolId:`capacitor`},{id:`M2`,mosBulkBinding:{netId:`net-global-0`,origin:`supply-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:520,y:290},rotation:0},reference:`M1`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`R3`,netlist:{binding:{deviceClass:`resistor`,kind:`primitive`},parameters:{}},placement:{mirror:`x`,position:{x:530,y:200},rotation:0},reference:`RD`,symbolId:`resistor`},{id:`GND5`,placement:{mirror:`none`,position:{x:590,y:290},rotation:0},symbolId:`ground`},{id:`GND5-copy-2`,placement:{mirror:`none`,position:{x:530,y:360},rotation:0},symbolId:`ground`},{id:`GND5-copy-2-copy-3`,placement:{mirror:`none`,position:{x:390,y:360},rotation:0},symbolId:`ground`},{id:`GND5-copy-2-copy-3-copy-4`,placement:{mirror:`none`,position:{x:290,y:360},rotation:0},symbolId:`ground`},{id:`R3-copy-5`,netlist:{binding:{deviceClass:`resistor`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:340,y:290},rotation:90},reference:`RS`,symbolId:`resistor`},{id:`V6`,netlist:{parameters:{}},placement:{mirror:`x`,position:{x:290,y:330},rotation:0},reference:`Vin`,symbolId:`voltage-source`}],junctions:[{id:`junction-ui-10`,netId:`net-split-1143160ec6fc8d88`,position:{x:390,y:290},role:`branch`},{id:`junction-ui-12`,netId:`net-split-1143160ec6fc8d88`,position:{x:430,y:290},role:`branch`},{id:`junction-ui-15`,netId:`net-split-315c27b4f6e1c409`,position:{x:530,y:240},role:`branch`},{id:`junction-vdd7-start`,netId:`net-power-vdd7`,position:{x:520,y:160},role:`route-anchor`},{id:`junction-vdd7-end`,netId:`net-power-vdd7`,position:{x:540,y:160},role:`route-anchor`},{id:`junction-ui-21`,netId:`net-power-vdd7`,position:{x:530,y:160},role:`branch`},{id:`junction-ui-26`,netId:`net-split-1143160ec6fc8d88`,position:{x:440,y:290},role:`branch`},{id:`junction-ui-29`,netId:`net-split-1143160ec6fc8d88`,position:{x:450,y:290},role:`branch`}],layoutGroups:[],name:`Main`,netlist:{formalParameters:[],name:`Main`,terminals:[]},nets:[{id:`net-global-0`,terminals:[{instanceId:`M2`,pinName:`B`},{instanceId:`GND5-copy-2`,pinName:`0`},{instanceId:`M2`,pinName:`S`}]},{id:`net-ui-4`,terminals:[{instanceId:`GND5-copy-2-copy-3-copy-4`,pinName:`0`},{instanceId:`V6`,pinName:`-`}]},{id:`net-ui-5`,terminals:[{instanceId:`V6`,pinName:`+`},{instanceId:`R3-copy-5`,pinName:`2`}]},{id:`net-ui-9`,terminals:[{instanceId:`C1`,pinName:`2`},{instanceId:`GND5-copy-2-copy-3`,pinName:`0`}]},{id:`net-split-315c27b4f6e1c409`,terminals:[{instanceId:`R3`,pinName:`2`},{instanceId:`C1-copy-1`,pinName:`1`},{instanceId:`M2`,pinName:`D`},{instanceId:`GND5`,pinName:`0`}]},{id:`net-power-vdd7`,terminals:[{instanceId:`R3`,pinName:`1`}]},{id:`net-split-1143160ec6fc8d88`,terminals:[{instanceId:`C1-copy-1`,pinName:`2`},{instanceId:`R3-copy-5`,pinName:`1`},{instanceId:`C1`,pinName:`1`},{instanceId:`M2`,pinName:`G`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:166,routes:[{id:`route-ui-5`,legs:[{id:`route-leg-b425448e843180bb`,mode:`manual`,to:{bendId:`route-bend-b425448e843180bb`,kind:`bend`,position:{x:290,y:290}}},{id:`route-leg-b425438e84317f08`,mode:`manual`,to:{endpoint:{instanceId:`R3-copy-5`,kind:`terminal`,pinName:`2`},kind:`endpoint`}}],netId:`net-ui-5`,start:{instanceId:`V6`,kind:`terminal`,pinName:`+`}},{id:`route-ui-8-a-10`,legs:[{id:`route-leg-938d19549064bc69`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-10`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{instanceId:`R3-copy-5`,kind:`terminal`,pinName:`1`}},{id:`route-ui-8-b-10`,legs:[{id:`route-leg-a5c54be8ef0ad91a`,mode:`manual`,to:{endpoint:{instanceId:`C1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{junctionId:`junction-ui-10`,kind:`junction`}},{id:`route-ui-11-a-12`,legs:[{id:`route-leg-35fa7da83873a292`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-12`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{junctionId:`junction-ui-10`,kind:`junction`}},{id:`route-ui-11-b-12-a-26`,legs:[{id:`route-leg-b5ad9fac2435a25e`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-26`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{junctionId:`junction-ui-12`,kind:`junction`}},{id:`route-ui-11-b-12-b-26-a-29`,legs:[{id:`route-leg-f3236c21b62696be`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-29`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{junctionId:`junction-ui-26`,kind:`junction`}},{id:`route-ui-11-b-12-b-26-b-29`,legs:[{id:`route-leg-d9cdd983f0a7c33d`,mode:`manual`,to:{endpoint:{instanceId:`M2`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{junctionId:`junction-ui-29`,kind:`junction`}},{id:`route-ui-19`,legs:[{id:`route-leg-140975b95ad30063`,mode:`manual`,to:{endpoint:{instanceId:`GND5-copy-2`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-global-0`,start:{instanceId:`M2`,kind:`terminal`,pinName:`S`}},{id:`route-vdd7-rail-a-21`,legs:[{id:`route-leg-5993f683ca4eed8c`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-21`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd7`,presentation:`power-rail`,start:{junctionId:`junction-vdd7-start`,kind:`junction`}},{id:`route-vdd7-rail-b-21`,legs:[{id:`route-leg-230c36b1a85c8fbf`,mode:`manual`,to:{endpoint:{junctionId:`junction-vdd7-end`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd7`,presentation:`power-rail`,start:{junctionId:`junction-ui-21`,kind:`junction`}},{id:`route-ui-22`,legs:[{id:`route-leg-5f6ad70b8c5bcedd`,mode:`manual`,to:{endpoint:{instanceId:`R3`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-power-vdd7`,start:{junctionId:`junction-ui-21`,kind:`junction`}},{id:`route-ui-23`,legs:[{id:`route-leg-5823016be2073ade`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-15`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-315c27b4f6e1c409`,start:{instanceId:`R3`,kind:`terminal`,pinName:`2`}},{id:`route-ui-24`,legs:[{id:`route-leg-92d7673fc0ab7623`,mode:`manual`,to:{endpoint:{instanceId:`M2`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-split-315c27b4f6e1c409`,start:{junctionId:`junction-ui-15`,kind:`junction`}},{id:`route-ui-25`,legs:[{id:`route-leg-a5b59907cb78c394`,mode:`manual`,to:{bendId:`route-bend-a5b59907cb78c394`,kind:`bend`,position:{x:590,y:240}}},{id:`route-leg-a5b59a07cb78c547`,mode:`manual`,to:{endpoint:{instanceId:`GND5`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-split-315c27b4f6e1c409`,start:{junctionId:`junction-ui-15`,kind:`junction`}},{id:`route-ui-30`,legs:[{id:`route-leg-c45e0a2ff0d6df32`,mode:`manual`,to:{bendId:`route-bend-c45e0a2ff0d6df32`,kind:`bend`,position:{x:450,y:240}}},{id:`route-leg-c45e0b2ff0d6e0e5`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-29`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-1143160ec6fc8d88`,start:{instanceId:`C1-copy-1`,kind:`terminal`,pinName:`2`}},{id:`route-ui-31`,legs:[{id:`route-leg-c651e825d0e80431`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-15`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-315c27b4f6e1c409`,start:{instanceId:`C1-copy-1`,kind:`terminal`,pinName:`1`}}],sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[],id:`project-main`,name:`New Circuit`,schemaVersion:48,simulationSetups:[],source:{dialect:`none`,entry:null,files:[],sourcePolicy:`copy`},structureRevision:0,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`document-main`},n={documents:[{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:550,y:170},kind:`object`,localOffset:{x:10,y:10},objectId:`junction-vdd1-end`},binding:{kind:`net-name`,netId:`net-power-vdd1`},id:`label-VDD1`,kind:`power-label`,locked:!1,netId:`net-power-vdd1`,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:510,y:210},kind:`object`,localOffset:{x:20,y:10},objectId:`M1`},binding:{instanceId:`M1`,kind:`instance-reference`},id:`instance-label-M1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:370,y:210},kind:`object`,localOffset:{x:-20,y:10},objectId:`M2`},binding:{instanceId:`M2`,kind:`instance-reference`},id:`instance-label-M2`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:390,y:310},kind:`object`,localOffset:{x:20,y:10},objectId:`M3`},binding:{instanceId:`M3`,kind:`instance-reference`},id:`instance-label-M3`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:490,y:310},kind:`object`,localOffset:{x:-20,y:10},objectId:`M4`},binding:{instanceId:`M4`,kind:`instance-reference`},id:`instance-label-M4`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:450,y:380},kind:`object`,localOffset:{x:20,y:10},objectId:`M5`},binding:{instanceId:`M5`,kind:`instance-reference`},id:`instance-label-M5`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:300,y:300},kind:`object`,localOffset:{x:-40,y:0},objectId:`P1`},binding:{kind:`net-name`,netId:`net-contact-p1`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`in1`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},id:`instance-label-P1`,kind:`net-label`,locked:!1,netId:`net-contact-p1`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{fallbackPosition:{x:560,y:300},kind:`object`,localOffset:{x:20,y:0},objectId:`P2`},binding:{kind:`net-name`,netId:`net-contact-p2`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`in2`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},id:`instance-label-P2`,kind:`net-label`,locked:!1,netId:`net-contact-p2`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{fallbackPosition:{x:550,y:250},kind:`object`,localOffset:{x:20,y:0},objectId:`P3`},binding:{kind:`net-name`,netId:`net-ui-8`},id:`instance-label-P3`,kind:`net-label`,locked:!1,netId:`net-ui-8`,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:360,y:370},kind:`object`,localOffset:{x:-40,y:0},objectId:`P4`},binding:{kind:`net-name`,netId:`net-contact-p4`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`b`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},id:`instance-label-P4`,kind:`net-label`,locked:!1,netId:`net-contact-p4`,rotation:0,sizeScale:1}],connectivityEvidence:[{id:`connectivity-evidence-25e634a2eea84516`,kind:`name-claim`,name:`VDD`,netId:`net-power-vdd1`,owner:{kind:`power-marker`,objectId:`route-vdd1-rail-a-1`},powerDomain:`vdd`,scope:`local`},{id:`connectivity-evidence-43d121a9b2699894`,kind:`net-name-hint`,netId:`net-ui-8`,origin:`legacy-explicit-net-property`,sourceName:`Vout`},{id:`connectivity-evidence-e49301de7c4e842c`,kind:`net-name-hint`,netId:`net-contact-p1`,origin:`legacy-explicit-net-property`,sourceName:`Vin1`},{id:`connectivity-evidence-3505353a1aed4e2e`,kind:`net-name-hint`,netId:`net-contact-p2`,origin:`legacy-explicit-net-property`,sourceName:`Vin2`},{id:`connectivity-evidence-0ee42d8cf01c7bbb`,kind:`net-name-hint`,netId:`net-contact-p4`,origin:`legacy-explicit-net-property`,sourceName:`Vb`},{id:`connectivity-evidence-5c878c49425c1514`,kind:`name-claim`,name:`0`,netId:`net-contact-gnd1`,owner:{kind:`power-marker`,objectId:`GND1`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-362a0827f36de02c`,kind:`name-claim`,name:`VDD`,netId:`net-power-vdd1`,owner:{kind:`power-marker`,objectId:`junction-vdd1-end`},powerDomain:`vdd`,scope:`local`},{id:`connectivity-evidence-6609436bdf68a3a6`,kind:`name-claim`,name:`Vin1`,netId:`net-contact-p1`,owner:{annotationId:`instance-label-P1`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-34bd0e453fcb04a8`,kind:`name-claim`,name:`Vin2`,netId:`net-contact-p2`,owner:{annotationId:`instance-label-P2`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-f799d25adc817336`,kind:`name-claim`,name:`Vout`,netId:`net-ui-8`,owner:{annotationId:`instance-label-P3`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-f33b12f0d8af9c38`,kind:`name-claim`,name:`Vb`,netId:`net-contact-p4`,owner:{annotationId:`instance-label-P4`,kind:`net-label`},scope:`local`}],constraints:[],drafting:{objects:[]},id:`document-main`,instances:[{id:`M1`,mosBulkBinding:{netId:`net-power-vdd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:490,y:200},rotation:0},reference:`M1`,symbolId:`pmos`,symbolVariantId:`textbook-3terminal`},{id:`M2`,mosBulkBinding:{netId:`net-power-vdd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`x`,position:{x:390,y:200},rotation:0},reference:`M2`,symbolId:`pmos`,symbolVariantId:`textbook-3terminal`},{id:`M3`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:370,y:300},rotation:0},reference:`M3`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`M4`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`x`,position:{x:510,y:300},rotation:0},reference:`M4`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`M5`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:430,y:370},rotation:0},reference:`M5`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`P1`,placement:{mirror:`none`,position:{x:340,y:300},rotation:0},symbolId:`port`},{id:`P2`,placement:{mirror:`x`,position:{x:540,y:300},rotation:0},symbolId:`port`},{id:`P3`,placement:{mirror:`x`,position:{x:530,y:250},rotation:0},symbolId:`port`},{id:`P4`,placement:{mirror:`none`,position:{x:400,y:370},rotation:0},symbolId:`port`},{id:`GND1`,placement:{mirror:`none`,position:{x:440,y:400},rotation:0},symbolId:`ground`}],junctions:[{id:`junction-vdd1-start`,netId:`net-power-vdd1`,position:{x:370,y:160},role:`route-anchor`},{id:`junction-vdd1-end`,netId:`net-power-vdd1`,position:{x:510,y:160},role:`route-anchor`},{id:`junction-ui-1`,netId:`net-power-vdd1`,position:{x:380,y:160},role:`branch`},{id:`junction-ui-3`,netId:`net-power-vdd1`,position:{x:500,y:160},role:`branch`},{id:`junction-ui-12`,netId:`net-ui-7`,position:{x:380,y:240},role:`branch`},{id:`junction-ui-13`,netId:`net-ui-7`,position:{x:430,y:200},role:`branch`},{id:`junction-ui-16`,netId:`net-ui-15`,position:{x:440,y:330},role:`branch`},{id:`junction-ui-18`,netId:`net-ui-8`,position:{x:500,y:250},role:`branch`}],layoutGroups:[],mosBulkDefaults:{nmosNetId:`net-contact-gnd1`,pmosNetId:`net-power-vdd1`},name:`Main`,netlist:{formalParameters:[],name:`Main`,terminals:[{direction:`passive`,id:`cell-terminal-p1`,interfaceInstanceIds:[`P1`],name:`Vin1`,netId:`net-contact-p1`},{direction:`passive`,id:`cell-terminal-p2`,interfaceInstanceIds:[`P2`],name:`Vin2`,netId:`net-contact-p2`},{direction:`passive`,id:`cell-terminal-p3`,interfaceInstanceIds:[`P3`],name:`Vout`,netId:`net-ui-8`},{direction:`passive`,id:`cell-terminal-p4`,interfaceInstanceIds:[`P4`],name:`Vb`,netId:`net-contact-p4`}]},nets:[{id:`net-power-vdd1`,terminals:[{instanceId:`M2`,pinName:`S`},{instanceId:`M1`,pinName:`S`},{instanceId:`M1`,pinName:`B`},{instanceId:`M2`,pinName:`B`}]},{id:`net-ui-7`,terminals:[{instanceId:`M2`,pinName:`D`},{instanceId:`M3`,pinName:`D`},{instanceId:`M2`,pinName:`G`},{instanceId:`M1`,pinName:`G`}]},{id:`net-ui-8`,terminals:[{instanceId:`M4`,pinName:`D`},{instanceId:`M1`,pinName:`D`},{instanceId:`P3`,pinName:`P`}]},{id:`net-ui-15`,terminals:[{instanceId:`M3`,pinName:`S`},{instanceId:`M4`,pinName:`S`},{instanceId:`M5`,pinName:`D`}]},{id:`net-contact-p1`,terminals:[{instanceId:`P1`,pinName:`P`},{instanceId:`M3`,pinName:`G`}]},{id:`net-contact-p2`,terminals:[{instanceId:`P2`,pinName:`P`},{instanceId:`M4`,pinName:`G`}]},{id:`net-contact-p4`,terminals:[{instanceId:`P4`,pinName:`P`},{instanceId:`M5`,pinName:`G`}]},{id:`net-contact-gnd1`,terminals:[{instanceId:`GND1`,pinName:`0`},{instanceId:`M5`,pinName:`S`},{instanceId:`M3`,pinName:`B`},{instanceId:`M4`,pinName:`B`},{instanceId:`M5`,pinName:`B`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:145,routes:[{id:`route-vdd1-rail-a-1`,legs:[{id:`route-leg-bb8907a29c131604`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-1`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-vdd1-start`,kind:`junction`}},{id:`route-vdd1-rail-b-1-a-3`,legs:[{id:`route-leg-cb1954139519f64a`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-3`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-ui-1`,kind:`junction`}},{id:`route-vdd1-rail-b-1-b-3`,legs:[{id:`route-leg-a175b9454f665393`,mode:`manual`,to:{endpoint:{junctionId:`junction-vdd1-end`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-ui-3`,kind:`junction`}},{id:`route-ui-2`,legs:[{id:`route-leg-77bdbebaa41b7a96`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-1`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,start:{instanceId:`M2`,kind:`terminal`,pinName:`S`}},{id:`route-ui-4`,legs:[{id:`route-leg-c70356568efe97cc`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-3`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,start:{instanceId:`M1`,kind:`terminal`,pinName:`S`}},{id:`route-ui-7-a-12`,legs:[{id:`route-leg-0f0c27d9d959b938`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-12`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-7`,start:{instanceId:`M2`,kind:`terminal`,pinName:`D`}},{id:`route-ui-7-b-12`,legs:[{id:`route-leg-63d59dc3b66eed47`,mode:`manual`,to:{endpoint:{instanceId:`M3`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-ui-7`,start:{junctionId:`junction-ui-12`,kind:`junction`}},{id:`route-ui-8-a-18`,legs:[{id:`route-leg-6cdaa192a72a40d1`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-18`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-8`,start:{instanceId:`M4`,kind:`terminal`,pinName:`D`}},{id:`route-ui-8-b-18`,legs:[{id:`route-leg-3eab54252e184982`,mode:`manual`,to:{endpoint:{instanceId:`M1`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-ui-8`,start:{junctionId:`junction-ui-18`,kind:`junction`}},{id:`route-ui-9-a-13`,legs:[{id:`route-leg-52ac1ab21d61b201`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-13`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-7`,start:{instanceId:`M2`,kind:`terminal`,pinName:`G`}},{id:`route-ui-9-b-13`,legs:[{id:`route-leg-71dda7fa809538de`,mode:`manual`,to:{endpoint:{instanceId:`M1`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-ui-7`,start:{junctionId:`junction-ui-13`,kind:`junction`}},{id:`route-ui-14`,legs:[{id:`route-leg-2c77578d26288638`,mode:`manual`,to:{bendId:`route-bend-2c77578d26288638`,kind:`bend`,position:{x:430,y:240}}},{id:`route-leg-2c77588d262887eb`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-13`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-7`,start:{junctionId:`junction-ui-12`,kind:`junction`}},{id:`route-ui-15-a-16`,legs:[{id:`route-leg-d688db042a43c802`,mode:`manual`,to:{bendId:`route-bend-d688db042a43c802`,kind:`bend`,position:{x:380,y:330}}},{id:`route-leg-d688dc042a43c9b5`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-16`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-15`,start:{instanceId:`M3`,kind:`terminal`,pinName:`S`}},{id:`route-ui-15-b-16`,legs:[{id:`route-leg-4c44278a57748e05`,mode:`manual`,to:{bendId:`route-bend-4c44278a57748e05`,kind:`bend`,position:{x:500,y:330}}},{id:`route-leg-4c44268a57748c52`,mode:`manual`,to:{endpoint:{instanceId:`M4`,kind:`terminal`,pinName:`S`},kind:`endpoint`}}],netId:`net-ui-15`,start:{junctionId:`junction-ui-16`,kind:`junction`}},{id:`route-ui-17`,legs:[{id:`route-leg-56b8e59fb979bb35`,mode:`manual`,to:{endpoint:{instanceId:`M5`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-ui-15`,start:{junctionId:`junction-ui-16`,kind:`junction`}},{id:`route-ui-19`,legs:[{id:`route-leg-140975b95ad30063`,mode:`manual`,to:{endpoint:{instanceId:`P3`,kind:`terminal`,pinName:`P`},kind:`endpoint`}}],netId:`net-ui-8`,start:{junctionId:`junction-ui-18`,kind:`junction`}},{id:`route-example-p1-lead`,netId:`net-contact-p1`,start:{kind:`terminal`,instanceId:`P1`,pinName:`P`},legs:[{id:`route-leg-2f8c1e18297b8300`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M3`,pinName:`G`}},mode:`manual`}]},{id:`route-example-p2-lead`,netId:`net-contact-p2`,start:{kind:`terminal`,instanceId:`P2`,pinName:`P`},legs:[{id:`route-leg-13465b00b3cbbf2b`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M4`,pinName:`G`}},mode:`manual`}]},{id:`route-example-p4-lead`,netId:`net-contact-p4`,start:{kind:`terminal`,instanceId:`P4`,pinName:`P`},legs:[{id:`route-leg-fe62a38a6dd97d01`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M5`,pinName:`G`}},mode:`manual`}]}],sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[],id:`project-main`,name:`New Circuit`,schemaVersion:48,simulationSetups:[],source:{dialect:`none`,entry:null,files:[],sourcePolicy:`copy`},structureRevision:0,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`document-main`},r={documents:[{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:590,y:180},kind:`object`,localOffset:{x:10,y:10},objectId:`junction-vdd1-end`},binding:{kind:`net-name`,netId:`net-power-vdd1`},id:`label-VDD1`,kind:`power-label`,locked:!1,netId:`net-power-vdd1`,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:260,y:220},kind:`object`,localOffset:{x:-20,y:10},objectId:`M1`},binding:{instanceId:`M1`,kind:`instance-reference`},id:`instance-label-M1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:350,y:210},kind:`object`,localOffset:{x:10,y:0},objectId:`M2`},binding:{instanceId:`M2`,kind:`instance-reference`},id:`instance-label-M2`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:470,y:210},kind:`object`,localOffset:{x:-20,y:0},objectId:`M3`},binding:{instanceId:`M3`,kind:`instance-reference`},id:`instance-label-M3`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:570,y:220},kind:`object`,localOffset:{x:20,y:10},objectId:`M4`},binding:{instanceId:`M4`,kind:`instance-reference`},id:`instance-label-M4`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:230,y:380},kind:`object`,localOffset:{x:-30,y:30},objectId:`M5`},binding:{instanceId:`M5`,kind:`instance-reference`},id:`instance-label-M5`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:310,y:380},kind:`object`,localOffset:{x:-30,y:30},objectId:`M6`},binding:{instanceId:`M6`,kind:`instance-reference`},id:`instance-label-M6`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:500,y:380},kind:`object`,localOffset:{x:10,y:30},objectId:`M7`},binding:{instanceId:`M7`,kind:`instance-reference`},id:`instance-label-M5-copy-1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:570,y:380},kind:`object`,localOffset:{x:0,y:30},objectId:`M8`},binding:{instanceId:`M8`,kind:`instance-reference`},id:`instance-label-M6-copy-1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:190,y:350},kind:`object`,localOffset:{x:-40,y:0},objectId:`P1`},binding:{kind:`net-name`,netId:`net-ui-34`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`bold`}],kind:`span`,style:`italic`},{children:[{children:[{kind:`text`,value:`in`}],kind:`span`,style:`bold`}],kind:`span`,style:`subscript`},{children:[{kind:`text`,value:`+`}],kind:`span`,style:`superscript`}]},id:`instance-label-P1`,kind:`net-label`,locked:!1,netId:`net-ui-34`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{fallbackPosition:{x:610,y:340},kind:`object`,localOffset:{x:10,y:-10},objectId:`P2`},binding:{kind:`net-name`,netId:`net-ui-35`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`in`}],kind:`span`,style:`subscript`},{children:[{kind:`text`,value:`-`}],kind:`span`,style:`superscript`}],kind:`span`,style:`bold`}]},id:`instance-label-P2`,kind:`net-label`,locked:!1,netId:`net-ui-35`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{fallbackPosition:{x:380,y:330},kind:`object`,localOffset:{x:0,y:-10},objectId:`C1`},binding:{instanceId:`C1`,kind:`instance-reference`},id:`instance-label-C1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:430,y:330},kind:`object`,localOffset:{x:-20,y:-10},objectId:`C2`},binding:{instanceId:`C2`,kind:`instance-reference`},id:`instance-label-C2`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:370,y:240},kind:`object`,localOffset:{x:0,y:-10},objectId:`P3`},binding:{kind:`net-name`,netId:`net-port-p3`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`out1`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},id:`instance-label-P3`,kind:`net-label`,locked:!1,netId:`net-port-p3`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{fallbackPosition:{x:430,y:240},kind:`object`,localOffset:{x:-30,y:-10},objectId:`P4`},binding:{kind:`net-name`,netId:`net-port-p4`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`out2`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},id:`instance-label-P4`,kind:`net-label`,locked:!1,netId:`net-port-p4`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{fallbackPosition:{x:430,y:440},kind:`object`,localOffset:{x:20,y:10},objectId:`I1`},id:`instance-label-I1`,kind:`instance-label`,locked:!1,rotation:0,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`I`}],kind:`span`,style:`bold`}],kind:`span`,style:`italic`},{children:[{children:[{kind:`text`,value:`SS1`}],kind:`span`,style:`bold`}],kind:`span`,style:`subscript`}]},binding:{kind:`instance-reference`,instanceId:`I1`}},{alignment:`start`,anchor:{fallbackPosition:{x:290,y:460},kind:`object`,localOffset:{x:20,y:10},objectId:`I2`},id:`instance-label-I2`,kind:`instance-label`,locked:!1,rotation:0,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`I`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`SS`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`},{children:[{children:[{kind:`text`,value:`2`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`I2`}}],connectivityEvidence:[{id:`connectivity-evidence-5c878c49425c1514`,kind:`name-claim`,name:`0`,netId:`net-contact-gnd1`,owner:{kind:`power-marker`,objectId:`GND3`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-25e634a2eea84516`,kind:`name-claim`,name:`VDD`,netId:`net-power-vdd1`,owner:{kind:`power-marker`,objectId:`route-vdd1-rail-a-20`},powerDomain:`vdd`,scope:`local`},{id:`connectivity-evidence-8a0159c1e72c6548`,kind:`net-name-hint`,netId:`net-ui-34`,origin:`legacy-explicit-net-property`,sourceName:`Vin+`},{id:`connectivity-evidence-a6dbb475386fd957`,kind:`net-name-hint`,netId:`net-ui-35`,origin:`legacy-explicit-net-property`,sourceName:`Vin-`},{id:`connectivity-evidence-5c4484a1dd737a3a`,kind:`net-name-hint`,netId:`net-port-p3`,origin:`legacy-explicit-net-property`,sourceName:`Vout1`},{id:`connectivity-evidence-4e3ad162be9bacee`,kind:`net-name-hint`,netId:`net-port-p4`,origin:`legacy-explicit-net-property`,sourceName:`Vout2`},{id:`connectivity-evidence-362a0827f36de02c`,kind:`name-claim`,name:`VDD`,netId:`net-power-vdd1`,owner:{kind:`power-marker`,objectId:`junction-vdd1-end`},powerDomain:`vdd`,scope:`local`},{id:`connectivity-evidence-e184ab56287ec08c`,kind:`name-claim`,name:`Vin+`,netId:`net-ui-34`,owner:{annotationId:`instance-label-P1`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-ebddb387d3b751e0`,kind:`name-claim`,name:`Vin-`,netId:`net-ui-35`,owner:{annotationId:`instance-label-P2`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-c18f883543023304`,kind:`name-claim`,name:`Vout1`,netId:`net-port-p3`,owner:{annotationId:`instance-label-P3`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-fb7c58dd2bee35ba`,kind:`name-claim`,name:`Vout2`,netId:`net-port-p4`,owner:{annotationId:`instance-label-P4`,kind:`net-label`},scope:`local`}],constraints:[],drafting:{objects:[]},id:`document-main`,instances:[{id:`M1`,mosBulkBinding:{netId:`net-power-vdd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`x`,position:{x:280,y:210},rotation:0},reference:`M1`,symbolId:`pmos`,symbolVariantId:`textbook-3terminal`},{id:`M2`,mosBulkBinding:{netId:`net-power-vdd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:340,y:210},rotation:0},reference:`M2`,symbolId:`pmos`,symbolVariantId:`textbook-3terminal`},{id:`M3`,mosBulkBinding:{netId:`net-power-vdd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`x`,position:{x:490,y:210},rotation:0},reference:`M3`,symbolId:`pmos`,symbolVariantId:`textbook-3terminal`},{id:`M4`,mosBulkBinding:{netId:`net-power-vdd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:550,y:210},rotation:0},reference:`M4`,symbolId:`pmos`,symbolVariantId:`textbook-3terminal`},{id:`M5`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:260,y:350},rotation:0},reference:`M5`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`M6`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`none`,position:{x:340,y:350},rotation:0},reference:`M6`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`M7`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`x`,position:{x:490,y:350},rotation:0},reference:`M7`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`M8`,mosBulkBinding:{netId:`net-contact-gnd1`,origin:`cell-default`},netlist:{parameters:{}},placement:{mirror:`x`,position:{x:570,y:350},rotation:0},reference:`M8`,symbolId:`nmos`,symbolVariantId:`textbook-3terminal`},{id:`P1`,placement:{mirror:`none`,position:{x:230,y:350},rotation:0},symbolId:`port`},{id:`P2`,placement:{mirror:`none`,position:{x:600,y:350},rotation:180},symbolId:`port`},{id:`C1`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:380,y:340},rotation:0},reference:`C1`,symbolId:`capacitor`},{id:`C2`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:450,y:340},rotation:0},reference:`C2`,symbolId:`capacitor`},{id:`GND3`,placement:{mirror:`none`,position:{x:380,y:370},rotation:0},symbolId:`ground`},{id:`GND4`,placement:{mirror:`none`,position:{x:450,y:370},rotation:0},symbolId:`ground`},{id:`P3`,placement:{mirror:`none`,position:{x:370,y:250},rotation:180},symbolId:`port`},{id:`P4`,placement:{mirror:`none`,position:{x:460,y:250},rotation:0},symbolId:`port`},{id:`I1`,netlist:{binding:{deviceClass:`current-source`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:410,y:430},rotation:0},reference:`ISS1`,symbolId:`current-source`},{id:`I2`,netlist:{binding:{deviceClass:`current-source`,kind:`primitive`},parameters:{}},placement:{mirror:`none`,position:{x:270,y:450},rotation:0},reference:`ISS2`,symbolId:`current-source`},{id:`GND1`,placement:{mirror:`none`,position:{x:270,y:480},rotation:0},symbolId:`ground`},{id:`GND2`,placement:{mirror:`none`,position:{x:410,y:460},rotation:0},symbolId:`ground`}],junctions:[{id:`junction-vdd1-start`,netId:`net-power-vdd1`,position:{x:250,y:170},role:`route-anchor`},{id:`junction-vdd1-end`,netId:`net-power-vdd1`,position:{x:580,y:170},role:`route-anchor`},{id:`junction-ui-20`,netId:`net-power-vdd1`,position:{x:270,y:170},role:`branch`},{id:`junction-ui-22`,netId:`net-power-vdd1`,position:{x:350,y:170},role:`branch`},{id:`junction-ui-24`,netId:`net-power-vdd1`,position:{x:480,y:170},role:`branch`},{id:`junction-ui-26`,netId:`net-power-vdd1`,position:{x:560,y:170},role:`branch`},{id:`junction-ui-36`,netId:`net-port-p3`,position:{x:350,y:320},role:`branch`},{id:`junction-ui-38`,netId:`net-port-p4`,position:{x:480,y:320},role:`branch`},{id:`junction-ui-40`,netId:`net-ui-28`,position:{x:310,y:210},role:`branch`},{id:`junction-ui-41`,netId:`net-ui-28`,position:{x:270,y:240},role:`branch`},{id:`junction-ui-43`,netId:`net-ui-29`,position:{x:520,y:210},role:`branch`},{id:`junction-ui-44`,netId:`net-ui-29`,position:{x:560,y:240},role:`branch`},{id:`junction-ui-50`,netId:`net-port-p3`,position:{x:350,y:250},role:`branch`},{id:`junction-ui-52`,netId:`net-port-p4`,position:{x:480,y:250},role:`branch`},{id:`junction-ui-58`,netId:`net-tail-1`,position:{x:410,y:390},role:`branch`},{id:`junction-ui-60`,netId:`net-tail-2`,position:{x:270,y:400},role:`branch`}],layoutGroups:[],mosBulkDefaults:{nmosNetId:`net-contact-gnd1`,pmosNetId:`net-power-vdd1`},name:`Main`,netlist:{formalParameters:[],name:`Main`,terminals:[{direction:`passive`,id:`cell-terminal-p1`,interfaceInstanceIds:[`P1`],name:`Vin+`,netId:`net-ui-34`},{direction:`passive`,id:`cell-terminal-p2`,interfaceInstanceIds:[`P2`],name:`Vin-`,netId:`net-ui-35`},{direction:`passive`,id:`cell-terminal-p3`,interfaceInstanceIds:[`P3`],name:`Vout1`,netId:`net-port-p3`},{direction:`passive`,id:`cell-terminal-p4`,interfaceInstanceIds:[`P4`],name:`Vout2`,netId:`net-port-p4`}]},nets:[{id:`net-contact-gnd1`,terminals:[{instanceId:`GND3`,pinName:`0`},{instanceId:`C1`,pinName:`2`},{instanceId:`GND4`,pinName:`0`},{instanceId:`C2`,pinName:`2`},{instanceId:`GND1`,pinName:`0`},{instanceId:`GND2`,pinName:`0`},{instanceId:`I1`,pinName:`-`},{instanceId:`I2`,pinName:`-`},{instanceId:`M5`,pinName:`B`},{instanceId:`M6`,pinName:`B`},{instanceId:`M7`,pinName:`B`},{instanceId:`M8`,pinName:`B`}]},{id:`net-tail-1`,terminals:[{instanceId:`M6`,pinName:`S`},{instanceId:`M7`,pinName:`S`},{instanceId:`I1`,pinName:`+`}]},{id:`net-tail-2`,terminals:[{instanceId:`M5`,pinName:`S`},{instanceId:`M8`,pinName:`S`},{instanceId:`I2`,pinName:`+`}]},{id:`net-power-vdd1`,terminals:[{instanceId:`M1`,pinName:`S`},{instanceId:`M2`,pinName:`S`},{instanceId:`M3`,pinName:`S`},{instanceId:`M4`,pinName:`S`},{instanceId:`M1`,pinName:`B`},{instanceId:`M2`,pinName:`B`},{instanceId:`M3`,pinName:`B`},{instanceId:`M4`,pinName:`B`}]},{id:`net-ui-28`,terminals:[{instanceId:`M1`,pinName:`G`},{instanceId:`M2`,pinName:`G`},{instanceId:`M1`,pinName:`D`},{instanceId:`M8`,pinName:`D`}]},{id:`net-ui-29`,terminals:[{instanceId:`M3`,pinName:`G`},{instanceId:`M4`,pinName:`G`},{instanceId:`M4`,pinName:`D`},{instanceId:`M5`,pinName:`D`}]},{id:`net-ui-34`,terminals:[{instanceId:`M6`,pinName:`G`},{instanceId:`M5`,pinName:`G`},{instanceId:`P1`,pinName:`P`}]},{id:`net-ui-35`,terminals:[{instanceId:`M7`,pinName:`G`},{instanceId:`M8`,pinName:`G`},{instanceId:`P2`,pinName:`P`}]},{id:`net-port-p3`,terminals:[{instanceId:`P3`,pinName:`P`},{instanceId:`M2`,pinName:`D`},{instanceId:`M6`,pinName:`D`},{instanceId:`C1`,pinName:`1`}]},{id:`net-port-p4`,terminals:[{instanceId:`P4`,pinName:`P`},{instanceId:`M3`,pinName:`D`},{instanceId:`M7`,pinName:`D`},{instanceId:`C2`,pinName:`1`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:302,routes:[{id:`route-vdd1-rail-a-20`,legs:[{id:`route-leg-f3c398b0ceaab9f9`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-20`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-vdd1-start`,kind:`junction`}},{id:`route-vdd1-rail-b-20-a-22`,legs:[{id:`route-leg-6c1e8f0365b2ab9a`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-22`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-ui-20`,kind:`junction`}},{id:`route-vdd1-rail-b-20-b-22-a-24`,legs:[{id:`route-leg-f3f95c75fb8e4210`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-24`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-ui-22`,kind:`junction`}},{id:`route-vdd1-rail-b-20-b-22-b-24-a-26`,legs:[{id:`route-leg-403364761c775491`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-26`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-ui-24`,kind:`junction`}},{id:`route-vdd1-rail-b-20-b-22-b-24-b-26`,legs:[{id:`route-leg-3da78e3eb77c81fe`,mode:`manual`,to:{endpoint:{junctionId:`junction-vdd1-end`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,presentation:`power-rail`,start:{junctionId:`junction-ui-26`,kind:`junction`}},{id:`route-ui-21`,legs:[{id:`route-leg-4b3248f996c36fe0`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-20`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,start:{instanceId:`M1`,kind:`terminal`,pinName:`S`}},{id:`route-ui-23`,legs:[{id:`route-leg-5823016be2073ade`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-22`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,start:{instanceId:`M2`,kind:`terminal`,pinName:`S`}},{id:`route-ui-25`,legs:[{id:`route-leg-a5b59907cb78c394`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-24`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,start:{instanceId:`M3`,kind:`terminal`,pinName:`S`}},{id:`route-ui-27`,legs:[{id:`route-leg-6306a9216cd2e242`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-26`,kind:`junction`},kind:`endpoint`}}],netId:`net-power-vdd1`,start:{instanceId:`M4`,kind:`terminal`,pinName:`S`}},{id:`route-ui-28-a-40`,legs:[{id:`route-leg-feb19dc68ffe4c65`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-40`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-28`,start:{instanceId:`M1`,kind:`terminal`,pinName:`G`}},{id:`route-ui-28-b-40`,legs:[{id:`route-leg-2a53f8e2af5455e6`,mode:`manual`,to:{endpoint:{instanceId:`M2`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-ui-28`,start:{junctionId:`junction-ui-40`,kind:`junction`}},{id:`route-ui-29-a-43`,legs:[{id:`route-leg-1a7e90c951cd174d`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-43`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-29`,start:{instanceId:`M3`,kind:`terminal`,pinName:`G`}},{id:`route-ui-29-b-43`,legs:[{id:`route-leg-76473a2f8a40a98a`,mode:`manual`,to:{endpoint:{instanceId:`M4`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-ui-29`,start:{junctionId:`junction-ui-43`,kind:`junction`}},{id:`route-ui-30-a-36-a-50`,legs:[{id:`route-leg-587e7e330a82ecc1`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-50`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p3`,start:{instanceId:`M2`,kind:`terminal`,pinName:`D`}},{id:`route-ui-30-a-36-b-50`,legs:[{id:`route-leg-43d6988db6bc6192`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-36`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p3`,start:{junctionId:`junction-ui-50`,kind:`junction`}},{id:`route-ui-30-b-36`,legs:[{id:`route-leg-8d0fbcff97052d14`,mode:`manual`,to:{endpoint:{instanceId:`M6`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-port-p3`,start:{junctionId:`junction-ui-36`,kind:`junction`}},{id:`route-ui-31-a-38-a-52`,legs:[{id:`route-leg-d9476b8aec0b374a`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-52`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p4`,start:{instanceId:`M3`,kind:`terminal`,pinName:`D`}},{id:`route-ui-31-a-38-b-52`,legs:[{id:`route-leg-5e5b2f2e95a5e945`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-38`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p4`,start:{junctionId:`junction-ui-52`,kind:`junction`}},{id:`route-ui-31-b-38`,legs:[{id:`route-leg-d2fb9c50611cf77b`,mode:`manual`,to:{endpoint:{instanceId:`M7`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-port-p4`,start:{junctionId:`junction-ui-38`,kind:`junction`}},{id:`route-ui-32-a-41`,legs:[{id:`route-leg-0fd7a60d651629b3`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-41`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-28`,start:{instanceId:`M1`,kind:`terminal`,pinName:`D`}},{id:`route-ui-32-b-41`,legs:[{id:`route-leg-f531986252801d60`,mode:`manual`,to:{bendId:`route-bend-f531986252801d60`,kind:`bend`,position:{x:270,y:270}}},{id:`route-leg-f531996252801f13`,mode:`manual`,to:{bendId:`route-bend-f531996252801f13`,kind:`bend`,position:{x:400,y:270}}},{id:`route-leg-f5319a62528020c6`,mode:`manual`,to:{bendId:`route-bend-f5319a62528020c6`,kind:`bend`,position:{x:430,y:300}}},{id:`route-leg-f5319b6252802279`,mode:`manual`,to:{bendId:`route-bend-f5319b6252802279`,kind:`bend`,position:{x:560,y:300}}},{id:`route-leg-f5319c625280242c`,mode:`manual`,to:{endpoint:{instanceId:`M8`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-ui-28`,start:{junctionId:`junction-ui-41`,kind:`junction`}},{id:`route-ui-33-a-44`,legs:[{id:`route-leg-2b750d442e5ef9e5`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-44`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-29`,start:{instanceId:`M4`,kind:`terminal`,pinName:`D`}},{id:`route-ui-33-b-44`,legs:[{id:`route-leg-91752233b7c36886`,mode:`manual`,to:{bendId:`route-bend-91752233b7c36886`,kind:`bend`,position:{x:560,y:270}}},{id:`route-leg-91752333b7c36a39`,mode:`manual`,to:{bendId:`route-bend-91752333b7c36a39`,kind:`bend`,position:{x:430,y:270}}},{id:`route-leg-91752033b7c36520`,mode:`manual`,to:{bendId:`route-bend-91752033b7c36520`,kind:`bend`,position:{x:400,y:300}}},{id:`route-leg-91752133b7c366d3`,mode:`manual`,to:{bendId:`route-bend-91752133b7c366d3`,kind:`bend`,position:{x:270,y:300}}},{id:`route-leg-91752633b7c36f52`,mode:`manual`,to:{endpoint:{instanceId:`M5`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-ui-29`,start:{junctionId:`junction-ui-44`,kind:`junction`}},{id:`route-ui-34`,legs:[{id:`route-leg-b7c7e27a649a7cce`,mode:`manual`,to:{endpoint:{instanceId:`M5`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-ui-34`,start:{instanceId:`M6`,kind:`terminal`,pinName:`G`}},{id:`route-ui-35`,legs:[{id:`route-leg-c0c2b81a1060a54d`,mode:`manual`,to:{endpoint:{instanceId:`M8`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-ui-35`,start:{instanceId:`M7`,kind:`terminal`,pinName:`G`}},{id:`route-ui-37`,legs:[{id:`route-leg-982f18400eb72a2f`,mode:`manual`,to:{endpoint:{instanceId:`C1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-port-p3`,start:{junctionId:`junction-ui-36`,kind:`junction`}},{id:`route-ui-39`,legs:[{id:`route-leg-41c1dfea2e21d549`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-38`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p4`,start:{instanceId:`C2`,kind:`terminal`,pinName:`1`}},{id:`route-ui-42`,legs:[{id:`route-leg-d0517dfc5916f74f`,mode:`manual`,to:{bendId:`route-bend-d0517dfc5916f74f`,kind:`bend`,position:{x:310,y:240}}},{id:`route-leg-d0517cfc5916f59c`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-41`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-28`,start:{junctionId:`junction-ui-40`,kind:`junction`}},{id:`route-ui-45`,legs:[{id:`route-leg-facd6fec39c517d2`,mode:`manual`,to:{bendId:`route-bend-facd6fec39c517d2`,kind:`bend`,position:{x:520,y:240}}},{id:`route-leg-facd70ec39c51985`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-44`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-29`,start:{junctionId:`junction-ui-43`,kind:`junction`}},{id:`route-ui-51`,legs:[{id:`route-leg-31a8df0add1af43f`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-50`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p3`,start:{instanceId:`P3`,kind:`terminal`,pinName:`P`}},{id:`route-ui-53`,legs:[{id:`route-leg-03cbfee26953855d`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-52`,kind:`junction`},kind:`endpoint`}}],netId:`net-port-p4`,start:{instanceId:`P4`,kind:`terminal`,pinName:`P`}},{id:`route-ui-56-a-60`,legs:[{id:`route-leg-3e66752f59f2bb40`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-60`,kind:`junction`},kind:`endpoint`}}],netId:`net-tail-2`,start:{instanceId:`M5`,kind:`terminal`,pinName:`S`}},{id:`route-ui-56-b-60`,legs:[{id:`route-leg-7a40d3d703aa71bb`,mode:`manual`,to:{endpoint:{instanceId:`I2`,kind:`terminal`,pinName:`+`},kind:`endpoint`}}],netId:`net-tail-2`,start:{junctionId:`junction-ui-60`,kind:`junction`}},{id:`route-ui-57-a-58`,legs:[{id:`route-leg-12170b18bde5aa26`,mode:`manual`,to:{bendId:`route-bend-12170b18bde5aa26`,kind:`bend`,position:{x:350,y:390}}},{id:`route-leg-12170c18bde5abd9`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-58`,kind:`junction`},kind:`endpoint`}}],netId:`net-tail-1`,start:{instanceId:`M6`,kind:`terminal`,pinName:`S`}},{id:`route-ui-57-b-58`,legs:[{id:`route-leg-5386df43f0845795`,mode:`manual`,to:{bendId:`route-bend-5386df43f0845795`,kind:`bend`,position:{x:480,y:390}}},{id:`route-leg-5386de43f08455e2`,mode:`manual`,to:{endpoint:{instanceId:`M7`,kind:`terminal`,pinName:`S`},kind:`endpoint`}}],netId:`net-tail-1`,start:{junctionId:`junction-ui-58`,kind:`junction`}},{id:`route-ui-59`,legs:[{id:`route-leg-970fd6ce9c9bef57`,mode:`manual`,to:{endpoint:{instanceId:`I1`,kind:`terminal`,pinName:`+`},kind:`endpoint`}}],netId:`net-tail-1`,start:{junctionId:`junction-ui-58`,kind:`junction`}},{id:`route-ui-61`,legs:[{id:`route-leg-ab6ea1ed2c755084`,mode:`manual`,to:{bendId:`route-bend-ab6ea1ed2c755084`,kind:`bend`,position:{x:560,y:400}}},{id:`route-leg-ab6ea2ed2c755237`,mode:`manual`,to:{endpoint:{instanceId:`M8`,kind:`terminal`,pinName:`S`},kind:`endpoint`}}],netId:`net-tail-2`,start:{junctionId:`junction-ui-60`,kind:`junction`}},{id:`route-example-p1-lead`,netId:`net-ui-34`,start:{kind:`terminal`,instanceId:`P1`,pinName:`P`},legs:[{id:`route-leg-2f8c1e18297b8300`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M5`,pinName:`G`}},mode:`manual`}]},{id:`route-example-p2-lead`,netId:`net-ui-35`,start:{kind:`terminal`,instanceId:`P2`,pinName:`P`},legs:[{id:`route-leg-13465b00b3cbbf2b`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M8`,pinName:`G`}},mode:`manual`}]}],sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[],id:`project-main`,name:`New Circuit`,schemaVersion:48,simulationSetups:[],source:{dialect:`none`,entry:null,files:[],sourcePolicy:`copy`},structureRevision:0,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`document-main`},i={documents:[{annotations:[{alignment:`middle`,anchor:{fallbackPosition:{x:430,y:180},kind:`object`,localOffset:{x:0,y:-30},objectId:`X7`},id:`instance-label-X7`,kind:`instance-label`,locked:!1,rotation:0,visible:!1,binding:{kind:`instance-reference`,instanceId:`X7`}},{alignment:`middle`,anchor:{fallbackPosition:{x:530,y:260},kind:`object`,localOffset:{x:0,y:30},objectId:`X8`},id:`instance-label-X8`,kind:`instance-label`,locked:!1,rotation:0,visible:!1,binding:{kind:`instance-reference`,instanceId:`X8`}},{alignment:`start`,anchor:{fallbackPosition:{x:590,y:280},kind:`object`,localOffset:{x:10,y:0},objectId:`C9`},id:`instance-label-C9`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`C`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`L`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`instance-reference`,instanceId:`C9`}},{alignment:`middle`,anchor:{fallbackPosition:{x:530,y:140},kind:`object`,localOffset:{x:0,y:-20},objectId:`C10`},id:`instance-label-C10`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`C`},{children:[{kind:`text`,value:`C`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}],kind:`span`,style:`italic`}]},binding:{kind:`instance-reference`,instanceId:`C10`}},{alignment:`start`,anchor:{fallbackPosition:{x:610,y:210},kind:`object`,localOffset:{x:10,y:0},objectId:`P12`},id:`instance-label-P12`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`out`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`cell-terminal-name`,terminalId:`cell-terminal-p12`}},{alignment:`end`,anchor:{fallbackPosition:{x:360,y:210},kind:`object`,localOffset:{x:-10,y:10},objectId:`P13`},id:`instance-label-P13`,kind:`instance-label`,locked:!1,rotation:0,sizeScale:1,formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`V`}],kind:`span`,style:`italic`},{children:[{kind:`text`,value:`in`}],kind:`span`,style:`subscript`}],kind:`span`,style:`bold`}]},binding:{kind:`cell-terminal-name`,terminalId:`cell-terminal-p13`}}],connectivityEvidence:[{id:`connectivity-evidence-4f697832b597ca42`,kind:`name-claim`,name:`0`,netId:`net-contact-gnd11`,owner:{kind:`power-marker`,objectId:`GND11`},powerDomain:`ground`,scope:`global`}],constraints:[],drafting:{objects:[]},id:`document-main`,instances:[{id:`X7`,netlist:{parameters:{}},placement:{mirror:`x`,position:{x:430,y:210},rotation:180},reference:`X1`,symbolId:`opamp`},{id:`X8`,netlist:{parameters:{}},placement:{mirror:`none`,position:{x:530,y:210},rotation:0},reference:`X2`,symbolId:`voltage-amplifier`},{id:`C9`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`1p`}},placement:{mirror:`none`,position:{x:580,y:280},rotation:0},reference:`CL`,symbolId:`capacitor`},{id:`C10`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`1p`}},placement:{mirror:`none`,position:{x:530,y:160},rotation:270},reference:`CC`,symbolId:`capacitor`},{id:`GND11`,placement:{mirror:`none`,position:{x:580,y:310},rotation:0},symbolId:`ground`},{id:`P12`,placement:{mirror:`none`,position:{x:600,y:210},rotation:180},symbolId:`port`},{id:`P13`,placement:{mirror:`none`,position:{x:370,y:200},rotation:0},symbolId:`port`}],junctions:[{id:`junction-ui-3`,netId:`net-ui-1`,position:{x:480,y:210},role:`branch`},{id:`junction-ui-10`,netId:`net-contact-p13`,position:{x:580,y:210},role:`branch`},{id:`junction-ui-13`,netId:`net-contact-p13`,position:{x:580,y:250},role:`branch`}],layoutGroups:[],name:`Main`,netlist:{formalParameters:[],name:`Main`,terminals:[{direction:`passive`,id:`cell-terminal-p12`,interfaceInstanceIds:[`P12`],name:`Vout`,netId:`net-contact-p13`},{direction:`passive`,id:`cell-terminal-p13`,interfaceInstanceIds:[`P13`],name:`Vin`,netId:`net-split-f9c443f2edef6e67`}]},nets:[{id:`net-contact-gnd11`,terminals:[{instanceId:`GND11`,pinName:`0`},{instanceId:`C9`,pinName:`2`}]},{id:`net-ui-1`,terminals:[{instanceId:`X7`,pinName:`OUT`},{instanceId:`X8`,pinName:`IN`},{instanceId:`C10`,pinName:`1`}]},{id:`net-contact-p13`,terminals:[{instanceId:`X7`,pinName:`IN-`},{instanceId:`X8`,pinName:`OUT`},{instanceId:`P12`,pinName:`P`},{instanceId:`C9`,pinName:`1`},{instanceId:`C10`,pinName:`2`}]},{id:`net-split-f9c443f2edef6e67`,terminals:[{instanceId:`X7`,pinName:`IN+`},{instanceId:`P13`,pinName:`P`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:80,routes:[{id:`route-ui-2-a-3`,legs:[{id:`route-leg-47e0bf0eb0836598`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-3`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-1`,start:{instanceId:`X7`,kind:`terminal`,pinName:`OUT`}},{id:`route-ui-2-b-3`,legs:[{id:`route-leg-59e24b0b6e91157d`,mode:`manual`,to:{endpoint:{instanceId:`X8`,kind:`terminal`,pinName:`IN`},kind:`endpoint`}}],netId:`net-ui-1`,start:{junctionId:`junction-ui-3`,kind:`junction`}},{id:`route-ui-4`,legs:[{id:`route-leg-c70356568efe97cc`,mode:`manual`,to:{bendId:`route-bend-c70356568efe97cc`,kind:`bend`,position:{x:480,y:160}}},{id:`route-leg-c70357568efe997f`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-3`,kind:`junction`},kind:`endpoint`}}],netId:`net-ui-1`,start:{instanceId:`C10`,kind:`terminal`,pinName:`1`}},{id:`route-ui-5-a-10`,legs:[{id:`route-leg-124785f169f69868`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-10`,kind:`junction`},kind:`endpoint`}}],netId:`net-contact-p13`,start:{instanceId:`X8`,kind:`terminal`,pinName:`OUT`}},{id:`route-ui-5-b-10`,legs:[{id:`route-leg-ae69059609efde33`,mode:`manual`,to:{endpoint:{instanceId:`P12`,kind:`terminal`,pinName:`P`},kind:`endpoint`}}],netId:`net-contact-p13`,start:{junctionId:`junction-ui-10`,kind:`junction`}},{id:`route-ui-11-a-13`,legs:[{id:`route-leg-3ef55347e439cb11`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-13`,kind:`junction`},kind:`endpoint`}}],netId:`net-contact-p13`,start:{junctionId:`junction-ui-10`,kind:`junction`}},{id:`route-ui-11-b-13`,legs:[{id:`route-leg-13cd2580332fb9ae`,mode:`manual`,to:{endpoint:{instanceId:`C9`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-contact-p13`,start:{junctionId:`junction-ui-13`,kind:`junction`}},{id:`route-ui-15`,legs:[{id:`route-leg-6e8cc5c78f885417`,mode:`manual`,to:{bendId:`route-bend-6e8cc5c78f885417`,kind:`bend`,position:{x:370,y:220}}},{id:`route-leg-6e8cc4c78f885264`,mode:`manual`,to:{bendId:`route-bend-6e8cc4c78f885264`,kind:`bend`,position:{x:370,y:250}}},{id:`route-leg-6e8cc7c78f88577d`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-13`,kind:`junction`},kind:`endpoint`}}],netId:`net-contact-p13`,start:{instanceId:`X7`,kind:`terminal`,pinName:`IN-`}},{id:`route-ui-16`,legs:[{id:`route-leg-3ebbe7a93baf89d6`,mode:`manual`,to:{bendId:`route-bend-3ebbe7a93baf89d6`,kind:`bend`,position:{x:580,y:160}}},{id:`route-leg-3ebbe8a93baf8b89`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-10`,kind:`junction`},kind:`endpoint`}}],netId:`net-contact-p13`,start:{instanceId:`C10`,kind:`terminal`,pinName:`2`}},{id:`route-example-p13-lead`,netId:`net-split-f9c443f2edef6e67`,start:{kind:`terminal`,instanceId:`P13`,pinName:`P`},legs:[{id:`route-leg-af3a5a5320ebd5c8`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`X7`,pinName:`IN+`}},mode:`manual`}]}],sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[],id:`project-main`,name:`New Circuit`,schemaVersion:48,simulationSetups:[],source:{dialect:`none`,entry:null,files:[],sourcePolicy:`copy`},structureRevision:0,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`document-main`},a={schemaVersion:55,id:`project-five-transistor-ota-sky130`,name:`Five-Transistor OTA — Full Simulation Lab`,source:{entry:null,dialect:`none`,sourcePolicy:`copy`,files:[]},symbolLibrary:{id:`razavi-symbols`,version:`1`,hash:`razavi-reference-v1`},structureRevision:85,topDocumentId:`document-ota-5t-testbench`,documents:[{id:`document-ota-5t-testbench`,name:`Testbench`,revision:161,sourceStatus:`connectivity-modified`,netlist:{name:`Testbench`,terminals:[],formalParameters:[]},instances:[{id:`XDUT`,symbolId:`hierarchical-symbol-72404fc79d737213`,placement:{position:{x:560,y:320},rotation:0,mirror:`none`},reference:`XDUT`,netlist:{binding:{kind:`subcircuit`,childDocumentId:`document-ota-5t`},parameters:{}}},{id:`VDD`,symbolId:`voltage-source`,placement:{position:{x:490,y:160},rotation:90,mirror:`none`},reference:`VDD`,netlist:{binding:{kind:`primitive`,deviceClass:`voltage-source`},parameters:{dc:`1.8`}}},{id:`VINP`,symbolId:`voltage-source`,placement:{position:{x:400,y:300},rotation:90,mirror:`none`},reference:`VINP`,netlist:{binding:{kind:`primitive`,deviceClass:`voltage-source`},parameters:{acMagnitude:`1`,dc:`0.9`,delay:`1u`,fall:`1n`,high:`0.91`,low:`0.9`,period:`3u`,rise:`1n`,waveform:`pulse`,width:`1u`}}},{id:`VINN`,symbolId:`voltage-source`,placement:{position:{x:400,y:350},rotation:90,mirror:`none`},reference:`VINN`,netlist:{binding:{kind:`primitive`,deviceClass:`voltage-source`},parameters:{dc:`0.9`}}},{id:`IBIAS`,symbolId:`current-source`,placement:{position:{x:550,y:210},rotation:0,mirror:`none`},reference:`IBIAS`,netlist:{binding:{kind:`primitive`,deviceClass:`current-source`},parameters:{dc:`15u`}}},{id:`CL`,symbolId:`capacitor`,placement:{position:{x:730,y:360},rotation:0,mirror:`none`},reference:`CL`,netlist:{binding:{kind:`primitive`,deviceClass:`capacitor`},parameters:{value:`1p`}}},{id:`GND1`,symbolId:`ground`,placement:{position:{x:430,y:160},rotation:90,mirror:`none`}},{id:`GND2`,symbolId:`ground`,placement:{position:{x:340,y:300},rotation:90,mirror:`none`}},{id:`GND3`,symbolId:`ground`,placement:{position:{x:340,y:350},rotation:90,mirror:`none`}},{id:`GND4`,symbolId:`ground`,placement:{position:{x:560,y:420},rotation:0,mirror:`none`}},{id:`GND5`,symbolId:`ground`,placement:{position:{x:730,y:400},rotation:0,mirror:`none`}}],nets:[{id:`net-power-gnd3`,terminals:[{instanceId:`GND3`,pinName:`0`},{instanceId:`VINN`,pinName:`-`}]},{id:`net-power-gnd4`,terminals:[{instanceId:`GND4`,pinName:`0`},{instanceId:`XDUT`,pinName:`vss`}]},{id:`net-power-gnd5`,terminals:[{instanceId:`GND5`,pinName:`0`},{instanceId:`CL`,pinName:`2`}]},{id:`net-tb-vdd`,terminals:[{instanceId:`VDD`,pinName:`+`},{instanceId:`IBIAS`,pinName:`+`},{instanceId:`XDUT`,pinName:`vdd`}]},{id:`tb-ibias-net`,terminals:[{instanceId:`IBIAS`,pinName:`-`},{instanceId:`XDUT`,pinName:`ibias`}]},{id:`tb-vinp-net`,terminals:[{instanceId:`VINP`,pinName:`+`},{instanceId:`XDUT`,pinName:`vinp`}]},{id:`tb-vinn-net`,terminals:[{instanceId:`VINN`,pinName:`+`},{instanceId:`XDUT`,pinName:`vinn`}]},{id:`tb-vout-net`,terminals:[{instanceId:`XDUT`,pinName:`vout`},{instanceId:`CL`,pinName:`1`}]},{id:`net-split-a810f1946a2e3084`,terminals:[{instanceId:`GND1`,pinName:`0`},{instanceId:`VDD`,pinName:`-`}]},{id:`net-split-f3cbcac420d93ece`,terminals:[{instanceId:`GND2`,pinName:`0`},{instanceId:`VINP`,pinName:`-`}]}],connectivityEvidence:[{id:`connectivity-evidence-33dd40c74ee1950d`,kind:`name-claim`,netId:`net-split-a810f1946a2e3084`,name:`0`,owner:{kind:`power-marker`,objectId:`GND1`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-4fd51303c6ed3225`,kind:`name-claim`,netId:`net-split-f3cbcac420d93ece`,name:`0`,owner:{kind:`power-marker`,objectId:`GND2`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-97019202b6a994e5`,kind:`name-claim`,netId:`net-power-gnd3`,name:`0`,owner:{kind:`power-marker`,objectId:`GND3`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-d2bb87eae3b4a1c5`,kind:`name-claim`,netId:`net-power-gnd4`,name:`0`,owner:{kind:`power-marker`,objectId:`GND4`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-7ec67ce55c90646d`,kind:`name-claim`,netId:`net-power-gnd5`,name:`0`,owner:{kind:`power-marker`,objectId:`GND5`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-7df4b9f72a121645`,kind:`name-claim`,netId:`net-tb-vdd`,name:`vdd`,owner:{kind:`net-label`,annotationId:`net-label-tb-vdd-source-route`},scope:`local`},{id:`connectivity-evidence-f7b96bb5ab25d11a`,kind:`name-claim`,netId:`tb-ibias-net`,name:`ibias`,owner:{kind:`net-label`,annotationId:`net-label-tb-ibias-route`},scope:`local`},{id:`connectivity-evidence-ade80d1dc122d646`,kind:`name-claim`,netId:`tb-vinp-net`,name:`vinp`,owner:{kind:`net-label`,annotationId:`net-label-tb-vinp-route`},scope:`local`},{id:`connectivity-evidence-b66084c183ee210e`,kind:`name-claim`,netId:`tb-vinn-net`,name:`vinn`,owner:{kind:`net-label`,annotationId:`net-label-tb-vinn-route`},scope:`local`},{id:`connectivity-evidence-db342e0a821d20d0`,kind:`name-claim`,netId:`tb-vout-net`,name:`vout`,owner:{kind:`net-label`,annotationId:`net-label-tb-vout-route`},scope:`local`}],routes:[{id:`tb-gnd-vinn-route`,netId:`net-power-gnd3`,start:{kind:`terminal`,instanceId:`VINN`,pinName:`-`},legs:[{id:`route-leg-34fd6882297027f4`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`GND3`,pinName:`0`}},mode:`manual`}]},{id:`tb-gnd-dut-route`,netId:`net-power-gnd4`,start:{kind:`terminal`,instanceId:`GND4`,pinName:`0`},legs:[{id:`route-leg-ac185f3591d27db9`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vss`}},mode:`manual`}]},{id:`tb-gnd-cl-route`,netId:`net-power-gnd5`,start:{kind:`terminal`,instanceId:`CL`,pinName:`2`},legs:[{id:`route-leg-af02721fb438a990`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`GND5`,pinName:`0`}},mode:`manual`}]},{id:`tb-ibias-route`,netId:`tb-ibias-net`,start:{kind:`terminal`,instanceId:`IBIAS`,pinName:`-`},legs:[{id:`route-leg-9c7f13cc644db106`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`ibias`}},mode:`manual`}]},{id:`tb-vinp-route`,netId:`tb-vinp-net`,start:{kind:`terminal`,instanceId:`VINP`,pinName:`+`},legs:[{id:`route-leg-db9df07a18d56c80`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vinp`}},mode:`manual`}]},{id:`tb-vinn-route`,netId:`tb-vinn-net`,start:{kind:`terminal`,instanceId:`VINN`,pinName:`+`},legs:[{id:`route-leg-42de77b6b7306ba2`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vinn`}},mode:`manual`}]},{id:`tb-vout-route`,netId:`tb-vout-net`,start:{kind:`terminal`,instanceId:`XDUT`,pinName:`vout`},legs:[{id:`route-leg-9cbad225568967f9`,to:{kind:`bend`,bendId:`route-bend-9cbad225568967f9`,position:{x:730,y:320}},mode:`manual`},{id:`route-leg-9cbad12556896646`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`CL`,pinName:`1`}},mode:`manual`}]},{id:`route-ui-1`,netId:`net-split-a810f1946a2e3084`,start:{kind:`terminal`,instanceId:`GND1`,pinName:`0`},legs:[{id:`route-leg-ace29482c237b3d7`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`VDD`,pinName:`-`}},mode:`manual`}]},{id:`route-35e042e11550de52`,netId:`net-split-f3cbcac420d93ece`,start:{kind:`terminal`,instanceId:`GND2`,pinName:`0`},legs:[{id:`route-leg-94c48a25d3985fe6`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`VINP`,pinName:`-`}},mode:`manual`}]},{id:`route-ui-3`,netId:`net-tb-vdd`,start:{kind:`terminal`,instanceId:`VDD`,pinName:`+`},legs:[{id:`route-leg-950eb45aec291af5`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-canonical-fa66a02887bbb6d9`}},mode:`manual`}]},{id:`tb-vdd-dut-route-a-2`,netId:`net-tb-vdd`,start:{kind:`junction`,junctionId:`junction-canonical-fa66a02887bbb6d9`},legs:[{id:`route-leg-624f4d1edaa3951c`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`IBIAS`,pinName:`+`}},mode:`manual`}]},{id:`tb-vdd-dut-route-b-2`,netId:`net-tb-vdd`,start:{kind:`junction`,junctionId:`junction-canonical-fa66a02887bbb6d9`},legs:[{id:`route-leg-c64a8aa78eb2d60f`,to:{kind:`bend`,bendId:`route-bend-624f4d1edaa3951c`,position:{x:590,y:160}},mode:`manual`},{id:`route-leg-624f4e1edaa396cf`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vdd`}},mode:`manual`}]}],junctions:[{id:`junction-canonical-fa66a02887bbb6d9`,netId:`net-tb-vdd`,position:{x:550,y:160},role:`branch`}],annotations:[{id:`instance-label-XDUT`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`XDUT`},anchor:{kind:`object`,objectId:`XDUT`,localOffset:{x:55,y:80},fallbackPosition:{x:615,y:400}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-VDD`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`VDD`},anchor:{kind:`object`,objectId:`VDD`,localOffset:{x:-30,y:-45},fallbackPosition:{x:460,y:115}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-value-VDD`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`VDD`},anchor:{kind:`object`,objectId:`VDD`,localOffset:{x:10,y:-45},fallbackPosition:{x:500,y:115}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-VINP`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`VINP`},anchor:{kind:`object`,objectId:`VINP`,localOffset:{x:-25,y:-35},fallbackPosition:{x:375,y:265}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-value-VINP`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`VINP`},anchor:{kind:`object`,objectId:`VINP`,localOffset:{x:20,y:-35},fallbackPosition:{x:420,y:265}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-VINN`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`VINN`},anchor:{kind:`object`,objectId:`VINN`,localOffset:{x:-20,y:40},fallbackPosition:{x:380,y:390}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-value-VINN`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`VINN`},anchor:{kind:`object`,objectId:`VINN`,localOffset:{x:25,y:40},fallbackPosition:{x:425,y:390}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-IBIAS`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`IBIAS`},anchor:{kind:`object`,objectId:`IBIAS`,localOffset:{x:-50,y:-5},fallbackPosition:{x:500,y:205}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-IBIAS`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`IBIAS`},anchor:{kind:`object`,objectId:`IBIAS`,localOffset:{x:-50,y:20},fallbackPosition:{x:500,y:230}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-CL`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`CL`},anchor:{kind:`object`,objectId:`CL`,localOffset:{x:20,y:-5},fallbackPosition:{x:750,y:355}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-CL`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`CL`},anchor:{kind:`object`,objectId:`CL`,localOffset:{x:45,y:-5},fallbackPosition:{x:775,y:355}},alignment:`start`,rotation:0,locked:!1},{id:`net-label-tb-vout-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-vout-net`},anchor:{kind:`route`,routeId:`tb-vout-route`,legId:`route-leg-9cbad225568967f9`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:685,y:310}},netId:`tb-vout-net`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-vdd-source-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`net-tb-vdd`},anchor:{kind:`route`,routeId:`route-ui-3`,legId:`route-leg-950eb45aec291af5`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:530,y:150}},netId:`net-tb-vdd`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-ibias-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-ibias-net`},anchor:{kind:`route`,routeId:`tb-ibias-route`,legId:`route-leg-9c7f13cc644db106`,t:.5,normalOffset:14,direction:`forward`,orientation:`follow`,fallbackPosition:{x:536,y:240}},netId:`tb-ibias-net`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-vinp-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-vinp-net`},anchor:{kind:`route`,routeId:`tb-vinp-route`,legId:`route-leg-db9df07a18d56c80`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:450,y:290}},netId:`tb-vinp-net`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-vinn-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-vinn-net`},anchor:{kind:`route`,routeId:`tb-vinn-route`,legId:`route-leg-42de77b6b7306ba2`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:450,y:340}},netId:`tb-vinn-net`,alignment:`middle`,rotation:0,locked:!1}],presentation:{styleProfileId:`razavi-textbook-v1`,grid:10,compactness:`normal`},layoutGroups:[],constraints:[],noConnects:[],drafting:{objects:[]}},{id:`document-ota-5t`,name:`ota_5t`,revision:162,sourceStatus:`connectivity-modified`,netlist:{name:`ota_5t`,terminals:[{id:`terminal-pvss`,name:`vss`,netId:`net-cell-pin-pvss`,direction:`passive`,interfaceInstanceIds:[`PVSS`]},{id:`terminal-pibias`,name:`ibias`,netId:`net-cell-pin-pibias`,direction:`input`,interfaceInstanceIds:[`PIBIAS`]},{id:`terminal-pvdd`,name:`vdd`,netId:`net-cell-pin-pvdd`,direction:`passive`,interfaceInstanceIds:[`PVDD`]},{id:`terminal-pvinn`,name:`vinn`,netId:`net-cell-pin-pvinn`,direction:`input`,interfaceInstanceIds:[`PVINN`]},{id:`terminal-pvinp`,name:`vinp`,netId:`net-cell-pin-pvinp`,direction:`input`,interfaceInstanceIds:[`PVINP`]},{id:`terminal-pvout`,name:`vout`,netId:`net-cell-pin-pvout`,direction:`output`,interfaceInstanceIds:[`PVOUT`]}],formalParameters:[]},instances:[{id:`M1`,symbolId:`nmos`,mosBulkBinding:{origin:`cell-default`,netId:`net-cell-pin-pvss`},placement:{position:{x:370,y:280},rotation:0,mirror:`none`},reference:`XM1`,netlist:{binding:{kind:`external-subcircuit`,definitionId:`external-subcircuit-e5ee3d17d0c7c89a`},parameters:{l:`1u`,nf:`12`,w:`96u`}}},{id:`M2`,symbolId:`nmos`,mosBulkBinding:{origin:`cell-default`,netId:`net-cell-pin-pvss`},placement:{position:{x:570,y:280},rotation:0,mirror:`horizontal`},reference:`XM2`,netlist:{binding:{kind:`external-subcircuit`,definitionId:`external-subcircuit-e5ee3d17d0c7c89a`},parameters:{l:`1u`,nf:`12`,w:`96u`}}},{id:`M3`,symbolId:`pmos`,mosBulkBinding:{origin:`cell-default`,netId:`net-cell-pin-pvdd`},placement:{position:{x:390,y:160},rotation:0,mirror:`horizontal`},reference:`XM3`,netlist:{binding:{kind:`external-subcircuit`,definitionId:`external-subcircuit-27f716b14d59fc10`},parameters:{l:`1u`,nf:`8`,w:`64u`}}},{id:`M4`,symbolId:`pmos`,mosBulkBinding:{origin:`cell-default`,netId:`net-cell-pin-pvdd`},placement:{position:{x:550,y:160},rotation:0,mirror:`none`},reference:`XM4`,netlist:{binding:{kind:`external-subcircuit`,definitionId:`external-subcircuit-27f716b14d59fc10`},parameters:{l:`1u`,nf:`8`,w:`64u`}}},{id:`M5`,symbolId:`nmos`,mosBulkBinding:{origin:`cell-default`,netId:`net-cell-pin-pvss`},placement:{position:{x:470,y:440},rotation:0,mirror:`none`},reference:`XM5`,netlist:{binding:{kind:`external-subcircuit`,definitionId:`external-subcircuit-e5ee3d17d0c7c89a`},parameters:{l:`3u`,nf:`20`,w:`100u`}}},{id:`M6`,symbolId:`nmos`,mosBulkBinding:{origin:`cell-default`,netId:`net-cell-pin-pvss`},placement:{position:{x:300,y:440},rotation:0,mirror:`horizontal`},reference:`XM6`,netlist:{binding:{kind:`external-subcircuit`,definitionId:`external-subcircuit-e5ee3d17d0c7c89a`},parameters:{l:`3u`,nf:`6`,w:`60u`}}},{id:`PVSS`,symbolId:`port`,placement:{position:{x:290,y:540},rotation:270,mirror:`none`}},{id:`PIBIAS`,symbolId:`port`,placement:{position:{x:290,y:360},rotation:90,mirror:`none`}},{id:`PVDD`,symbolId:`port`,placement:{position:{x:310,y:100},rotation:0,mirror:`none`}},{id:`PVINN`,symbolId:`port`,placement:{position:{x:610,y:280},rotation:180,mirror:`none`}},{id:`PVINP`,symbolId:`port`,placement:{position:{x:330,y:280},rotation:0,mirror:`none`}},{id:`PVOUT`,symbolId:`port`,placement:{position:{x:630,y:220},rotation:180,mirror:`none`}}],nets:[{id:`net-cell-pin-pvss`,terminals:[{instanceId:`PVSS`,pinName:`P`},{instanceId:`M6`,pinName:`S`},{instanceId:`M5`,pinName:`S`},{instanceId:`M1`,pinName:`B`},{instanceId:`M2`,pinName:`B`},{instanceId:`M5`,pinName:`B`},{instanceId:`M6`,pinName:`B`}]},{id:`net-cell-pin-pibias`,terminals:[{instanceId:`PIBIAS`,pinName:`P`},{instanceId:`M6`,pinName:`G`},{instanceId:`M6`,pinName:`D`},{instanceId:`M5`,pinName:`G`}]},{id:`net-cell-pin-pvdd`,terminals:[{instanceId:`PVDD`,pinName:`P`},{instanceId:`M3`,pinName:`S`},{instanceId:`M4`,pinName:`S`},{instanceId:`M3`,pinName:`B`},{instanceId:`M4`,pinName:`B`}]},{id:`net-cell-pin-pvinn`,terminals:[{instanceId:`PVINN`,pinName:`P`},{instanceId:`M2`,pinName:`G`}]},{id:`net-cell-pin-pvinp`,terminals:[{instanceId:`PVINP`,pinName:`P`},{instanceId:`M1`,pinName:`G`}]},{id:`net-cell-pin-pvout`,terminals:[{instanceId:`PVOUT`,pinName:`P`},{instanceId:`M4`,pinName:`D`},{instanceId:`M2`,pinName:`D`}]},{id:`net-dut-nleft`,terminals:[{instanceId:`M3`,pinName:`D`},{instanceId:`M1`,pinName:`D`},{instanceId:`M3`,pinName:`G`},{instanceId:`M4`,pinName:`G`}]},{id:`net-dut-tail`,terminals:[{instanceId:`M5`,pinName:`D`},{instanceId:`M1`,pinName:`S`},{instanceId:`M2`,pinName:`S`}]}],connectivityEvidence:[{id:`connectivity-evidence-9f1ce905a5db8772`,kind:`name-claim`,netId:`net-dut-nleft`,name:`nleft`,owner:{kind:`net-label`,annotationId:`net-label-dut-nleft-trunk-route`},scope:`local`},{id:`connectivity-evidence-ca7bbcf380650530`,kind:`name-claim`,netId:`net-dut-tail`,name:`tail`,owner:{kind:`net-label`,annotationId:`net-label-dut-tail-m1s-route`},scope:`local`}],routes:[{id:`dut-vdd-port-route`,netId:`net-cell-pin-pvdd`,start:{kind:`terminal`,instanceId:`PVDD`,pinName:`P`},legs:[{id:`route-leg-a720db58bbd8e3ad`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-vdd`}},mode:`manual`}]},{id:`dut-vdd-m3-route`,netId:`net-cell-pin-pvdd`,start:{kind:`terminal`,instanceId:`M3`,pinName:`S`},legs:[{id:`route-leg-e029990b3e5d06bc`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-vdd`}},mode:`manual`}]},{id:`dut-vdd-m4-route`,netId:`net-cell-pin-pvdd`,start:{kind:`terminal`,instanceId:`M4`,pinName:`S`},legs:[{id:`route-leg-5b9805254e937a59`,to:{kind:`bend`,bendId:`route-bend-5b9805254e937a59`,position:{x:560,y:100}},mode:`manual`},{id:`route-leg-5b9804254e9378a6`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-vdd`}},mode:`manual`}]},{id:`dut-vout-port-route`,netId:`net-cell-pin-pvout`,start:{kind:`terminal`,instanceId:`PVOUT`,pinName:`P`},legs:[{id:`route-leg-6043a3e9d6720b4e`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-vout`}},mode:`manual`}]},{id:`dut-vout-m4-route`,netId:`net-cell-pin-pvout`,start:{kind:`terminal`,instanceId:`M4`,pinName:`D`},legs:[{id:`route-leg-ae091c386561f66a`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-vout`}},mode:`manual`}]},{id:`dut-vout-m2-route`,netId:`net-cell-pin-pvout`,start:{kind:`terminal`,instanceId:`M2`,pinName:`D`},legs:[{id:`route-leg-109a650f1a292f40`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-vout`}},mode:`manual`}]},{id:`dut-vinp-route`,netId:`net-cell-pin-pvinp`,start:{kind:`terminal`,instanceId:`PVINP`,pinName:`P`},legs:[{id:`route-leg-a72f03f468a1d2f4`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M1`,pinName:`G`}},mode:`manual`}]},{id:`dut-vinn-route`,netId:`net-cell-pin-pvinn`,start:{kind:`terminal`,instanceId:`PVINN`,pinName:`P`},legs:[{id:`route-leg-d16ea816ee4bf8ce`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M2`,pinName:`G`}},mode:`manual`}]},{id:`dut-nleft-m3d-route`,netId:`net-dut-nleft`,start:{kind:`terminal`,instanceId:`M3`,pinName:`D`},legs:[{id:`route-leg-f449712ee4a17702`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-nleft-a`}},mode:`manual`}]},{id:`dut-nleft-m1d-route`,netId:`net-dut-nleft`,start:{kind:`terminal`,instanceId:`M1`,pinName:`D`},legs:[{id:`route-leg-4449fdaa3f37ea4c`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-nleft-a`}},mode:`manual`}]},{id:`dut-nleft-trunk-route`,netId:`net-dut-nleft`,start:{kind:`junction`,junctionId:`junction-dut-nleft-a`},legs:[{id:`route-leg-220f44782704e593`,to:{kind:`bend`,bendId:`route-bend-adb5e8be6b3344d6`,position:{x:470,y:210}},mode:`manual`},{id:`route-leg-c5b2e6b4e8fd7635`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-nleft-b`}},mode:`manual`}]},{id:`dut-nleft-m3g-route`,netId:`net-dut-nleft`,start:{kind:`terminal`,instanceId:`M3`,pinName:`G`},legs:[{id:`route-leg-a7d85c5a0e43f8af`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-nleft-b`}},mode:`manual`}]},{id:`dut-nleft-m4g-route`,netId:`net-dut-nleft`,start:{kind:`terminal`,instanceId:`M4`,pinName:`G`},legs:[{id:`route-leg-5dee764c63230748`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-nleft-b`}},mode:`manual`}]},{id:`dut-tail-m5d-route`,netId:`net-dut-tail`,start:{kind:`terminal`,instanceId:`M5`,pinName:`D`},legs:[{id:`route-leg-beabd8e3dedf141e`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-tail`}},mode:`manual`}]},{id:`dut-tail-m1s-route`,netId:`net-dut-tail`,start:{kind:`terminal`,instanceId:`M1`,pinName:`S`},legs:[{id:`route-leg-ada2b826f49de203`,to:{kind:`bend`,bendId:`route-bend-ada2b826f49de203`,position:{x:380,y:340}},mode:`manual`},{id:`route-leg-ada2b726f49de050`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-tail`}},mode:`manual`}]},{id:`dut-tail-m2s-route`,netId:`net-dut-tail`,start:{kind:`terminal`,instanceId:`M2`,pinName:`S`},legs:[{id:`route-leg-a525c367f98f1f50`,to:{kind:`bend`,bendId:`route-bend-a525c367f98f1f50`,position:{x:560,y:340}},mode:`manual`},{id:`route-leg-a525c467f98f2103`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-dut-tail`}},mode:`manual`}]},{id:`dut-vss-m5-route`,netId:`net-cell-pin-pvss`,start:{kind:`terminal`,instanceId:`M6`,pinName:`S`},legs:[{id:`route-leg-1fd2cacc728a5fec`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-canonical-3993d1302f152696`}},mode:`manual`}]},{id:`dut-vss-port-route`,netId:`net-cell-pin-pvss`,start:{kind:`junction`,junctionId:`junction-canonical-3993d1302f152696`},legs:[{id:`route-leg-9a243a8749f3f47b`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`PVSS`,pinName:`P`}},mode:`manual`}]},{id:`route-canonical-e161f2c6f556c327`,netId:`net-cell-pin-pvss`,start:{kind:`junction`,junctionId:`junction-canonical-3993d1302f152696`},legs:[{id:`route-leg-6406fbb3dde68137`,to:{kind:`bend`,bendId:`route-bend-6406fbb3dde68137`,position:{x:480,y:490}},mode:`manual`},{id:`route-leg-6406fab3dde67f84`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M5`,pinName:`S`}},mode:`manual`}]},{id:`dut-ibias-port-route`,netId:`net-cell-pin-pibias`,start:{kind:`terminal`,instanceId:`PIBIAS`,pinName:`P`},legs:[{id:`route-leg-df9387cdaaaab728`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-canonical-a69a92ac5a85be8f`}},mode:`manual`}]},{id:`dut-ibias-m6d-route`,netId:`net-cell-pin-pibias`,start:{kind:`junction`,junctionId:`junction-canonical-a69a92ac5a85be8f`},legs:[{id:`route-leg-dfa853aaa4309a7e`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M6`,pinName:`D`}},mode:`manual`}]},{id:`dut-ibias-m5g-route`,netId:`net-cell-pin-pibias`,start:{kind:`junction`,junctionId:`junction-canonical-a69a92ac5a85be8f`},legs:[{id:`route-leg-7172d946242cfd98`,to:{kind:`bend`,bendId:`route-bend-9351f6029255a2bb`,position:{x:380,y:400}},mode:`manual`},{id:`route-leg-a63007ca9d22b9cc`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-canonical-0fddbcfe7d216a81`}},mode:`manual`}]},{id:`dut-ibias-m6g-route`,netId:`net-cell-pin-pibias`,start:{kind:`terminal`,instanceId:`M6`,pinName:`G`},legs:[{id:`route-leg-36accc90d5a60eab`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-canonical-0fddbcfe7d216a81`}},mode:`manual`}]},{id:`route-canonical-781ca20d250b5d82`,netId:`net-cell-pin-pibias`,start:{kind:`junction`,junctionId:`junction-canonical-0fddbcfe7d216a81`},legs:[{id:`route-leg-77da2da4eeb4e9de`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`M5`,pinName:`G`}},mode:`manual`}]}],junctions:[{id:`junction-dut-vdd`,netId:`net-cell-pin-pvdd`,position:{x:380,y:100},role:`branch`},{id:`junction-dut-vout`,netId:`net-cell-pin-pvout`,position:{x:560,y:220},role:`branch`},{id:`junction-dut-nleft-a`,netId:`net-dut-nleft`,position:{x:380,y:210},role:`branch`},{id:`junction-dut-nleft-b`,netId:`net-dut-nleft`,position:{x:470,y:160},role:`branch`},{id:`junction-dut-tail`,netId:`net-dut-tail`,position:{x:480,y:340},role:`branch`},{id:`junction-canonical-a69a92ac5a85be8f`,netId:`net-cell-pin-pibias`,position:{x:290,y:400},role:`branch`},{id:`junction-canonical-3993d1302f152696`,netId:`net-cell-pin-pvss`,position:{x:290,y:490},role:`branch`},{id:`junction-canonical-0fddbcfe7d216a81`,netId:`net-cell-pin-pibias`,position:{x:380,y:440},role:`branch`}],annotations:[{id:`instance-label-PVSS`,kind:`instance-label`,binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvss`},anchor:{kind:`object`,objectId:`PVSS`,localOffset:{x:10,y:20},fallbackPosition:{x:300,y:560}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-PIBIAS`,kind:`instance-label`,binding:{kind:`cell-terminal-name`,terminalId:`terminal-pibias`},anchor:{kind:`object`,objectId:`PIBIAS`,localOffset:{x:-45,y:-5},fallbackPosition:{x:245,y:355}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-PVDD`,kind:`instance-label`,binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvdd`},anchor:{kind:`object`,objectId:`PVDD`,localOffset:{x:-5,y:-15},fallbackPosition:{x:305,y:85}},alignment:`end`,rotation:0,locked:!1},{id:`instance-label-PVINN`,kind:`instance-label`,binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvinn`},anchor:{kind:`object`,objectId:`PVINN`,localOffset:{x:20,y:-10},fallbackPosition:{x:630,y:270}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-PVINP`,kind:`instance-label`,binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvinp`},anchor:{kind:`object`,objectId:`PVINP`,localOffset:{x:-20,y:-10},fallbackPosition:{x:310,y:270}},alignment:`end`,rotation:0,locked:!1},{id:`instance-label-PVOUT`,kind:`instance-label`,binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvout`},anchor:{kind:`object`,objectId:`PVOUT`,localOffset:{x:15,y:0},fallbackPosition:{x:645,y:220}},alignment:`start`,rotation:0,locked:!1},{id:`net-label-dut-nleft-trunk-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`net-dut-nleft`},anchor:{kind:`route`,routeId:`dut-nleft-trunk-route`,legId:`route-leg-220f44782704e593`,t:.625,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:436,y:200}},netId:`net-dut-nleft`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-dut-tail-m1s-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`net-dut-tail`},anchor:{kind:`route`,routeId:`dut-tail-m1s-route`,legId:`route-leg-ada2b726f49de050`,t:.9,normalOffset:-14,direction:`forward`,orientation:`follow`,fallbackPosition:{x:0,y:0}},netId:`net-dut-tail`,alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-M1`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`M1`},anchor:{kind:`object`,objectId:`M1`,localOffset:{x:-25,y:35},fallbackPosition:{x:345,y:315}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-M1`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`M1`},anchor:{kind:`object`,objectId:`M1`,localOffset:{x:20,y:-5},fallbackPosition:{x:390,y:275}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-M2`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`M2`},anchor:{kind:`object`,objectId:`M2`,localOffset:{x:35,y:30},fallbackPosition:{x:605,y:310}},alignment:`end`,rotation:0,locked:!1},{id:`instance-value-M2`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`M2`},anchor:{kind:`object`,objectId:`M2`,localOffset:{x:-15,y:5},fallbackPosition:{x:555,y:285}},alignment:`end`,rotation:0,locked:!1},{id:`instance-label-M3`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`M3`},anchor:{kind:`object`,objectId:`M3`,localOffset:{x:30,y:-25},fallbackPosition:{x:420,y:135}},alignment:`end`,rotation:0,locked:!1},{id:`instance-value-M3`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`M3`},anchor:{kind:`object`,objectId:`M3`,localOffset:{x:-20,y:5},fallbackPosition:{x:370,y:165}},alignment:`end`,rotation:0,locked:!1},{id:`instance-label-M4`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`M4`},anchor:{kind:`object`,objectId:`M4`,localOffset:{x:-30,y:-20},fallbackPosition:{x:520,y:140}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-M4`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`M4`},anchor:{kind:`object`,objectId:`M4`,localOffset:{x:20,y:10},fallbackPosition:{x:570,y:170}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-M5`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`M5`},anchor:{kind:`object`,objectId:`M5`,localOffset:{x:-30,y:25},fallbackPosition:{x:440,y:465}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-M5`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`M5`},anchor:{kind:`object`,objectId:`M5`,localOffset:{x:20,y:10},fallbackPosition:{x:490,y:450}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-M6`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`M6`},anchor:{kind:`object`,objectId:`M6`,localOffset:{x:35,y:25},fallbackPosition:{x:335,y:465}},alignment:`end`,rotation:0,locked:!1},{id:`instance-value-M6`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`M6`},anchor:{kind:`object`,objectId:`M6`,localOffset:{x:-25,y:10},fallbackPosition:{x:275,y:450}},alignment:`end`,rotation:0,locked:!1}],presentation:{styleProfileId:`razavi-textbook-v1`,grid:10,compactness:`normal`,cellSymbol:{minimumBodySize:{width:140,height:120},pinPlacements:[{terminalId:`terminal-pvdd`,side:`north`,offset:30},{terminalId:`terminal-pvinn`,side:`west`,offset:30},{terminalId:`terminal-pvout`,side:`east`,offset:0},{terminalId:`terminal-pvss`,side:`south`,offset:0},{terminalId:`terminal-pvinp`,side:`west`,offset:-20},{terminalId:`terminal-pibias`,side:`north`,offset:-10}]}},mosBulkDefaults:{nmosNetId:`net-cell-pin-pvss`,pmosNetId:`net-cell-pin-pvdd`},layoutGroups:[],constraints:[],noConnects:[],drafting:{objects:[]}},{id:`document-ota-5t-testbench-sin`,name:`Testbench SIN`,revision:161,sourceStatus:`connectivity-modified`,netlist:{name:`Testbench_SIN`,terminals:[],formalParameters:[]},instances:[{id:`XDUT`,symbolId:`hierarchical-symbol-72404fc79d737213`,placement:{position:{x:560,y:320},rotation:0,mirror:`none`},reference:`XDUT`,netlist:{binding:{kind:`subcircuit`,childDocumentId:`document-ota-5t`},parameters:{}}},{id:`VDD`,symbolId:`voltage-source`,placement:{position:{x:490,y:160},rotation:90,mirror:`none`},reference:`VDD`,netlist:{binding:{kind:`primitive`,deviceClass:`voltage-source`},parameters:{dc:`1.8`}}},{id:`VINP`,symbolId:`voltage-source`,placement:{position:{x:400,y:300},rotation:90,mirror:`none`},reference:`VINP`,netlist:{binding:{kind:`primitive`,deviceClass:`voltage-source`},parameters:{acMagnitude:`1`,amplitude:`10m`,damping:`0`,dc:`0.9`,delay:`0`,frequency:`1Meg`,offset:`0.9`,phase:`0`,waveform:`sin`}}},{id:`VINN`,symbolId:`voltage-source`,placement:{position:{x:400,y:350},rotation:90,mirror:`none`},reference:`VINN`,netlist:{binding:{kind:`primitive`,deviceClass:`voltage-source`},parameters:{dc:`0.9`}}},{id:`IBIAS`,symbolId:`current-source`,placement:{position:{x:550,y:210},rotation:0,mirror:`none`},reference:`IBIAS`,netlist:{binding:{kind:`primitive`,deviceClass:`current-source`},parameters:{dc:`15u`}}},{id:`CL`,symbolId:`capacitor`,placement:{position:{x:730,y:360},rotation:0,mirror:`none`},reference:`CL`,netlist:{binding:{kind:`primitive`,deviceClass:`capacitor`},parameters:{value:`1p`}}},{id:`GND1`,symbolId:`ground`,placement:{position:{x:430,y:160},rotation:90,mirror:`none`}},{id:`GND2`,symbolId:`ground`,placement:{position:{x:340,y:300},rotation:90,mirror:`none`}},{id:`GND3`,symbolId:`ground`,placement:{position:{x:340,y:350},rotation:90,mirror:`none`}},{id:`GND4`,symbolId:`ground`,placement:{position:{x:560,y:420},rotation:0,mirror:`none`}},{id:`GND5`,symbolId:`ground`,placement:{position:{x:730,y:400},rotation:0,mirror:`none`}}],nets:[{id:`net-power-gnd3`,terminals:[{instanceId:`GND3`,pinName:`0`},{instanceId:`VINN`,pinName:`-`}]},{id:`net-power-gnd4`,terminals:[{instanceId:`GND4`,pinName:`0`},{instanceId:`XDUT`,pinName:`vss`}]},{id:`net-power-gnd5`,terminals:[{instanceId:`GND5`,pinName:`0`},{instanceId:`CL`,pinName:`2`}]},{id:`net-tb-vdd`,terminals:[{instanceId:`VDD`,pinName:`+`},{instanceId:`IBIAS`,pinName:`+`},{instanceId:`XDUT`,pinName:`vdd`}]},{id:`tb-ibias-net`,terminals:[{instanceId:`IBIAS`,pinName:`-`},{instanceId:`XDUT`,pinName:`ibias`}]},{id:`tb-vinp-net`,terminals:[{instanceId:`VINP`,pinName:`+`},{instanceId:`XDUT`,pinName:`vinp`}]},{id:`tb-vinn-net`,terminals:[{instanceId:`VINN`,pinName:`+`},{instanceId:`XDUT`,pinName:`vinn`}]},{id:`tb-vout-net`,terminals:[{instanceId:`XDUT`,pinName:`vout`},{instanceId:`CL`,pinName:`1`}]},{id:`net-split-a810f1946a2e3084`,terminals:[{instanceId:`GND1`,pinName:`0`},{instanceId:`VDD`,pinName:`-`}]},{id:`net-split-f3cbcac420d93ece`,terminals:[{instanceId:`GND2`,pinName:`0`},{instanceId:`VINP`,pinName:`-`}]}],connectivityEvidence:[{id:`connectivity-evidence-33dd40c74ee1950d`,kind:`name-claim`,netId:`net-split-a810f1946a2e3084`,name:`0`,owner:{kind:`power-marker`,objectId:`GND1`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-4fd51303c6ed3225`,kind:`name-claim`,netId:`net-split-f3cbcac420d93ece`,name:`0`,owner:{kind:`power-marker`,objectId:`GND2`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-97019202b6a994e5`,kind:`name-claim`,netId:`net-power-gnd3`,name:`0`,owner:{kind:`power-marker`,objectId:`GND3`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-d2bb87eae3b4a1c5`,kind:`name-claim`,netId:`net-power-gnd4`,name:`0`,owner:{kind:`power-marker`,objectId:`GND4`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-7ec67ce55c90646d`,kind:`name-claim`,netId:`net-power-gnd5`,name:`0`,owner:{kind:`power-marker`,objectId:`GND5`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-7df4b9f72a121645`,kind:`name-claim`,netId:`net-tb-vdd`,name:`vdd`,owner:{kind:`net-label`,annotationId:`net-label-tb-vdd-source-route`},scope:`local`},{id:`connectivity-evidence-f7b96bb5ab25d11a`,kind:`name-claim`,netId:`tb-ibias-net`,name:`ibias`,owner:{kind:`net-label`,annotationId:`net-label-tb-ibias-route`},scope:`local`},{id:`connectivity-evidence-ade80d1dc122d646`,kind:`name-claim`,netId:`tb-vinp-net`,name:`vinp`,owner:{kind:`net-label`,annotationId:`net-label-tb-vinp-route`},scope:`local`},{id:`connectivity-evidence-b66084c183ee210e`,kind:`name-claim`,netId:`tb-vinn-net`,name:`vinn`,owner:{kind:`net-label`,annotationId:`net-label-tb-vinn-route`},scope:`local`},{id:`connectivity-evidence-db342e0a821d20d0`,kind:`name-claim`,netId:`tb-vout-net`,name:`vout`,owner:{kind:`net-label`,annotationId:`net-label-tb-vout-route`},scope:`local`}],routes:[{id:`tb-gnd-vinn-route`,netId:`net-power-gnd3`,start:{kind:`terminal`,instanceId:`VINN`,pinName:`-`},legs:[{id:`route-leg-34fd6882297027f4`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`GND3`,pinName:`0`}},mode:`manual`}]},{id:`tb-gnd-dut-route`,netId:`net-power-gnd4`,start:{kind:`terminal`,instanceId:`GND4`,pinName:`0`},legs:[{id:`route-leg-ac185f3591d27db9`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vss`}},mode:`manual`}]},{id:`tb-gnd-cl-route`,netId:`net-power-gnd5`,start:{kind:`terminal`,instanceId:`CL`,pinName:`2`},legs:[{id:`route-leg-af02721fb438a990`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`GND5`,pinName:`0`}},mode:`manual`}]},{id:`tb-ibias-route`,netId:`tb-ibias-net`,start:{kind:`terminal`,instanceId:`IBIAS`,pinName:`-`},legs:[{id:`route-leg-9c7f13cc644db106`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`ibias`}},mode:`manual`}]},{id:`tb-vinp-route`,netId:`tb-vinp-net`,start:{kind:`terminal`,instanceId:`VINP`,pinName:`+`},legs:[{id:`route-leg-db9df07a18d56c80`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vinp`}},mode:`manual`}]},{id:`tb-vinn-route`,netId:`tb-vinn-net`,start:{kind:`terminal`,instanceId:`VINN`,pinName:`+`},legs:[{id:`route-leg-42de77b6b7306ba2`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vinn`}},mode:`manual`}]},{id:`tb-vout-route`,netId:`tb-vout-net`,start:{kind:`terminal`,instanceId:`XDUT`,pinName:`vout`},legs:[{id:`route-leg-9cbad225568967f9`,to:{kind:`bend`,bendId:`route-bend-9cbad225568967f9`,position:{x:730,y:320}},mode:`manual`},{id:`route-leg-9cbad12556896646`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`CL`,pinName:`1`}},mode:`manual`}]},{id:`route-ui-1`,netId:`net-split-a810f1946a2e3084`,start:{kind:`terminal`,instanceId:`GND1`,pinName:`0`},legs:[{id:`route-leg-ace29482c237b3d7`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`VDD`,pinName:`-`}},mode:`manual`}]},{id:`route-35e042e11550de52`,netId:`net-split-f3cbcac420d93ece`,start:{kind:`terminal`,instanceId:`GND2`,pinName:`0`},legs:[{id:`route-leg-94c48a25d3985fe6`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`VINP`,pinName:`-`}},mode:`manual`}]},{id:`route-ui-3`,netId:`net-tb-vdd`,start:{kind:`terminal`,instanceId:`VDD`,pinName:`+`},legs:[{id:`route-leg-950eb45aec291af5`,to:{kind:`endpoint`,endpoint:{kind:`junction`,junctionId:`junction-canonical-fa66a02887bbb6d9`}},mode:`manual`}]},{id:`tb-vdd-dut-route-a-2`,netId:`net-tb-vdd`,start:{kind:`junction`,junctionId:`junction-canonical-fa66a02887bbb6d9`},legs:[{id:`route-leg-624f4d1edaa3951c`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`IBIAS`,pinName:`+`}},mode:`manual`}]},{id:`tb-vdd-dut-route-b-2`,netId:`net-tb-vdd`,start:{kind:`junction`,junctionId:`junction-canonical-fa66a02887bbb6d9`},legs:[{id:`route-leg-c64a8aa78eb2d60f`,to:{kind:`bend`,bendId:`route-bend-624f4d1edaa3951c`,position:{x:590,y:160}},mode:`manual`},{id:`route-leg-624f4e1edaa396cf`,to:{kind:`endpoint`,endpoint:{kind:`terminal`,instanceId:`XDUT`,pinName:`vdd`}},mode:`manual`}]}],junctions:[{id:`junction-canonical-fa66a02887bbb6d9`,netId:`net-tb-vdd`,position:{x:550,y:160},role:`branch`}],annotations:[{id:`instance-label-XDUT`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`XDUT`},anchor:{kind:`object`,objectId:`XDUT`,localOffset:{x:55,y:80},fallbackPosition:{x:615,y:400}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-VDD`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`VDD`},anchor:{kind:`object`,objectId:`VDD`,localOffset:{x:-30,y:-45},fallbackPosition:{x:460,y:115}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-value-VDD`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`VDD`},anchor:{kind:`object`,objectId:`VDD`,localOffset:{x:10,y:-45},fallbackPosition:{x:500,y:115}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-VINP`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`VINP`},anchor:{kind:`object`,objectId:`VINP`,localOffset:{x:-25,y:-35},fallbackPosition:{x:375,y:265}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-value-VINP`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`VINP`},anchor:{kind:`object`,objectId:`VINP`,localOffset:{x:20,y:-35},fallbackPosition:{x:420,y:265}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-VINN`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`VINN`},anchor:{kind:`object`,objectId:`VINN`,localOffset:{x:-20,y:40},fallbackPosition:{x:380,y:390}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-value-VINN`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`VINN`},anchor:{kind:`object`,objectId:`VINN`,localOffset:{x:25,y:40},fallbackPosition:{x:425,y:390}},alignment:`middle`,rotation:0,locked:!1},{id:`instance-label-IBIAS`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`IBIAS`},anchor:{kind:`object`,objectId:`IBIAS`,localOffset:{x:-50,y:-5},fallbackPosition:{x:500,y:205}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-IBIAS`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`IBIAS`},anchor:{kind:`object`,objectId:`IBIAS`,localOffset:{x:-50,y:20},fallbackPosition:{x:500,y:230}},alignment:`start`,rotation:0,locked:!1},{id:`instance-label-CL`,kind:`instance-label`,binding:{kind:`instance-reference`,instanceId:`CL`},anchor:{kind:`object`,objectId:`CL`,localOffset:{x:20,y:-5},fallbackPosition:{x:750,y:355}},alignment:`start`,rotation:0,locked:!1},{id:`instance-value-CL`,kind:`instance-value`,binding:{kind:`instance-value`,instanceId:`CL`},anchor:{kind:`object`,objectId:`CL`,localOffset:{x:45,y:-5},fallbackPosition:{x:775,y:355}},alignment:`start`,rotation:0,locked:!1},{id:`net-label-tb-vout-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-vout-net`},anchor:{kind:`route`,routeId:`tb-vout-route`,legId:`route-leg-9cbad225568967f9`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:685,y:310}},netId:`tb-vout-net`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-vdd-source-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`net-tb-vdd`},anchor:{kind:`route`,routeId:`route-ui-3`,legId:`route-leg-950eb45aec291af5`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:530,y:150}},netId:`net-tb-vdd`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-ibias-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-ibias-net`},anchor:{kind:`route`,routeId:`tb-ibias-route`,legId:`route-leg-9c7f13cc644db106`,t:.5,normalOffset:14,direction:`forward`,orientation:`follow`,fallbackPosition:{x:536,y:240}},netId:`tb-ibias-net`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-vinp-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-vinp-net`},anchor:{kind:`route`,routeId:`tb-vinp-route`,legId:`route-leg-db9df07a18d56c80`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:450,y:290}},netId:`tb-vinp-net`,alignment:`middle`,rotation:0,locked:!1},{id:`net-label-tb-vinn-route`,kind:`net-label`,binding:{kind:`net-name`,netId:`tb-vinn-net`},anchor:{kind:`route`,routeId:`tb-vinn-route`,legId:`route-leg-42de77b6b7306ba2`,t:.5,normalOffset:-10,direction:`forward`,orientation:`follow`,fallbackPosition:{x:450,y:340}},netId:`tb-vinn-net`,alignment:`middle`,rotation:0,locked:!1}],presentation:{styleProfileId:`razavi-textbook-v1`,grid:10,compactness:`normal`},layoutGroups:[],constraints:[],noConnects:[],drafting:{objects:[]}}],externalSubcircuitDefinitions:[{id:`external-subcircuit-e5ee3d17d0c7c89a`,name:`sky130_fd_pr__nfet_01v8`,terminals:[{id:`external-subcircuit-terminal-353df4da271bcc2b`,name:`D`,direction:`passive`},{id:`external-subcircuit-terminal-353df3da271bca78`,name:`G`,direction:`passive`},{id:`external-subcircuit-terminal-353df6da271bcf91`,name:`S`,direction:`passive`},{id:`external-subcircuit-terminal-353df5da271bcdde`,name:`B`,direction:`passive`}],formalParameters:[{name:`w`,defaultValue:`1`},{name:`l`,defaultValue:`0.15`},{name:`nf`,defaultValue:`1`},{name:`m`,defaultValue:`1`}],interfaceStatus:`declared`},{id:`external-subcircuit-27f716b14d59fc10`,name:`sky130_fd_pr__pfet_01v8`,terminals:[{id:`external-subcircuit-terminal-7921a0096089118d`,name:`D`,direction:`passive`},{id:`external-subcircuit-terminal-79219f0960890fda`,name:`G`,direction:`passive`},{id:`external-subcircuit-terminal-79219e0960890e27`,name:`S`,direction:`passive`},{id:`external-subcircuit-terminal-79219d0960890c74`,name:`B`,direction:`passive`}],formalParameters:[{name:`w`,defaultValue:`1`},{name:`l`,defaultValue:`0.15`},{name:`nf`,defaultValue:`1`},{name:`m`,defaultValue:`1`}],interfaceStatus:`declared`}],simulationFolders:[{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`OTA OP, DC, AC, and TRAN
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vout) v(ibias) v('XDUT:tail') v('XDUT:nleft')
analysis bias op
alter instance("VINP") type="dc"
sweep input instance="VINP" parameter="dc" from=0.88 to=0.92 step=0.005
analysis transfer op
// Restore the Canvas source after DC, before subsequent analyses.
alter instance("VINP") type="pulse" dc=0.9
analysis frequency ac from=1 to=1000000000 mode="dec" points=10
analysis signal tran stop=0.000004 step=2e-8 maxstep=2e-8
postprocess(PYTHON,"report.py","simulation-setup-ota-op-ac")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-43c930b6671663fa`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-op-ac`,name:`OTA OP, DC, AC, and TRAN`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`Complete OP, DC, AC, TRAN, and Noise (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vout) v(vinp) v(ibias) v('XDUT:tail') v('XDUT:nleft') i(VDD)
save p('XDUT:XM1:msky130_fd_pr__nfet_01v8',id) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vgs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vds) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vbs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gm) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gds) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gmbs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vth) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vdsat)
save p('XDUT:XM3:msky130_fd_pr__pfet_01v8',id) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vgs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vds) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vbs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gm) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gds) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gmbs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vth) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vdsat)
analysis bias op
// Device parameters are OP-only; do not repeat them in waveform records.
clear saves
save v(vout) v(vinp) v(ibias) v('XDUT:tail') v('XDUT:nleft') i(VDD)
alter instance("VINP") type="dc"
sweep input instance="VINP" parameter="dc" from=0.86 to=0.94 step=0.001
analysis transfer op
// Restore the Canvas source after DC, before subsequent analyses.
alter instance("VINP") type="pulse" dc=0.9
analysis frequency ac from=1 to=1000000000 mode="dec" points=40
analysis signal tran stop=0.000006 step=1e-8 maxstep=1e-8
analysis spectrum noise out="vout" in="VINP" from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-full-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-d19fdea80ac3cc0e`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-full-tt`,name:`Complete OP, DC, AC, TRAN, and Noise (TT)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`Bias point (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vout) v(vinp) v(ibias) v('XDUT:tail') v('XDUT:nleft') i(VDD)
save p('XDUT:XM1:msky130_fd_pr__nfet_01v8',id) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vgs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vds) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vbs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gm) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gds) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gmbs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vth) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vdsat)
save p('XDUT:XM3:msky130_fd_pr__pfet_01v8',id) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vgs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vds) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vbs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gm) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gds) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gmbs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vth) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vdsat)
analysis bias op
postprocess(PYTHON,"report.py","simulation-setup-ota-bias-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-54bc9080fdbafada`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-bias-tt`,name:`Bias point (TT)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`DC transfer (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vout) v(vinp) v('XDUT:tail')
alter instance("VINP") type="dc"
sweep input instance="VINP" parameter="dc" from=0.86 to=0.94 step=0.001
analysis transfer op
// Restore the Canvas source after DC, before subsequent analyses.
alter instance("VINP") type="pulse" dc=0.9
postprocess(PYTHON,"report.py","simulation-setup-ota-dc-transfer-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-aff95ba8645ee65e`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-dc-transfer-tt`,name:`DC transfer (TT)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`AC response (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis frequency ac from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-ac-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-33a7174fa9bb1375`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-ac-tt`,name:`AC response (TT)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`AC response (FF)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=ff
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis frequency ac from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-ac-ff")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-87bfa2a46e9c045d`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-ac-ff`,name:`AC response (FF)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`AC response (SS)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=ss
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis frequency ac from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-ac-ss")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-069b639e7112bc97`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-ac-ss`,name:`AC response (SS)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`AC response (FS)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=fs
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis frequency ac from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-ac-fs")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-ec8f1ab14b4220c4`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-ac-fs`,name:`AC response (FS)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`AC response (SF)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=sf
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis frequency ac from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-ac-sf")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-cdf48a82b77553de`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-ac-sf`,name:`AC response (SF)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`Transient PULSE step (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis signal tran stop=0.000006 step=1e-8 maxstep=1e-8
postprocess(PYTHON,"report.py","simulation-setup-ota-tran-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-bbdb56d73eaee0ba`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-tran-tt`,name:`Transient PULSE step (TT)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`Noise response (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vout) v(vinp) v(ibias) v('XDUT:tail') v('XDUT:nleft') i(VDD)
analysis spectrum noise out="vout" in="VINP" from=1 to=1000000000 mode="dec" points=40
postprocess(PYTHON,"report.py","simulation-setup-ota-noise-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-f167697fe57752f8`,path:`circuit.spice`,documentId:`document-ota-5t-testbench`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-noise-tt`,name:`Noise response (TT)`},{version:4,input:{kind:`source`,entry:`run.cir`,configPath:`experiment.json`,files:[{path:`run.cir`,text:`Transient SIN response (TT)
// Native BSIM4 4.8.3 candidate; historical ngspice acceptance is separate.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis signal tran stop=0.000005 step=5e-9 maxstep=5e-9
postprocess(PYTHON,"report.py","simulation-setup-ota-tran-sin-tt")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable reports for the twelve Library OTA experiments.

Native source owns the analyses. This file owns explicit numerical calculations,
not a second JSON experiment protocol. Mean/RMS use time-weighted trapezoids;
sampling/window endpoints use linear interpolation, as in the original lab.
"""
from math import log10, sqrt
from pathlib import Path
import sys

from native_report import read_ascii, sample
from icm_reports import report_measurement, report_plot


def window(data, start, stop):
    time, values = data["time"], data["vout"]
    pairs = [(start, sample(time, values, start))]
    pairs += [(t, v) for t, v in zip(time, values) if start < t < stop]
    pairs += [(stop, sample(time, values, stop))]
    return pairs


def statistic(data, kind, start, stop):
    pairs = window(data, start, stop)
    values = [v for _, v in pairs]
    if kind == "pp":
        return max(values) - min(values)
    power = 2 if kind == "rms" else 1
    integral = sum((t1 - t0) * (v0**power + v1**power) / 2
                   for (t0, v0), (t1, v1) in zip(pairs, pairs[1:]))
    mean = integral / (stop - start)
    return sqrt(mean) if power == 2 else mean


def write_plot(path, analysis, axis, values, probes, complex_data=False):
    # The axis is a column, not a probe. A dict preserves the authored order.
    names = list(values)
    count = len(next(iter(values.values())))
    lines = ["Title: Library OTA derived result", "Date: Current run",
             f"Plotname: {analysis} derived", "Flags: complex" if complex_data else "Flags: real",
             f"No. Variables: {len(names)}", f"No. Points: {count}", "Variables:"]
    lines += [f"{i} {name} notype" for i, name in enumerate(names)]
    lines += ["Values:"]
    for row in range(count):
        for col, name in enumerate(names):
            value = values[name][row]
            token = f"{value.real:.17e},{value.imag:.17e}" if complex_data else f"{value:.17e}"
            lines.append((f"{row} " if col == 0 else " ") + token)
    Path(path).write_text("\\n".join(lines) + "\\n")
    axis_spec = {"name": axis, "quantity": "voltage", "unit": "V"} if analysis == "dc" else axis
    report_plot(path, analysis, axis=axis_spec, probes=probes)


mode = sys.argv[1].removeprefix("simulation-setup-ota-")
full = mode == "full-tt"
if mode == "op-ac":
    # Historical four-analysis acceptance has no scalar/derived requests.
    sys.exit(0)

if full or mode == "bias-tt":
    data = read_ascii("bias.raw")
    report_measurement("measure-vout-op", lambda: data["vout"][0], "V")
    if not full:
        report_measurement("measure-supply-current-op", lambda: -data["VDD:flow(br)"][0], "A")

if full or mode == "dc-transfer-tt":
    data = read_ascii("transfer.raw")
    output = data["vout"]
    report_measurement("measure-dc-min" if full else "measure-vout-min", lambda: min(output), "V")
    if not full:
        report_measurement("measure-vout-max", lambda: max(output), "V")
        report_measurement("measure-vout-pp", lambda: max(output) - min(output), "V")
        report_measurement("measure-vout-at-balance", lambda: sample(data["vinp"], output, 0.9), "V")

if full or mode.startswith("ac-"):
    data = read_ascii("frequency.raw")
    frequency = [v.real for v in data["frequency"]]
    gain = [out / inp for inp, out in zip(data["vinp"], data["vout"])]
    db = [20 * log10(abs(v)) for v in gain]
    write_plot("gain.raw", "ac", "frequency", {"frequency": frequency, "Gain": gain},
               [{"name": "Gain", "quantity": "transfer", "unit": "1"}], True)
    report_measurement("measure-ac-gain-1k" if full else f"measure-gain-1k-{mode[-2:]}",
                       lambda: sample(frequency, db, 1e3), "dB")
    if not full:
        report_measurement(f"measure-gain-max-{mode[-2:]}", lambda: max(db), "dB")

if full or mode in ("tran-tt", "tran-sin-tt"):
    data = read_ascii("signal.raw")
    stop = 4e-6 if full else 5e-6 if mode == "tran-sin-tt" else 6e-6
    prefix = "measure-tran-" if full else "measure-vout-"
    for kind in (["pp", "rms"] if mode == "tran-sin-tt" else ["pp", "mean", "rms"]):
        report_measurement(prefix + kind, lambda kind=kind: statistic(data, kind, 1e-6, stop), "V")

if full or mode == "noise-tt":
    data = read_ascii("spectrum.raw")
    frequency = data["frequency"]
    output = [sqrt(v) for v in data["onoise"]]
    report_measurement("measure-noise-1k" if full else "measure-output-noise-1k",
                       lambda: sample(frequency, output, 1e3), "V/sqrt(Hz)")
    if not full:
        input_density = [sqrt(v / gain) for v, gain in zip(data["onoise"], data["gain"])]
        report_measurement("measure-input-noise-1k", lambda: sample(frequency, input_density, 1e3), "V/sqrt(Hz)")

# Sign-converted supply current is an explicit derived trace, never a renamed
# negative native current. Native raw records remain available as evidence.
if full or mode == "bias-tt":
    for path, analysis, axis in [("bias.raw", "op", "op"), ("transfer.raw", "dc", "VINP"),
                                 ("frequency.raw", "ac", "frequency"), ("signal.raw", "tran", "time")]:
        if not Path(path).exists():
            continue
        data = read_ascii(path)
        # Native OP/DC independent-variable names come from the raw record.
        if analysis == "dc":
            axis = next(iter(data))
        elif analysis == "op":
            axis = None
        values = {axis: data[axis]} if axis else {}
        values["I_supply"] = [-v for v in data["VDD:flow(br)"]]
        write_plot(f"supply-{analysis}.raw", analysis, axis,
                   values,
                   [{"name": "I_supply", "quantity": "current", "unit": "A"}], analysis == "ac")
`},{path:`native_report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],circuitBindings:[{id:`simulation-circuit-binding-8730ec75dc5400cd`,path:`circuit.spice`,documentId:`document-ota-5t-testbench-sin`,emission:`top-level`}],dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}]},id:`simulation-setup-ota-tran-sin-tt`,name:`Transient SIN response (TT)`}]},o=new WeakMap;function s(t){let n=o.get(t);return n||(n=e(JSON.stringify(t)),o.set(t,n)),n}var c=[{id:`common-source-amplifier`,name:`Common-Source Amplifier`,description:`Small-signal NMOS gain stage`,get project(){return s(t)}},{id:`two-stage-op-amp`,name:`Two-Stage Op Amp`,description:`Miller-compensated amplifier`,get project(){return s(i)}},{id:`current-mirror-loaded-differential-pair`,name:`Current-Mirror-Loaded Differential Pair`,description:`NMOS differential pair with PMOS active load`,get project(){return s(n)}},{id:`fully-differential-two-stage-op-amp`,name:`Fully Differential Two-Stage Op Amp`,description:`Differential CMOS amplifier with capacitive loads`,get project(){return s(r)}},{id:`five-transistor-ota-sky130`,name:`Five-Transistor OTA (Sky130)`,description:`Full OP/DC/AC/TRAN/Noise lab with PULSE/SIN testbenches and five corners`,get project(){return s(a)}}];function l(e){let t=c.find(t=>t.id===e);return t?structuredClone(t.project):null}export{l as createLibraryExampleProject,c as libraryProjectExamples};