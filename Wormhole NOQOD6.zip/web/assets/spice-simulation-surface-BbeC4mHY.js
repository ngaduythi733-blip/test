import{n as e,t}from"./jsx-runtime-DE3RlOCf.js";import{k as n}from"./index-DbKWkCHr.js";import{n as r}from"./dist-weBOQ2AN.js";import{d as i,tn as a,vt as o,zt as s}from"./dist-CXCCAyu0.js";import{t as c}from"./profile-Cv2CJCWc.js";import{yt as l}from"./dist-BzjQmGJH.js";import{B as u,C as d,F as f,G as p,H as m,I as h,J as g,L as _,M as v,R as y,S as b,U as x,V as S,W as ee,X as C,Y as w,Z as T,_ as te,a as ne,b as re,c as ie,d as ae,f as E,g as oe,h as se,i as D,it as O,l as ce,m as k,n as le,r as A,s as ue,st as de,u as fe,w as j,x as M}from"./dist-CHZWujiQ.js";import{r as pe,t as me}from"./cache-D_Uf2VWM.js";import{a as N,r as he}from"./dist-BjwS3kgu.js";import{i as ge,n as _e,r as ve}from"./dist-JQKb3MsQ.js";import{a as ye,b as be,c as xe,d as Se,i as Ce,l as we,o as Te,p as P,u as F}from"./recovery-coordinator-GUht6Rb5.js";import{$ as I,Q as Ee,W as De,et as L,tt as Oe}from"./files-CsUIrzgs.js";import{A as R,D as z,E as ke,F as B,I as Ae,J as je,K as Me,L as Ne,R as V,S as H,X as U,Z as W,_ as Pe,a as G,b as K,c as q,d as Fe,f as Ie,i as Le,j as Re,k as ze,l as J,m as Be,n as Ve,nt as He,o as Ue,p as We,r as Ge,rt as Y,s as Ke,t as qe,tt as Je,u as Ye,v as Xe,w as Ze,x as Qe,y as $e,z as et}from"./dist-D_Akw6f6.js";import{a as tt,c as nt,i as rt,l as it,n as at,o as ot,r as st,s as ct,t as lt}from"./code-spice-language-ryVuJi2t.js";import{n as ut,t as dt}from"./dist-zaLaQ_4V.js";import{t as ft}from"./source-presentation-CYOMBYcK.js";import{c as pt,d as mt,f as ht,l as gt,o as _t,r as vt,s as yt,t as bt,u as xt}from"./simulation-run-archive-mEpSOnOW.js";import{n as St}from"./browser-simulation-archive-store-DRLDVzYU.js";function Ct(e,t,n,r){let i=e.includes(`\r
`)?`\r
`:`
`,a=e.lastIndexOf(`
`,Math.max(0,t-1))+1,o=e.indexOf(`
`,t),s=o<0?e.length:o,c=e.slice(a,s).replace(/\r$/u,``);if(/^\s*\.?save(?:\s|$)/iu.test(c)){let e=n.filter(e=>!c.toLowerCase().split(/\s+/u).includes(e.toLowerCase()));return{from:a+c.length,insert:e.length?` `+e.join(` `):``}}let l=/^\s*\.control[^\r\n]*(?:\r?\n|$)/imu.exec(e),u=l?l.index+l[0].length:r?e.indexOf(`
`)<0?e.length:e.indexOf(`
`)+1:0;return{from:u,insert:(u>0&&e[u-1]!==`
`?i:``)+`${l?`save`:`.save`} ${n.join(` `)}${i}`}}function wt(e,t,n,r,i=[]){let a=e.includes(`\r
`)?`\r
`:`
`,o=new Set(e.split(/\r?\n/u).map(e=>e.trim().toLowerCase())),s=i.filter(e=>!o.has(e.toLowerCase())),c=e,l=t,u=[];if(s.length){let i=r?e.indexOf(`
`)<0?e.length:e.indexOf(`
`)+1:0,o=(i>0&&e[i-1]!==`
`?a:``)+s.join(a)+a;u.push({from:i,insert:o}),c=e.slice(0,i)+o+e.slice(i),l=t>=i?t+o.length:t,n.length||(l=i+o.length)}if(n.length){let e=Ct(c,l,n,r);e.insert&&u.push(e),c=c.slice(0,e.from)+e.insert+c.slice(e.from),l=e.from+e.insert.replace(/[\r\n]+$/u,``).length}return{ok:!0,text:c,anchor:l,changes:u}}function Tt(e,t){let n=e.includes(`\r
`)?`\r
`:`
`,r=e.indexOf(`
`),i=t?r<0?e.length:r+1:0,a=`${t&&r<0?`${e?``:`Simulation`}${n}`:``}parameters `,o=`${a}${n}`;return{text:e.slice(0,i)+o+e.slice(i),changes:[{from:i,to:i,insert:o}],anchor:i+a.length}}var X=t(),Et={idle:`Connect Agent`,creating:`Connecting Agent`,"waiting-for-agent":`Waiting for Agent`,connected:`Agent connected`,working:`Agent working`,paused:`Agent paused`,reconnecting:`Agent reconnecting`,offline:`Agent offline`,revoked:`Connect Agent`,expired:`Connect Agent`},Dt={idle:{label:`Agent not connected`,hint:`Connect an Agent to get started.`,action:`Connect Agent`,icon:`○`},creating:{label:`Connecting Agent`,hint:`Preparing your connection information…`,action:`Connecting…`,icon:`…`},"waiting-for-agent":{label:`Waiting for Agent`,hint:`Paste the connection message into your Agent chat.`,action:`View connection info`,icon:`…`},connected:{label:`Agent connected`,hint:`Tell your Agent your simulation goal.`,action:`Connection details`,icon:`✓`},working:{label:`Agent working`,hint:`Your Agent is processing a request.`,action:`Connection details`,icon:`…`},paused:{label:`Agent paused`,hint:`Open connection details to resume.`,action:`Connection details`,icon:`Ⅱ`},reconnecting:{label:`Agent reconnecting`,hint:`Restoring the existing connection…`,action:`Connection details`,icon:`…`},offline:{label:`Agent offline`,hint:`Check the connection to continue.`,action:`Connection details`,icon:`!`},revoked:{label:`Agent disconnected`,hint:`Reconnect an Agent to continue.`,action:`Reconnect Agent`,icon:`!`},expired:{label:`Agent connection expired`,hint:`Reconnect an Agent to continue.`,action:`Reconnect Agent`,icon:`!`}};function Ot({status:e,onOpen:t,onManualSetup:n}){let r=Dt[e];return(0,X.jsxs)(`section`,{className:`simulation-agent-start`,"aria-label":`Agent simulation guide`,"data-agent-status":e,children:[(0,X.jsxs)(`h2`,{children:[`Simulate with an Agent`,` `,(0,X.jsx)(`span`,{className:`simulation-agent-recommended`,children:`(recommended)`})]}),(0,X.jsxs)(`div`,{className:`simulation-agent-start-status`,role:`status`,"aria-atomic":`true`,children:[(0,X.jsx)(`span`,{className:`simulation-agent-start-icon`,"aria-hidden":`true`,children:r.icon}),(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`strong`,{children:r.label}),(0,X.jsx)(`p`,{children:r.hint})]})]}),(0,X.jsxs)(`ol`,{className:`simulation-agent-steps`,children:[(0,X.jsxs)(`li`,{children:[(0,X.jsx)(`strong`,{children:`Connect your Agent`}),(0,X.jsxs)(`p`,{children:[`Click `,(0,X.jsx)(`b`,{children:`Connect Agent`}),` and paste the connection message into your Agent chat.`]})]}),(0,X.jsxs)(`li`,{children:[(0,X.jsx)(`strong`,{children:`Describe your goal`}),(0,X.jsx)(`p`,{children:`Tell your Agent what to test. It can configure sources, analyses, and signals to capture.`})]}),(0,X.jsxs)(`li`,{children:[(0,X.jsx)(`strong`,{children:`Review the results`}),(0,X.jsx)(`p`,{children:`Your Agent can run the simulation and explain the findings. View plots, measurements, and run history here.`})]})]}),(0,X.jsxs)(`div`,{className:`simulation-agent-start-actions`,children:[(0,X.jsx)(`button`,{className:`simulation-agent-start-primary`,type:`button`,disabled:e===`creating`,onClick:t,children:r.action}),(0,X.jsx)(`button`,{className:`simulation-agent-start-manual`,type:`button`,onClick:n,children:`Set up manually`})]})]})}function kt({status:e,onOpen:t}){let n=e===`connected`?`Tell your Agent your simulation goal`:e===`idle`||e===`revoked`||e===`expired`?`Let an Agent help configure, run and analyze`:``;return(0,X.jsxs)(`div`,{className:`simulation-agent-guidance`,"data-agent-status":e,children:[(0,X.jsx)(`span`,{className:`simulation-agent-hint`,"aria-hidden":`true`,children:n}),(0,X.jsxs)(`button`,{type:`button`,onClick:t,title:n||`${Et[e]} — manage connection`,children:[(0,X.jsx)(`span`,{className:`simulation-agent-dot`,"aria-hidden":`true`}),Et[e]]})]})}var Z=e(),At=n(),jt=(0,Z.createContext)(null);function Mt(){let e=(0,Z.useContext)(jt);if(!e)throw Error(`Workspace interactions require their provider`);return e}function Nt({children:e}){let[t,n]=(0,Z.useState)(),r=(0,Z.useRef)(0),i=(0,Z.useRef)(void 0),[a,o]=(0,Z.useState)(),s=(0,Z.useRef)(void 0),[c,l]=(0,Z.useState)(),u=(0,Z.useRef)(null),d=(0,Z.useRef)(null),f=(0,Z.useRef)(null),p=()=>{u.current?.isConnected&&u.current.focus()},m=(e=!1)=>{l(void 0),e&&p()},h=(e,r=!1)=>{let a=i.current;i.current=void 0,n(void 0),a?.(e),r&&t&&requestAnimationFrame(()=>{((t.kind===`folder`?e?document.querySelector(`[aria-label="${CSS.escape(`Folder ${e.name}`)}"]`):document.querySelector(`[data-folder-id="${CSS.escape(t.folderId??``)}"][data-tree-row="folder"]`):document.querySelector(`[data-folder-id="${CSS.escape(t.folderId??``)}"][data-file-path="${CSS.escape(e?.name??t.path??``)}"]`))??document.querySelector(`[data-workspace-new-folder]`))?.focus()})},g=e=>{s.current?.(e),s.current=void 0,o(void 0),p()};return(0,Z.useEffect)(()=>()=>{i.current?.(null),s.current?.(!1)},[]),(0,Z.useLayoutEffect)(()=>{if(!c||!d.current)return;let e=d.current,t=e.getBoundingClientRect();e.style.left=`${Math.max(4,Math.min(c.x,window.innerWidth-t.width-4))}px`,e.style.top=`${Math.max(4,Math.min(c.y,window.innerHeight-t.height-4))}px`,e.querySelector(`button:not(:disabled)`)?.focus();let n=t=>{e.contains(t.target)||m()},r=()=>m();return document.addEventListener(`pointerdown`,n,!0),window.addEventListener(`resize`,r),window.addEventListener(`blur`,r),()=>{document.removeEventListener(`pointerdown`,n,!0),window.removeEventListener(`resize`,r),window.removeEventListener(`blur`,r)}},[c]),(0,Z.useEffect)(()=>{a&&(f.current?.showModal(),f.current?.querySelector(`button`)?.focus())},[a]),(0,X.jsxs)(jt.Provider,{value:{edit:t,finishName:h,closeMenu:m,name:e=>(h(null),m(),n({...e,requestId:++r.current}),new Promise(e=>{i.current=e})),confirm:e=>(h(null),m(),s.current?.(!1),u.current=document.activeElement,o(e),new Promise(e=>{s.current=e})),menu:(e,t,n,r=`Workspace actions`)=>{u.current=document.activeElement,l({x:e,y:t,items:n,label:r})}},children:[e,c?(0,At.createPortal)((0,X.jsx)(`div`,{ref:d,role:`menu`,"aria-label":c.label,"data-workspace-interaction":`true`,className:`workspace-context-menu`,style:{left:c.x,top:c.y},onContextMenu:e=>e.preventDefault(),onKeyDown:e=>{if(e.stopPropagation(),(e.key===`Escape`||e.key===`Tab`)&&(e.preventDefault(),m(!0)),[`ArrowDown`,`ArrowUp`,`Home`,`End`].includes(e.key)){e.preventDefault();let t=[...e.currentTarget.querySelectorAll(`button:not(:disabled)`)],n=t.indexOf(document.activeElement);t[e.key===`Home`?0:e.key===`End`?t.length-1:(n+(e.key===`ArrowDown`?1:-1)+t.length)%t.length]?.focus()}},children:c.items.map(e=>(0,X.jsx)(`button`,{type:`button`,role:`menuitem`,disabled:e.disabled,onClick:()=>{m(!0),e.run()},children:e.label},e.label))}),document.body):null,a?(0,At.createPortal)((0,X.jsxs)(`dialog`,{ref:f,className:`workspace-confirm-dialog`,"data-workspace-interaction":`true`,"aria-label":a.title,onCancel:e=>{e.preventDefault(),g(!1)},onClick:e=>{e.target===e.currentTarget&&g(!1)},onKeyDown:e=>e.stopPropagation(),children:[(0,X.jsx)(`h3`,{children:a.title}),(0,X.jsx)(`p`,{children:a.message}),(0,X.jsxs)(`div`,{children:[(0,X.jsx)(`button`,{type:`button`,onClick:()=>g(!1),children:`Cancel`}),(0,X.jsx)(`button`,{type:`button`,className:`is-danger`,onClick:()=>g(!0),children:a.acceptLabel??`Delete`})]})]}),document.body):null]})}function Pt(){let e=Mt();return e.edit?(0,X.jsx)(Ft,{},e.edit.requestId):null}function Ft(){let e=Mt(),t=e.edit,[n,r]=(0,Z.useState)(t.initial),i=e=>t.profileFor?.(e)??t.profiles?.[0]?.id??``,[a,o]=(0,Z.useState)(()=>i(t.cellSelection?.initial??``)),s=(0,Z.useRef)(!1),[c,l]=(0,Z.useState)(t.cellSelection?.initial??``),[u,d]=(0,Z.useState)(),f=(0,Z.useRef)(null),p=(0,Z.useRef)(!1);(0,Z.useEffect)(()=>{f.current?.focus(),f.current?.select()},[]);let m=(r=!1,i=!1)=>{if(p.current)return;let o=n.trim(),s=!r&&o?t.validate?.(o)??t.cellSelection?.validate(c):void 0;if(s){d(s);return}p.current=!0,e.finishName(r||!o?null:{name:o,...t.cellSelection?{documentId:c}:{},...t.profiles?{profileId:a}:{}},i)};return(0,X.jsxs)(`div`,{className:`workspace-inline-name`,onContextMenu:e=>e.stopPropagation(),onBlur:e=>{e.currentTarget.contains(e.relatedTarget)||m(!!t.cellSelection)},children:[(0,X.jsx)(`input`,{ref:f,"aria-label":t.label,autoComplete:`off`,value:n,"aria-invalid":!!u,onChange:e=>{r(e.currentTarget.value),d(void 0)},onKeyDown:e=>{e.stopPropagation(),e.key===`Enter`&&!e.nativeEvent.isComposing&&(e.preventDefault(),m(!1,!0)),e.key===`Escape`&&(e.preventDefault(),m(!0,!0))}}),t.profiles&&t.profiles.length>1?(0,X.jsxs)(`label`,{children:[`Environment`,` `,(0,X.jsx)(`select`,{"aria-label":`Simulation environment`,value:a,onChange:e=>{s.current=!0,o(e.currentTarget.value)},children:t.profiles.map(e=>(0,X.jsx)(`option`,{value:e.id,children:e.name},e.id))})]}):null,t.cellSelection?(0,X.jsxs)(`div`,{className:`workspace-cell-selection`,children:[(0,X.jsx)(`label`,{htmlFor:`simulation-cell-${t.requestId}`,children:`Cell`}),(0,X.jsxs)(`select`,{id:`simulation-cell-${t.requestId}`,"aria-label":`Simulation Cell`,value:c,onChange:e=>{l(e.currentTarget.value),s.current||o(i(e.currentTarget.value)),d(void 0)},onKeyDown:e=>{e.stopPropagation(),e.key===`Escape`&&(e.preventDefault(),m(!0,!0))},children:[(0,X.jsx)(`option`,{value:``,disabled:!0,children:`Select a Cell`}),t.cellSelection.options.map(e=>(0,X.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,X.jsx)(`button`,{type:`button`,onClick:()=>m(!1,!0),children:`Create`})]}):null,u?(0,X.jsx)(`small`,{role:`status`,children:u}):null]})}var It=[{id:`rc`,name:`RC Filters`,description:`Low-pass & high-pass`,source:{documents:[{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:120,y:220},kind:`object`,localOffset:{x:20,y:10},objectId:`V1`},binding:{instanceId:`V1`,kind:`instance-reference`},id:`instance-label-V1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{kind:`free`,position:{x:125,y:275}},binding:{instanceId:`V1`,kind:`instance-value`},id:`instance-value-V1`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:305,y:225},kind:`object`,localOffset:{x:15,y:5},objectId:`C1`},binding:{instanceId:`C1`,kind:`instance-reference`},id:`instance-label-C1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:190,y:140},kind:`object`,localOffset:{x:0,y:-20},objectId:`R1`},binding:{instanceId:`R1`,kind:`instance-reference`},id:`instance-label-R1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{kind:`free`,position:{x:260,y:150}},binding:{kind:`net-name`,netId:`net-232eaf9b4907ccf7`},formatOverride:{runs:[{children:[{children:[{kind:`text`,value:`out`}],kind:`span`,style:`italic`}],kind:`span`,style:`bold`}]},id:`net-label-wire-4`,kind:`net-label`,locked:!1,netId:`net-232eaf9b4907ccf7`,rotation:0,sizeScale:1}],connectivityEvidence:[{id:`connectivity-evidence-d92e0a448bb319cd`,kind:`net-name-hint`,netId:`net-3cc118a1672a4767`,origin:`spice-import`,sourceName:`in`},{id:`connectivity-evidence-7ae98d9e91d374ad`,kind:`spice-source`,netId:`net-3cc118a1672a4767`,sourceNetId:`net-3cc118a1672a4767`},{id:`connectivity-evidence-c3026f25e0803bdb`,kind:`name-claim`,name:`0`,netId:`net-89e480092dc336ed`,owner:{kind:`global-declaration`,sourceNetId:`net-89e480092dc336ed`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-08b4f29c97880525`,kind:`spice-source`,netId:`net-89e480092dc336ed`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-617050b36c8b4149`,kind:`net-name-hint`,netId:`net-232eaf9b4907ccf7`,origin:`spice-import`,sourceName:`out`},{id:`connectivity-evidence-e5eb74d8864ce135`,kind:`spice-source`,netId:`net-232eaf9b4907ccf7`,sourceNetId:`net-232eaf9b4907ccf7`},{id:`connectivity-evidence-48a18744e815b771`,kind:`name-claim`,name:`out`,netId:`net-232eaf9b4907ccf7`,owner:{annotationId:`net-label-wire-4`,kind:`net-label`},scope:`local`}],constraints:[],drafting:{objects:[{alignment:`start`,anchor:{kind:`free`,position:{x:45,y:50}},content:{runs:[{children:[{kind:`text`,value:`RC low-pass: R = 10 kohm, C = 10 nF`}],kind:`span`,style:`bold`}]},id:`description-0`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:45,y:85}},content:{runs:[{children:[{kind:`text`,value:`Expected fc = 1591.55 Hz; tau = 100 us.`}],kind:`span`,style:`bold`}]},id:`description-1`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0}]},id:`cell-rc-lowpass`,instances:[{id:`V1`,importProvenance:{kind:`primitive`,sourceMasterName:`voltage-source`,sourceTarget:`primitive:voltage-source`,status:`resolved`,terminalMapping:[{pinName:`+`,sourcePosition:0},{pinName:`-`,sourcePosition:1}]},netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{acMagnitude:`1`,dc:`0`,delay:`100u`,fall:`100n`,high:`1`,low:`0`,period:`4m`,rise:`100n`,waveform:`pulse`,width:`2m`}},placement:{mirror:`none`,position:{x:100,y:210},rotation:0},reference:`V1`,sourceRef:{end:{column:10,line:2,offset:90},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:81}},symbolId:`voltage-source`},{id:`R1`,importProvenance:{kind:`primitive`,sourceMasterName:`resistor`,sourceTarget:`primitive:resistor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`resistor`,kind:`primitive`},parameters:{value:`10k`}},placement:{mirror:`none`,position:{x:190,y:160},rotation:270},reference:`R1`,sourceRef:{end:{column:14,line:3,offset:104},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:3,offset:91}},symbolId:`resistor`},{id:`C1`,importProvenance:{kind:`primitive`,sourceMasterName:`capacitor`,sourceTarget:`primitive:capacitor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`10n`}},placement:{mirror:`none`,position:{x:290,y:220},rotation:0},reference:`C1`,sourceRef:{end:{column:13,line:4,offset:117},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:4,offset:105}},symbolId:`capacitor`},{id:`GND1`,placement:{mirror:`none`,position:{x:100,y:260},rotation:0},symbolId:`ground`},{id:`GND2`,placement:{mirror:`none`,position:{x:290,y:260},rotation:0},symbolId:`ground`}],junctions:[],layoutGroups:[],name:`RC Filters — Low-pass & High-pass`,netlist:{formalParameters:[],name:`rc_lowpass`,terminals:[]},nets:[{id:`net-3cc118a1672a4767`,terminals:[{instanceId:`V1`,pinName:`+`},{instanceId:`R1`,pinName:`1`}]},{id:`net-89e480092dc336ed`,terminals:[{instanceId:`V1`,pinName:`-`},{instanceId:`C1`,pinName:`2`},{instanceId:`GND1`,pinName:`0`},{instanceId:`GND2`,pinName:`0`}]},{id:`net-232eaf9b4907ccf7`,terminals:[{instanceId:`R1`,pinName:`2`},{instanceId:`C1`,pinName:`1`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:93,routes:[{id:`wire-2`,legs:[{id:`route-leg-cf551b7f16df69fe`,mode:`manual`,to:{bendId:`route-bend-cf551b7f16df69fe`,kind:`bend`,position:{x:100,y:160}}},{id:`route-leg-cf551c7f16df6bb1`,mode:`manual`,to:{endpoint:{instanceId:`R1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-3cc118a1672a4767`,start:{instanceId:`V1`,kind:`terminal`,pinName:`+`}},{id:`wire-4`,legs:[{id:`route-leg-1ce8331b0051cc34`,mode:`manual`,to:{bendId:`route-bend-1ce8331b0051cc34`,kind:`bend`,position:{x:290,y:160}}},{id:`route-leg-1ce8341b0051cde7`,mode:`manual`,to:{endpoint:{instanceId:`C1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-232eaf9b4907ccf7`,start:{instanceId:`R1`,kind:`terminal`,pinName:`2`}},{id:`wire-7`,legs:[{id:`route-leg-329d212cf72d2061`,mode:`manual`,to:{endpoint:{instanceId:`GND1`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`V1`,kind:`terminal`,pinName:`-`}},{id:`wire-10`,legs:[{id:`route-leg-2ec0789b797ba9c4`,mode:`manual`,to:{endpoint:{instanceId:`GND2`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`C1`,kind:`terminal`,pinName:`2`}}],sourceBinding:{cellName:`rc_lowpass`,sourceRef:{end:{column:13,line:4,offset:117},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:81}}},sourceStatus:`connectivity-modified`},{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:120,y:230},kind:`object`,localOffset:{x:20,y:10},objectId:`V1`},binding:{instanceId:`V1`,kind:`instance-reference`},id:`instance-label-V1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:320,y:230},kind:`object`,localOffset:{x:20,y:10},objectId:`R1`},binding:{instanceId:`R1`,kind:`instance-reference`},id:`instance-label-R1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:200,y:145},kind:`object`,localOffset:{x:0,y:-15},objectId:`C1`},binding:{instanceId:`C1`,kind:`instance-reference`},id:`instance-label-C1`,kind:`instance-label`,locked:!1,rotation:0}],connectivityEvidence:[{id:`connectivity-evidence-d92e0a448bb319cd`,kind:`net-name-hint`,netId:`net-3cc118a1672a4767`,origin:`spice-import`,sourceName:`in`},{id:`connectivity-evidence-7ae98d9e91d374ad`,kind:`spice-source`,netId:`net-3cc118a1672a4767`,sourceNetId:`net-3cc118a1672a4767`},{id:`connectivity-evidence-c3026f25e0803bdb`,kind:`name-claim`,name:`0`,netId:`net-89e480092dc336ed`,owner:{kind:`global-declaration`,sourceNetId:`net-89e480092dc336ed`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-08b4f29c97880525`,kind:`spice-source`,netId:`net-89e480092dc336ed`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-617050b36c8b4149`,kind:`net-name-hint`,netId:`net-232eaf9b4907ccf7`,origin:`spice-import`,sourceName:`out`},{id:`connectivity-evidence-e5eb74d8864ce135`,kind:`spice-source`,netId:`net-232eaf9b4907ccf7`,sourceNetId:`net-232eaf9b4907ccf7`}],constraints:[],drafting:{objects:[{alignment:`start`,anchor:{kind:`free`,position:{x:30,y:70}},content:{runs:[{children:[{kind:`text`,value:`RC high-pass: complementary first-order response`}],kind:`span`,style:`bold`}]},id:`description-0`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:35,y:95}},content:{runs:[{children:[{kind:`text`,value:`Expected fc = 1591.55 Hz; step response decays to zero.`}],kind:`span`,style:`bold`}]},id:`description-1`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0}]},id:`cell-rc-highpass`,instances:[{id:`V1`,importProvenance:{kind:`primitive`,sourceMasterName:`voltage-source`,sourceTarget:`primitive:voltage-source`,status:`resolved`,terminalMapping:[{pinName:`+`,sourcePosition:0},{pinName:`-`,sourcePosition:1}]},netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{acMagnitude:`1`,dc:`0`,delay:`100u`,fall:`100n`,high:`1`,low:`0`,period:`4m`,rise:`100n`,waveform:`pulse`,width:`2m`}},placement:{mirror:`none`,position:{x:100,y:220},rotation:0},reference:`V1`,sourceRef:{end:{column:10,line:2,offset:90},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:81}},symbolId:`voltage-source`},{id:`C1`,importProvenance:{kind:`primitive`,sourceMasterName:`capacitor`,sourceTarget:`primitive:capacitor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`10n`}},placement:{mirror:`none`,position:{x:200,y:160},rotation:270},reference:`C1`,sourceRef:{end:{column:14,line:3,offset:104},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:3,offset:91}},symbolId:`capacitor`},{id:`R1`,importProvenance:{kind:`primitive`,sourceMasterName:`resistor`,sourceTarget:`primitive:resistor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`resistor`,kind:`primitive`},parameters:{value:`10k`}},placement:{mirror:`none`,position:{x:300,y:220},rotation:0},reference:`R1`,sourceRef:{end:{column:13,line:4,offset:117},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:4,offset:105}},symbolId:`resistor`},{id:`GND1`,placement:{mirror:`none`,position:{x:100,y:270},rotation:0},symbolId:`ground`},{id:`GND2`,placement:{mirror:`none`,position:{x:300,y:270},rotation:0},symbolId:`ground`}],junctions:[],layoutGroups:[],name:`RC High-pass`,netlist:{formalParameters:[],name:`rc_highpass`,terminals:[]},nets:[{id:`net-3cc118a1672a4767`,terminals:[{instanceId:`V1`,pinName:`+`},{instanceId:`C1`,pinName:`1`}]},{id:`net-89e480092dc336ed`,terminals:[{instanceId:`V1`,pinName:`-`},{instanceId:`R1`,pinName:`2`},{instanceId:`GND1`,pinName:`0`},{instanceId:`GND2`,pinName:`0`}]},{id:`net-232eaf9b4907ccf7`,terminals:[{instanceId:`C1`,pinName:`2`},{instanceId:`R1`,pinName:`1`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:37,routes:[{id:`wire-14`,legs:[{id:`route-leg-cd3630e379115290`,mode:`manual`,to:{bendId:`route-bend-cd3630e379115290`,kind:`bend`,position:{x:100,y:160}}},{id:`route-leg-cd3631e379115443`,mode:`manual`,to:{endpoint:{instanceId:`C1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-3cc118a1672a4767`,start:{instanceId:`V1`,kind:`terminal`,pinName:`+`}},{id:`wire-16`,legs:[{id:`route-leg-df7ae0ff8e988c8e`,mode:`manual`,to:{bendId:`route-bend-df7ae0ff8e988c8e`,kind:`bend`,position:{x:300,y:160}}},{id:`route-leg-df7ae1ff8e988e41`,mode:`manual`,to:{endpoint:{instanceId:`R1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-232eaf9b4907ccf7`,start:{instanceId:`C1`,kind:`terminal`,pinName:`2`}},{id:`wire-19`,legs:[{id:`route-leg-81493e972e2f576b`,mode:`manual`,to:{endpoint:{instanceId:`GND1`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`V1`,kind:`terminal`,pinName:`-`}},{id:`wire-22`,legs:[{id:`route-leg-13ba028735a48d15`,mode:`manual`,to:{endpoint:{instanceId:`GND2`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`R1`,kind:`terminal`,pinName:`2`}}],sourceBinding:{cellName:`rc_highpass`,sourceRef:{end:{column:13,line:4,offset:117},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:81}}},sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[],id:`project-rc-lowpass`,name:`RC Filters — Low-pass & High-pass`,schemaVersion:51,simulationFolders:[{id:`rc-lp-ac`,input:{circuitBindings:[{documentId:`cell-rc-lowpass`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`01 Low-pass | AC
// 1. Change R or C on Canvas. Use a native VACASK Profile with Python.
// 2. Click Run.
// 3. Plot Gain in dB/phase; Measurements contains gain_at_fc.
ground 0
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10
save v(in) v(out) i(V1)
// AC is small-signal response, not an output-swing test.
analysis frequency ac from=10 to=1M mode="dec" points=80
postprocess(PYTHON, "report.py", "ac")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`01 Low-pass | AC`,version:4},{id:`rc-lp-tran`,input:{circuitBindings:[{documentId:`cell-rc-lowpass`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`02 Low-pass | Step
// 1. Change R or C on Canvas. Use a native VACASK Profile with Python.
// 2. Click Run.
// 3. Plot the step; Measurements samples at 200.05 us and 1 ms.
ground 0
include "circuit.spice"
control
abort always
// Resolve the short source ramp after its breakpoint, not just the RC decay.
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10 tran_fbr=0.025
save v(in) v(out) i(V1)
analysis step tran stop=1m step=1u maxstep=1u
postprocess(PYTHON, "report.py", "step")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`02 Low-pass | Step`,version:4},{id:`rc-hp-ac`,input:{circuitBindings:[{documentId:`cell-rc-highpass`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`03 High-pass | AC
// 1. Change R or C on Canvas. Use a native VACASK Profile with Python.
// 2. Click Run.
// 3. Plot Gain in dB/phase; Measurements contains gain_at_fc.
ground 0
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10
save v(in) v(out) i(V1)
// AC is small-signal response, not an output-swing test.
analysis frequency ac from=10 to=1M mode="dec" points=80
postprocess(PYTHON, "report.py", "ac")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`03 High-pass | AC`,version:4},{id:`rc-hp-tran`,input:{circuitBindings:[{documentId:`cell-rc-highpass`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`04 High-pass | Step
// 1. Change R or C on Canvas. Use a native VACASK Profile with Python.
// 2. Click Run.
// 3. Plot the step; Measurements samples at 200.05 us and 1 ms.
ground 0
include "circuit.spice"
control
abort always
// Resolve the short source ramp after its breakpoint, not just the RC decay.
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10 tran_fbr=0.025
save v(in) v(out) i(V1)
analysis step tran stop=1m step=1u maxstep=1u
postprocess(PYTHON, "report.py", "step")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`04 High-pass | Step`,version:4}],source:{dialect:`spice3f5-core`,entry:`circuit.spi`,files:[{hash:`sha256:d80deb453ce172a5509e37e983d40900377f5c71ee288a2ab04d0f3572e1ae6c`,id:`source-648e50f6f6cd02ee`,path:`circuit.spi`}],sourcePolicy:`copy`},structureRevision:2,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`cell-rc-lowpass`}},{id:`rlc`,name:`RLC Filter`,description:`Damping & resonance`,source:{documents:[{annotations:[{alignment:`middle`,anchor:{fallbackPosition:{x:280,y:160},kind:`object`,localOffset:{x:10,y:-20},objectId:`R1`},binding:{instanceId:`R1`,kind:`instance-reference`},id:`instance-label-R1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:390,y:160},kind:`object`,localOffset:{x:10,y:-20},objectId:`L1`},binding:{instanceId:`L1`,kind:`instance-reference`},id:`instance-label-L1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:500,y:250},kind:`object`,localOffset:{x:20,y:10},objectId:`C1`},binding:{instanceId:`C1`,kind:`instance-reference`},id:`instance-label-C1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:190,y:250},kind:`object`,localOffset:{x:20,y:10},objectId:`V1`},binding:{instanceId:`V1`,kind:`instance-reference`},id:`instance-label-V1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:190,y:280},kind:`object`,localOffset:{x:20,y:40},objectId:`V1`},binding:{instanceId:`V1`,kind:`instance-value`},id:`instance-value-V1`,kind:`instance-value`,locked:!1,rotation:0,visible:!1},{alignment:`middle`,anchor:{fallbackPosition:{x:280,y:190},kind:`object`,localOffset:{x:10,y:10},objectId:`R1`},binding:{instanceId:`R1`,kind:`instance-value`},id:`instance-value-R1`,kind:`instance-value`,locked:!1,rotation:0,visible:!1},{alignment:`start`,anchor:{direction:`forward`,fallbackPosition:{x:490,y:195},kind:`route`,legId:`route-leg-aaa7fe3b2551960f`,normalOffset:-10,orientation:`follow`,routeId:`wire-32`,t:.375},binding:{kind:`net-name`,netId:`net-232eaf9b4907ccf7`},id:`net-label-wire-32`,kind:`net-label`,locked:!1,netId:`net-232eaf9b4907ccf7`,rotation:0,sizeScale:1},{alignment:`start`,anchor:{direction:`forward`,fallbackPosition:{x:145,y:195},kind:`route`,legId:`route-leg-c9c862951504dedf`,normalOffset:-25,orientation:`follow`,routeId:`wire-28`,t:.625},binding:{kind:`net-name`,netId:`net-3cc118a1672a4767`},id:`net-label-wire-28`,kind:`net-label`,locked:!1,netId:`net-3cc118a1672a4767`,rotation:0,sizeScale:1}],connectivityEvidence:[{id:`connectivity-evidence-d92e0a448bb319cd`,kind:`net-name-hint`,netId:`net-3cc118a1672a4767`,origin:`spice-import`,sourceName:`in`},{id:`connectivity-evidence-7ae98d9e91d374ad`,kind:`spice-source`,netId:`net-3cc118a1672a4767`,sourceNetId:`net-3cc118a1672a4767`},{id:`connectivity-evidence-c3026f25e0803bdb`,kind:`name-claim`,name:`0`,netId:`net-89e480092dc336ed`,owner:{kind:`global-declaration`,sourceNetId:`net-89e480092dc336ed`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-08b4f29c97880525`,kind:`spice-source`,netId:`net-89e480092dc336ed`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-bd910f1e7809737a`,kind:`net-name-hint`,netId:`net-1161719b3ecff90d`,origin:`spice-import`,sourceName:`mid`},{id:`connectivity-evidence-e2e3624cdc9a4129`,kind:`spice-source`,netId:`net-1161719b3ecff90d`,sourceNetId:`net-1161719b3ecff90d`},{id:`connectivity-evidence-617050b36c8b4149`,kind:`net-name-hint`,netId:`net-232eaf9b4907ccf7`,origin:`spice-import`,sourceName:`out`},{id:`connectivity-evidence-e5eb74d8864ce135`,kind:`spice-source`,netId:`net-232eaf9b4907ccf7`,sourceNetId:`net-232eaf9b4907ccf7`},{id:`connectivity-evidence-c91303d1f37f789e`,kind:`name-claim`,name:`out`,netId:`net-232eaf9b4907ccf7`,owner:{annotationId:`net-label-wire-32`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-64b347cb81b29afd`,kind:`name-claim`,name:`in`,netId:`net-3cc118a1672a4767`,owner:{annotationId:`net-label-wire-28`,kind:`net-label`},scope:`local`}],constraints:[],drafting:{objects:[{alignment:`start`,anchor:{kind:`free`,position:{x:20,y:20}},content:{runs:[{children:[{kind:`text`,value:`RLC low-pass: L = 10 mH, C = 100 nF`}],kind:`span`,style:`bold`}]},id:`description-0`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:20,y:45}},content:{runs:[{children:[{kind:`text`,value:`f0 = 5032.92 Hz; critical R = 632.456 ohm.`}],kind:`span`,style:`bold`}]},id:`description-1`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:20,y:70}},content:{runs:[{children:[{kind:`text`,value:`Each experiment explicitly alters R1 for its damping case.`}],kind:`span`,style:`bold`}]},id:`description-2`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0}]},id:`cell-rlc-filter`,instances:[{id:`V1`,importProvenance:{kind:`primitive`,sourceMasterName:`voltage-source`,sourceTarget:`primitive:voltage-source`,status:`resolved`,terminalMapping:[{pinName:`+`,sourcePosition:0},{pinName:`-`,sourcePosition:1}]},netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{acMagnitude:`1`,dc:`0`,delay:`100u`,fall:`100n`,high:`1`,low:`0`,period:`4m`,rise:`100n`,waveform:`pulse`,width:`2m`}},placement:{mirror:`none`,position:{x:170,y:240},rotation:0},reference:`V1`,sourceRef:{end:{column:10,line:2,offset:79},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:70}},symbolId:`voltage-source`},{id:`R1`,importProvenance:{kind:`primitive`,sourceMasterName:`resistor`,sourceTarget:`primitive:resistor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`resistor`,kind:`primitive`},parameters:{value:`200`}},placement:{mirror:`none`,position:{x:270,y:180},rotation:270},reference:`R1`,sourceRef:{end:{column:14,line:3,offset:93},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:3,offset:80}},symbolId:`resistor`},{id:`L1`,importProvenance:{kind:`primitive`,sourceMasterName:`inductor`,sourceTarget:`primitive:inductor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`inductor`,kind:`primitive`},parameters:{value:`10m`}},placement:{mirror:`none`,position:{x:380,y:180},rotation:270},reference:`L1`,sourceRef:{end:{column:15,line:4,offset:108},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:4,offset:94}},symbolId:`inductor-compact`},{id:`C1`,importProvenance:{kind:`primitive`,sourceMasterName:`capacitor`,sourceTarget:`primitive:capacitor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`100n`}},placement:{mirror:`none`,position:{x:480,y:240},rotation:0},reference:`C1`,sourceRef:{end:{column:14,line:5,offset:122},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:5,offset:109}},symbolId:`capacitor`},{id:`GND1`,placement:{mirror:`none`,position:{x:170,y:300},rotation:0},symbolId:`ground`},{id:`GND2`,placement:{mirror:`none`,position:{x:480,y:300},rotation:0},symbolId:`ground`}],junctions:[],layoutGroups:[],name:`RLC Filter — Damping Laboratory`,netlist:{formalParameters:[],name:`rlc_filter`,terminals:[]},nets:[{id:`net-3cc118a1672a4767`,terminals:[{instanceId:`V1`,pinName:`+`},{instanceId:`R1`,pinName:`1`}]},{id:`net-89e480092dc336ed`,terminals:[{instanceId:`V1`,pinName:`-`},{instanceId:`C1`,pinName:`2`},{instanceId:`GND1`,pinName:`0`},{instanceId:`GND2`,pinName:`0`}]},{id:`net-1161719b3ecff90d`,terminals:[{instanceId:`R1`,pinName:`2`},{instanceId:`L1`,pinName:`1`}]},{id:`net-232eaf9b4907ccf7`,terminals:[{instanceId:`L1`,pinName:`2`},{instanceId:`C1`,pinName:`1`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:49,routes:[{id:`wire-28`,legs:[{id:`route-leg-c9c862951504dedf`,mode:`manual`,to:{bendId:`route-bend-c9c862951504dedf`,kind:`bend`,position:{x:170,y:180}}},{id:`route-leg-c9c861951504dd2c`,mode:`manual`,to:{endpoint:{instanceId:`R1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-3cc118a1672a4767`,start:{instanceId:`V1`,kind:`terminal`,pinName:`+`}},{id:`wire-30`,legs:[{id:`route-leg-b76235ad7066f66a`,mode:`manual`,to:{endpoint:{instanceId:`L1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-1161719b3ecff90d`,start:{instanceId:`R1`,kind:`terminal`,pinName:`2`}},{id:`wire-32`,legs:[{id:`route-leg-aaa7fd3b2551945c`,mode:`manual`,to:{bendId:`route-bend-aaa7fd3b2551945c`,kind:`bend`,position:{x:480,y:180}}},{id:`route-leg-aaa7fe3b2551960f`,mode:`manual`,to:{endpoint:{instanceId:`C1`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-232eaf9b4907ccf7`,start:{instanceId:`L1`,kind:`terminal`,pinName:`2`}},{id:`wire-35`,legs:[{id:`route-leg-735ee395b837cf05`,mode:`manual`,to:{endpoint:{instanceId:`GND1`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`V1`,kind:`terminal`,pinName:`-`}},{id:`wire-38`,legs:[{id:`route-leg-559c359379b7d5d2`,mode:`manual`,to:{endpoint:{instanceId:`GND2`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`C1`,kind:`terminal`,pinName:`2`}}],sourceBinding:{cellName:`rlc_filter`,sourceRef:{end:{column:14,line:5,offset:122},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:70}}},sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[],id:`project-rlc-filter`,name:`RLC Filter — Damping Laboratory`,schemaVersion:53,simulationFolders:[{id:`rlc-1`,input:{circuitBindings:[{documentId:`cell-rlc-filter`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`01 Underdamped | AC + Step
// 1. Change r in the alter command below; Canvas R1 remains the nominal value.
// 2. Click Run.
// 3. Plot Gain or the step; Measurements contains sampled peaks and final value.
ground 0
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10 tran_fbr=0.025
alter instance("R1") r=200
save v(in) v(out) i(L1)
// AC is small-signal response, not an output-swing test.
analysis frequency ac from=100 to=1M mode="dec" points=100
analysis step tran stop=1m step=500n maxstep=500n
postprocess(PYTHON, "report.py", "rlc")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`01 Underdamped | AC + Step`,version:4},{id:`rlc-2`,input:{circuitBindings:[{documentId:`cell-rlc-filter`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`02 Critical | AC + Step
// 1. Change r in the alter command below; Canvas R1 remains the nominal value.
// 2. Click Run.
// 3. Plot Gain or the step; Measurements contains sampled peaks and final value.
ground 0
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10 tran_fbr=0.025
alter instance("R1") r=632.455532
save v(in) v(out) i(L1)
// AC is small-signal response, not an output-swing test.
analysis frequency ac from=100 to=1M mode="dec" points=100
analysis step tran stop=1m step=500n maxstep=500n
postprocess(PYTHON, "report.py", "rlc")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`02 Critical | AC + Step`,version:4},{id:`rlc-3`,input:{circuitBindings:[{documentId:`cell-rlc-filter`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[],entry:`run.cir`,files:[{path:`run.cir`,text:`03 Overdamped | AC + Step
// 1. Change r in the alter command below; Canvas R1 remains the nominal value.
// 2. Click Run.
// 3. Plot Gain or the step; Measurements contains sampled peaks and final value.
ground 0
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 vntol=1e-10 tran_fbr=0.025
alter instance("R1") r=1000
save v(in) v(out) i(L1)
// AC is small-signal response, not an output-swing test.
analysis frequency ac from=100 to=1M mode="dec" points=100
analysis step tran stop=1m step=500n maxstep=500n
postprocess(PYTHON, "report.py", "rlc")
endc
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`03 Overdamped | AC + Step`,version:4}],source:{dialect:`spice3f5-core`,entry:`circuit.spi`,files:[{hash:`sha256:522c323ab66e1bc8d22e6bf6b1229c9ff2e427164a8fef79a2835d8d85001580`,id:`source-648e50f6f6cd02ee`,path:`circuit.spi`}],sourcePolicy:`copy`},structureRevision:0,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`cell-rlc-filter`}},{id:`common-source`,name:`Common-source Amplifier`,description:`Bias, gain & distortion`,source:{documents:[{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:310,y:430},kind:`object`,localOffset:{x:-30,y:30},objectId:`XM1`},binding:{instanceId:`XM1`,kind:`instance-reference`},id:`instance-label-XM1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:370,y:330},kind:`object`,localOffset:{x:20,y:10},objectId:`RD`},binding:{instanceId:`RD`,kind:`instance-reference`},id:`instance-label-RD`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:400,y:275},kind:`object`,localOffset:{x:50,y:5},objectId:`VDD`},binding:{instanceId:`VDD`,kind:`instance-reference`},id:`instance-label-VDD`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:460,y:385},kind:`object`,localOffset:{x:20,y:5},objectId:`CL`},binding:{instanceId:`CL`,kind:`instance-reference`},id:`instance-label-CL`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:210,y:445},kind:`object`,localOffset:{x:-50,y:5},objectId:`VIN`},binding:{instanceId:`VIN`,kind:`instance-reference`},id:`instance-label-VIN`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:295,y:380},kind:`object`,localOffset:{x:-45,y:-20},objectId:`XM1`},binding:{instanceId:`XM1`,kind:`instance-value`},id:`instance-value-XM1`,kind:`instance-value`,locked:!1,rotation:0}],connectivityEvidence:[{id:`connectivity-evidence-b7e6be66f73ec485`,kind:`net-name-hint`,netId:`net-e601849b263a5bd1`,origin:`spice-import`,sourceName:`vdd`},{id:`connectivity-evidence-8d0b0efdb1057aa9`,kind:`spice-source`,netId:`net-e601849b263a5bd1`,sourceNetId:`net-e601849b263a5bd1`},{id:`connectivity-evidence-c3026f25e0803bdb`,kind:`name-claim`,name:`0`,netId:`net-89e480092dc336ed`,owner:{kind:`global-declaration`,sourceNetId:`net-89e480092dc336ed`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-08b4f29c97880525`,kind:`spice-source`,netId:`net-89e480092dc336ed`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-d92e0a448bb319cd`,kind:`net-name-hint`,netId:`net-3cc118a1672a4767`,origin:`spice-import`,sourceName:`in`},{id:`connectivity-evidence-7ae98d9e91d374ad`,kind:`spice-source`,netId:`net-3cc118a1672a4767`,sourceNetId:`net-3cc118a1672a4767`},{id:`connectivity-evidence-617050b36c8b4149`,kind:`net-name-hint`,netId:`net-232eaf9b4907ccf7`,origin:`spice-import`,sourceName:`out`},{id:`connectivity-evidence-e5eb74d8864ce135`,kind:`spice-source`,netId:`net-232eaf9b4907ccf7`,sourceNetId:`net-232eaf9b4907ccf7`},{id:`connectivity-evidence-41b3d5b2278dadc8`,kind:`spice-source`,netId:`net-split-03d2ef8490cf4130`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-135777569d918963`,kind:`spice-source`,netId:`net-split-162a792c97635c9d`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-7384c945030845a2`,kind:`spice-source`,netId:`net-split-1f0a142c9c792118`,sourceNetId:`net-89e480092dc336ed`},{id:`connectivity-evidence-d4f81b6fb35ecc7c`,kind:`name-claim`,netId:`net-split-1f0a142c9c792118`,name:`0`,owner:{kind:`power-marker`,objectId:`GND2`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-d4f81c6fb35ece2f`,kind:`name-claim`,netId:`net-89e480092dc336ed`,name:`0`,owner:{kind:`power-marker`,objectId:`GND3`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-d4f8196fb35ec916`,kind:`name-claim`,netId:`net-split-03d2ef8490cf4130`,name:`0`,owner:{kind:`power-marker`,objectId:`GND4`},scope:`global`,powerDomain:`ground`},{id:`connectivity-evidence-a69d157e122129c0`,kind:`name-claim`,netId:`net-split-162a792c97635c9d`,name:`0`,owner:{kind:`power-marker`,objectId:`GND2-copy-1`},scope:`global`,powerDomain:`ground`}],constraints:[],drafting:{objects:[{alignment:`start`,anchor:{kind:`free`,position:{x:50,y:115}},content:{runs:[{children:[{kind:`text`,value:`SKY130 NMOS resistor-loaded common-source amplifier`}],kind:`span`,style:`bold`}]},id:`description-0`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:50,y:145}},content:{runs:[{children:[{kind:`text`,value:`VDD = 1.8 V; Vbias = 0.7 V; RD = 10 kohm; CL = 1 pF`}],kind:`span`,style:`bold`}]},id:`description-1`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:50,y:175}},content:{runs:[{children:[{kind:`text`,value:`Small/large signals use native alter commands, not hidden JSON overrides.`}],kind:`span`,style:`bold`}]},id:`description-2`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0}]},id:`cell-common-source`,instances:[{id:`VDD`,importProvenance:{kind:`primitive`,sourceMasterName:`voltage-source`,sourceTarget:`primitive:voltage-source`,status:`resolved`,terminalMapping:[{pinName:`+`,sourcePosition:0},{pinName:`-`,sourcePosition:1}]},netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{dc:`1.8`,waveform:`dc`}},placement:{mirror:`none`,position:{x:350,y:270},rotation:180},reference:`VDD`,sourceRef:{end:{column:14,line:2,offset:97},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:84}},symbolId:`voltage-source`},{id:`VIN`,importProvenance:{kind:`primitive`,sourceMasterName:`voltage-source`,sourceTarget:`primitive:voltage-source`,status:`resolved`,terminalMapping:[{pinName:`+`,sourcePosition:0},{pinName:`-`,sourcePosition:1}]},netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{acMagnitude:`1`,amplitude:`10m`,dc:`0.7`,frequency:`10k`,offset:`0.7`,waveform:`sin`}},placement:{mirror:`none`,position:{x:260,y:440},rotation:0},reference:`VIN`,sourceRef:{end:{column:13,line:3,offset:110},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:3,offset:98}},symbolId:`voltage-source`},{id:`RD`,importProvenance:{kind:`primitive`,sourceMasterName:`resistor`,sourceTarget:`primitive:resistor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`resistor`,kind:`primitive`},parameters:{value:`10k`}},placement:{mirror:`none`,position:{x:350,y:320},rotation:0},reference:`RD`,sourceRef:{end:{column:15,line:4,offset:125},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:4,offset:111}},symbolId:`resistor`},{id:`XM1`,importProvenance:{kind:`opaque`,sourceMasterName:`sky130_fd_pr__nfet_01v8`,sourceTarget:`external-subcircuit:sky130_fd_pr__nfet_01v8`,status:`resolved`,symbolMappingRegistryId:`sky130-nfet-01v8`,terminalMapping:[{pinName:`D`,sourcePosition:0},{pinName:`G`,sourcePosition:1},{pinName:`S`,sourcePosition:2},{pinName:`B`,sourcePosition:3}]},netlist:{binding:{definitionId:`external-subcircuit-e5ee3d17d0c7c89a`,kind:`external-subcircuit`},parameters:{l:`1u`,nf:`1`,w:`10u`}},placement:{mirror:`none`,position:{x:340,y:400},rotation:0},reference:`XM1`,sourceRef:{end:{column:53,line:5,offset:178},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:5,offset:126}},symbolId:`nmos`},{id:`CL`,importProvenance:{kind:`primitive`,sourceMasterName:`capacitor`,sourceTarget:`primitive:capacitor`,status:`resolved`,terminalMapping:[{pinName:`1`,sourcePosition:0},{pinName:`2`,sourcePosition:1}]},netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`1p`}},placement:{mirror:`none`,position:{x:440,y:380},rotation:0},reference:`CL`,sourceRef:{end:{column:12,line:6,offset:190},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:6,offset:179}},symbolId:`capacitor`},{id:`GND2`,placement:{mirror:`none`,position:{x:260,y:480},rotation:0},symbolId:`ground`},{id:`GND3`,placement:{mirror:`none`,position:{x:350,y:480},rotation:0},symbolId:`ground`},{id:`GND4`,placement:{mirror:`none`,position:{x:440,y:410},rotation:0},symbolId:`ground`},{id:`GND2-copy-1`,placement:{mirror:`none`,position:{x:350,y:220},rotation:180},symbolId:`ground`}],junctions:[{id:`junction-ui-4`,netId:`net-89e480092dc336ed`,position:{x:350,y:430},role:`branch`},{id:`junction-lifecycle-18-1`,netId:`net-split-162a792c97635c9d`,position:{x:350,y:230},role:`branch`},{id:`junction-canonical-836e0dd3e7b1500a`,netId:`net-232eaf9b4907ccf7`,position:{x:350,y:360},role:`branch`}],layoutGroups:[],name:`SKY130 Common-source Amplifier`,netlist:{formalParameters:[],name:`common_source`,terminals:[]},nets:[{id:`net-e601849b263a5bd1`,terminals:[{instanceId:`VDD`,pinName:`+`},{instanceId:`RD`,pinName:`1`}]},{id:`net-89e480092dc336ed`,terminals:[{instanceId:`XM1`,pinName:`B`},{instanceId:`XM1`,pinName:`S`},{instanceId:`GND3`,pinName:`0`}]},{id:`net-3cc118a1672a4767`,terminals:[{instanceId:`VIN`,pinName:`+`},{instanceId:`XM1`,pinName:`G`}]},{id:`net-232eaf9b4907ccf7`,terminals:[{instanceId:`RD`,pinName:`2`},{instanceId:`XM1`,pinName:`D`},{instanceId:`CL`,pinName:`1`}]},{id:`net-split-03d2ef8490cf4130`,terminals:[{instanceId:`CL`,pinName:`2`},{instanceId:`GND4`,pinName:`0`}]},{id:`net-split-162a792c97635c9d`,terminals:[{instanceId:`VDD`,pinName:`-`},{instanceId:`GND2-copy-1`,pinName:`0`}]},{id:`net-split-1f0a142c9c792118`,terminals:[{instanceId:`VIN`,pinName:`-`},{instanceId:`GND2`,pinName:`0`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:164,routes:[{id:`wire-47`,legs:[{id:`route-leg-3334808c4bb0b5fc`,mode:`manual`,to:{bendId:`route-bend-9df9d5960dfab1f0`,kind:`bend`,position:{x:260,y:400}}},{id:`route-leg-4595699febebcc43`,mode:`manual`,to:{endpoint:{instanceId:`XM1`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-3cc118a1672a4767`,start:{instanceId:`VIN`,kind:`terminal`,pinName:`+`}},{id:`wire-52`,legs:[{id:`route-leg-a01eac6794d2ebb6`,mode:`manual`,to:{endpoint:{junctionId:`junction-lifecycle-18-1`,kind:`junction`},kind:`endpoint`}}],netId:`net-split-162a792c97635c9d`,start:{instanceId:`VDD`,kind:`terminal`,pinName:`-`}},{id:`route-e62be0dccd25d299`,legs:[{id:`route-leg-37d913f0a9a65ed1`,mode:`manual`,to:{endpoint:{instanceId:`VDD`,kind:`terminal`,pinName:`+`},kind:`endpoint`}}],netId:`net-e601849b263a5bd1`,start:{instanceId:`RD`,kind:`terminal`,pinName:`1`}},{id:`route-ui-5`,legs:[{id:`route-leg-b425448e843180bb`,mode:`manual`,to:{bendId:`route-bend-b425438e84317f08`,kind:`bend`,position:{x:370,y:400}}},{id:`route-leg-b425468e84318421`,mode:`manual`,to:{bendId:`route-bend-b425468e84318421`,kind:`bend`,position:{x:370,y:430}}},{id:`route-leg-b425458e8431826e`,mode:`manual`,to:{endpoint:{junctionId:`junction-ui-4`,kind:`junction`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,presentation:`bulk-dashed`,start:{instanceId:`XM1`,kind:`terminal`,pinName:`B`}},{id:`route-446c979dc97457c8`,legs:[{id:`route-leg-0380f4248e81778a`,mode:`manual`,to:{endpoint:{instanceId:`VIN`,kind:`terminal`,pinName:`-`},kind:`endpoint`}}],netId:`net-split-1f0a142c9c792118`,start:{instanceId:`GND2`,kind:`terminal`,pinName:`0`}},{id:`route-canonical-98c3ed8cf6ae9fc3-a-4`,legs:[{id:`route-leg-6a6e2a9e8beeae8e`,mode:`manual`,to:{endpoint:{instanceId:`GND3`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-89e480092dc336ed`,start:{instanceId:`XM1`,kind:`terminal`,pinName:`S`}},{id:`wire-45`,legs:[{id:`route-leg-f08530a5ed0a318a`,mode:`manual`,to:{endpoint:{junctionId:`junction-canonical-836e0dd3e7b1500a`,kind:`junction`},kind:`endpoint`}}],netId:`net-232eaf9b4907ccf7`,start:{instanceId:`RD`,kind:`terminal`,pinName:`2`}},{id:`route-canonical-5dc017b681e2b4a5`,legs:[{id:`route-leg-f90643294d33b198`,mode:`manual`,to:{endpoint:{instanceId:`XM1`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-232eaf9b4907ccf7`,start:{junctionId:`junction-canonical-836e0dd3e7b1500a`,kind:`junction`}},{id:`route-canonical-597959e33fc6e42d`,legs:[{id:`route-leg-dd432688216b06ad`,mode:`manual`,to:{endpoint:{instanceId:`CL`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`net-232eaf9b4907ccf7`,start:{junctionId:`junction-canonical-836e0dd3e7b1500a`,kind:`junction`}}],sourceBinding:{cellName:`common_source`,sourceRef:{end:{column:12,line:6,offset:190},fileId:`source-648e50f6f6cd02ee`,start:{column:1,line:2,offset:84}}},sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[{formalParameters:[{defaultValue:`1`,name:`w`},{defaultValue:`0.15`,name:`l`},{defaultValue:`1`,name:`nf`},{defaultValue:`1`,name:`m`}],id:`external-subcircuit-e5ee3d17d0c7c89a`,interfaceStatus:`declared`,name:`sky130_fd_pr__nfet_01v8`,terminals:[{direction:`passive`,id:`external-subcircuit-terminal-353df4da271bcc2b`,name:`D`},{direction:`passive`,id:`external-subcircuit-terminal-353df3da271bca78`,name:`G`},{direction:`passive`,id:`external-subcircuit-terminal-353df6da271bcf91`,name:`S`},{direction:`passive`,id:`external-subcircuit-terminal-353df5da271bcdde`,name:`B`}]}],id:`project-common-source`,name:`SKY130 Common-source Amplifier`,schemaVersion:53,simulationFolders:[{id:`cs-op`,input:{circuitBindings:[{documentId:`cell-common-source`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`01 Bias | Native Device OP
// 1. Adjust sources or device parameters on Canvas.
// 2. Click Run.
// 3. Open Operating Point for node voltages and native model values.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(in) v(out) i(VDD)
save p('XM1:msky130_fd_pr__nfet_01v8',id) p('XM1:msky130_fd_pr__nfet_01v8',vgs) p('XM1:msky130_fd_pr__nfet_01v8',vds) p('XM1:msky130_fd_pr__nfet_01v8',vbs) p('XM1:msky130_fd_pr__nfet_01v8',gm) p('XM1:msky130_fd_pr__nfet_01v8',gds) p('XM1:msky130_fd_pr__nfet_01v8',gmbs) p('XM1:msky130_fd_pr__nfet_01v8',vth) p('XM1:msky130_fd_pr__nfet_01v8',vdsat)
analysis bias op
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`01 Bias | Native Device OP`,version:4},{id:`cs-dc`,input:{circuitBindings:[{documentId:`cell-common-source`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`02 DC transfer
// 1. Edit the VIN sweep below; Canvas still owns the circuit.
// 2. Click Run.
// 3. Plot out against the input sweep.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(in) v(out) i(VDD)
// A native sine source must explicitly enter DC mode for this parameter sweep.
alter instance("VIN") type="dc"
sweep input instance="VIN" parameter="dc" from=0.3 to=1.2 step=0.005
analysis transfer op
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`02 DC transfer`,version:4},{id:`cs-ac`,input:{circuitBindings:[{documentId:`cell-common-source`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`03 AC gain and bandwidth
// 1. Edit frequency limits below or circuit parameters on Canvas.
// 2. Click Run.
// 3. Plot Gain in dB/phase and read gain_db_1khz from Measurements.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(in) v(out)
analysis frequency ac from=10 to=1G mode="dec" points=80
postprocess(PYTHON,"report.py","cs-ac")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`03 AC gain and bandwidth`,version:4},{id:`cs-tran`,input:{circuitBindings:[{documentId:`cell-common-source`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`04 Small and large signal | Native loop
// 1. Edit the native amplitude sweep; keep both cases for comparison.
// 2. Click Run.
// 3. Plot the two signal records; output_pp uses 200-400 us for each case.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(in) v(out)
alter instance("VIN") type="sine" sinedc=0.7 freq=10k
sweep amplitude instance="VIN" parameter="ampl" values=[0.01,0.2] continuation=0
analysis signal tran stop=400u step=0.2u maxstep=0.2u
// Split by the returned amplitude column, not guessed point counts or frontend state.
postprocess(PYTHON,"report.py","cs-tran")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`04 Small and large signal | Native loop`,version:4}],source:{dialect:`spice3f5-core`,entry:`circuit.spi`,files:[{hash:`sha256:27c79eb10f8877eeb2aa2ecf4693c56661836587f27fe1488d5cd270bc250af4`,id:`source-648e50f6f6cd02ee`,path:`circuit.spi`}],sourcePolicy:`copy`},structureRevision:0,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`cell-common-source`}},{id:`ota`,name:`OTA Amplifier`,description:`Open & closed loop`,source:{documents:[{annotations:[{alignment:`middle`,anchor:{fallbackPosition:{x:615,y:400},kind:`object`,localOffset:{x:55,y:80},objectId:`XDUT`},binding:{instanceId:`XDUT`,kind:`instance-reference`},id:`instance-label-XDUT`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:460,y:130},kind:`object`,localOffset:{x:-30,y:-30},objectId:`VDD`},binding:{instanceId:`VDD`,kind:`instance-reference`},id:`instance-label-VDD`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:500,y:130},kind:`object`,localOffset:{x:10,y:-30},objectId:`VDD`},binding:{instanceId:`VDD`,kind:`instance-value`},id:`instance-value-VDD`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:375,y:265},kind:`object`,localOffset:{x:-25,y:-35},objectId:`VINP`},binding:{instanceId:`VINP`,kind:`instance-reference`},id:`instance-label-VINP`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{fallbackPosition:{x:380,y:390},kind:`object`,localOffset:{x:-20,y:40},objectId:`VINN`},binding:{instanceId:`VINN`,kind:`instance-reference`},id:`instance-label-VINN`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:500,y:210},kind:`object`,localOffset:{x:-50,y:0},objectId:`IBIAS`},binding:{instanceId:`IBIAS`,kind:`instance-reference`},id:`instance-label-IBIAS`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:750,y:355},kind:`object`,localOffset:{x:20,y:-5},objectId:`CL`},binding:{instanceId:`CL`,kind:`instance-reference`},id:`instance-label-CL`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{direction:`forward`,fallbackPosition:{x:685,y:310},kind:`route`,legId:`route-leg-9cbad225568967f9`,normalOffset:-10,orientation:`follow`,routeId:`tb-vout-route`,t:.5},binding:{kind:`net-name`,netId:`tb-vout-net`},id:`net-label-tb-vout-route`,kind:`net-label`,locked:!1,netId:`tb-vout-net`,rotation:0},{alignment:`start`,anchor:{kind:`free`,position:{x:450,y:285}},binding:{kind:`net-name`,netId:`tb-vinp-net`},id:`native-net-vinp`,kind:`net-label`,locked:!1,netId:`tb-vinp-net`,rotation:0},{alignment:`start`,anchor:{kind:`free`,position:{x:450,y:340}},binding:{kind:`net-name`,netId:`tb-vinn-net`},id:`native-net-vinn`,kind:`net-label`,locked:!1,netId:`tb-vinn-net`,rotation:0},{alignment:`start`,anchor:{kind:`free`,position:{x:580,y:150}},binding:{kind:`net-name`,netId:`net-tb-vdd`},id:`native-net-vdd`,kind:`net-label`,locked:!1,netId:`net-tb-vdd`,rotation:0}],connectivityEvidence:[{id:`connectivity-evidence-33dd40c74ee1950d`,kind:`name-claim`,name:`0`,netId:`net-split-a810f1946a2e3084`,owner:{kind:`power-marker`,objectId:`GND1`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-4fd51303c6ed3225`,kind:`name-claim`,name:`0`,netId:`net-split-f3cbcac420d93ece`,owner:{kind:`power-marker`,objectId:`GND2`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-97019202b6a994e5`,kind:`name-claim`,name:`0`,netId:`net-power-gnd3`,owner:{kind:`power-marker`,objectId:`GND3`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-d2bb87eae3b4a1c5`,kind:`name-claim`,name:`0`,netId:`net-power-gnd4`,owner:{kind:`power-marker`,objectId:`GND4`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-7ec67ce55c90646d`,kind:`name-claim`,name:`0`,netId:`net-power-gnd5`,owner:{kind:`power-marker`,objectId:`GND5`},powerDomain:`ground`,scope:`global`},{id:`connectivity-evidence-db342e0a821d20d0`,kind:`name-claim`,name:`vout`,netId:`tb-vout-net`,owner:{annotationId:`net-label-tb-vout-route`,kind:`net-label`},scope:`local`},{id:`native-name-vinp`,kind:`name-claim`,name:`vinp`,netId:`tb-vinp-net`,owner:{annotationId:`native-net-vinp`,kind:`net-label`},scope:`local`},{id:`native-name-vinn`,kind:`name-claim`,name:`vinn`,netId:`tb-vinn-net`,owner:{annotationId:`native-net-vinn`,kind:`net-label`},scope:`local`},{id:`native-name-vdd`,kind:`name-claim`,name:`vdd`,netId:`net-tb-vdd`,owner:{annotationId:`native-net-vdd`,kind:`net-label`},scope:`local`}],constraints:[],drafting:{objects:[{alignment:`start`,anchor:{kind:`free`,position:{x:270,y:30}},content:{runs:[{children:[{kind:`text`,value:`Native OTA laboratory: bias, DC, AC corners, transient, noise and feedback.`}],kind:`span`,style:`bold`}]},id:`native-guide-1`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0},{alignment:`start`,anchor:{kind:`free`,position:{x:270,y:55}},content:{runs:[{children:[{kind:`text`,value:`Five-transistor core plus bias transistor XM6. Open-loop pulse is not settling time.`}],kind:`span`,style:`bold`}]},id:`native-guide-2`,kind:`text`,locked:!1,rotation:0,styleOverride:{sizeScale:1},zIndex:0}]},id:`document-ota-5t-testbench`,instances:[{id:`XDUT`,netlist:{binding:{childDocumentId:`document-ota-5t`,kind:`subcircuit`},parameters:{}},placement:{mirror:`none`,position:{x:560,y:320},rotation:0},reference:`XDUT`,symbolId:`hierarchical-symbol-72404fc79d737213`},{id:`VDD`,netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{dc:`1.8`}},placement:{mirror:`none`,position:{x:490,y:160},rotation:90},reference:`VDD`,symbolId:`voltage-source`},{id:`VINP`,netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{acMagnitude:`1`,dc:`0.9`,delay:`1u`,fall:`1n`,high:`0.91`,low:`0.9`,period:`3u`,rise:`1n`,waveform:`pulse`,width:`1u`}},placement:{mirror:`none`,position:{x:400,y:300},rotation:90},reference:`VINP`,symbolId:`voltage-source`},{id:`VINN`,netlist:{binding:{deviceClass:`voltage-source`,kind:`primitive`},parameters:{dc:`0.9`}},placement:{mirror:`none`,position:{x:400,y:350},rotation:90},reference:`VINN`,symbolId:`voltage-source`},{id:`IBIAS`,netlist:{binding:{deviceClass:`current-source`,kind:`primitive`},parameters:{dc:`15u`}},placement:{mirror:`none`,position:{x:550,y:210},rotation:0},reference:`IBIAS`,symbolId:`current-source`},{id:`CL`,netlist:{binding:{deviceClass:`capacitor`,kind:`primitive`},parameters:{value:`1p`}},placement:{mirror:`none`,position:{x:730,y:360},rotation:0},reference:`CL`,symbolId:`capacitor`},{id:`GND1`,placement:{mirror:`none`,position:{x:430,y:160},rotation:90},symbolId:`ground`},{id:`GND2`,placement:{mirror:`none`,position:{x:340,y:300},rotation:90},symbolId:`ground`},{id:`GND3`,placement:{mirror:`none`,position:{x:340,y:350},rotation:90},symbolId:`ground`},{id:`GND4`,placement:{mirror:`none`,position:{x:560,y:420},rotation:0},symbolId:`ground`},{id:`GND5`,placement:{mirror:`none`,position:{x:730,y:400},rotation:0},symbolId:`ground`}],junctions:[{id:`junction-canonical-fa66a02887bbb6d9`,netId:`net-tb-vdd`,position:{x:550,y:160},role:`branch`}],layoutGroups:[],name:`Testbench`,netlist:{formalParameters:[],name:`Testbench`,terminals:[]},nets:[{id:`net-power-gnd3`,terminals:[{instanceId:`GND3`,pinName:`0`},{instanceId:`VINN`,pinName:`-`}]},{id:`net-power-gnd4`,terminals:[{instanceId:`GND4`,pinName:`0`},{instanceId:`XDUT`,pinName:`vss`}]},{id:`net-power-gnd5`,terminals:[{instanceId:`GND5`,pinName:`0`},{instanceId:`CL`,pinName:`2`}]},{id:`net-tb-vdd`,terminals:[{instanceId:`VDD`,pinName:`+`},{instanceId:`IBIAS`,pinName:`+`},{instanceId:`XDUT`,pinName:`vdd`}]},{id:`tb-ibias-net`,terminals:[{instanceId:`IBIAS`,pinName:`-`},{instanceId:`XDUT`,pinName:`ibias`}]},{id:`tb-vinp-net`,terminals:[{instanceId:`VINP`,pinName:`+`},{instanceId:`XDUT`,pinName:`vinp`}]},{id:`tb-vinn-net`,terminals:[{instanceId:`VINN`,pinName:`+`},{instanceId:`XDUT`,pinName:`vinn`}]},{id:`tb-vout-net`,terminals:[{instanceId:`XDUT`,pinName:`vout`},{instanceId:`CL`,pinName:`1`}]},{id:`net-split-a810f1946a2e3084`,terminals:[{instanceId:`GND1`,pinName:`0`},{instanceId:`VDD`,pinName:`-`}]},{id:`net-split-f3cbcac420d93ece`,terminals:[{instanceId:`GND2`,pinName:`0`},{instanceId:`VINP`,pinName:`-`}]}],noConnects:[],presentation:{compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:181,routes:[{id:`tb-gnd-vinn-route`,legs:[{id:`route-leg-34fd6882297027f4`,mode:`manual`,to:{endpoint:{instanceId:`GND3`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-power-gnd3`,start:{instanceId:`VINN`,kind:`terminal`,pinName:`-`}},{id:`tb-gnd-dut-route`,legs:[{id:`route-leg-ac185f3591d27db9`,mode:`manual`,to:{endpoint:{instanceId:`XDUT`,kind:`terminal`,pinName:`vss`},kind:`endpoint`}}],netId:`net-power-gnd4`,start:{instanceId:`GND4`,kind:`terminal`,pinName:`0`}},{id:`tb-gnd-cl-route`,legs:[{id:`route-leg-af02721fb438a990`,mode:`manual`,to:{endpoint:{instanceId:`GND5`,kind:`terminal`,pinName:`0`},kind:`endpoint`}}],netId:`net-power-gnd5`,start:{instanceId:`CL`,kind:`terminal`,pinName:`2`}},{id:`tb-ibias-route`,legs:[{id:`route-leg-9c7f13cc644db106`,mode:`manual`,to:{endpoint:{instanceId:`XDUT`,kind:`terminal`,pinName:`ibias`},kind:`endpoint`}}],netId:`tb-ibias-net`,start:{instanceId:`IBIAS`,kind:`terminal`,pinName:`-`}},{id:`tb-vinp-route`,legs:[{id:`route-leg-db9df07a18d56c80`,mode:`manual`,to:{endpoint:{instanceId:`XDUT`,kind:`terminal`,pinName:`vinp`},kind:`endpoint`}}],netId:`tb-vinp-net`,start:{instanceId:`VINP`,kind:`terminal`,pinName:`+`}},{id:`tb-vinn-route`,legs:[{id:`route-leg-42de77b6b7306ba2`,mode:`manual`,to:{endpoint:{instanceId:`XDUT`,kind:`terminal`,pinName:`vinn`},kind:`endpoint`}}],netId:`tb-vinn-net`,start:{instanceId:`VINN`,kind:`terminal`,pinName:`+`}},{id:`tb-vout-route`,legs:[{id:`route-leg-9cbad225568967f9`,mode:`manual`,to:{bendId:`route-bend-9cbad225568967f9`,kind:`bend`,position:{x:730,y:320}}},{id:`route-leg-9cbad12556896646`,mode:`manual`,to:{endpoint:{instanceId:`CL`,kind:`terminal`,pinName:`1`},kind:`endpoint`}}],netId:`tb-vout-net`,start:{instanceId:`XDUT`,kind:`terminal`,pinName:`vout`}},{id:`route-ui-1`,legs:[{id:`route-leg-ace29482c237b3d7`,mode:`manual`,to:{endpoint:{instanceId:`VDD`,kind:`terminal`,pinName:`-`},kind:`endpoint`}}],netId:`net-split-a810f1946a2e3084`,start:{instanceId:`GND1`,kind:`terminal`,pinName:`0`}},{id:`route-35e042e11550de52`,legs:[{id:`route-leg-94c48a25d3985fe6`,mode:`manual`,to:{endpoint:{instanceId:`VINP`,kind:`terminal`,pinName:`-`},kind:`endpoint`}}],netId:`net-split-f3cbcac420d93ece`,start:{instanceId:`GND2`,kind:`terminal`,pinName:`0`}},{id:`route-ui-3`,legs:[{id:`route-leg-950eb45aec291af5`,mode:`manual`,to:{endpoint:{junctionId:`junction-canonical-fa66a02887bbb6d9`,kind:`junction`},kind:`endpoint`}}],netId:`net-tb-vdd`,start:{instanceId:`VDD`,kind:`terminal`,pinName:`+`}},{id:`tb-vdd-dut-route-a-2`,legs:[{id:`route-leg-624f4d1edaa3951c`,mode:`manual`,to:{endpoint:{instanceId:`IBIAS`,kind:`terminal`,pinName:`+`},kind:`endpoint`}}],netId:`net-tb-vdd`,start:{junctionId:`junction-canonical-fa66a02887bbb6d9`,kind:`junction`}},{id:`tb-vdd-dut-route-b-2`,legs:[{id:`route-leg-c64a8aa78eb2d60f`,mode:`manual`,to:{bendId:`route-bend-624f4d1edaa3951c`,kind:`bend`,position:{x:590,y:160}}},{id:`route-leg-624f4e1edaa396cf`,mode:`manual`,to:{endpoint:{instanceId:`XDUT`,kind:`terminal`,pinName:`vdd`},kind:`endpoint`}}],netId:`net-tb-vdd`,start:{junctionId:`junction-canonical-fa66a02887bbb6d9`,kind:`junction`}}],sourceStatus:`connectivity-modified`},{annotations:[{alignment:`start`,anchor:{fallbackPosition:{x:300,y:560},kind:`object`,localOffset:{x:10,y:20},objectId:`PVSS`},binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvss`},id:`instance-label-PVSS`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:245,y:355},kind:`object`,localOffset:{x:-45,y:-5},objectId:`PIBIAS`},binding:{kind:`cell-terminal-name`,terminalId:`terminal-pibias`},id:`instance-label-PIBIAS`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:305,y:85},kind:`object`,localOffset:{x:-5,y:-15},objectId:`PVDD`},binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvdd`},id:`instance-label-PVDD`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:630,y:270},kind:`object`,localOffset:{x:20,y:-10},objectId:`PVINN`},binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvinn`},id:`instance-label-PVINN`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:310,y:270},kind:`object`,localOffset:{x:-20,y:-10},objectId:`PVINP`},binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvinp`},id:`instance-label-PVINP`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:645,y:220},kind:`object`,localOffset:{x:15,y:0},objectId:`PVOUT`},binding:{kind:`cell-terminal-name`,terminalId:`terminal-pvout`},id:`instance-label-PVOUT`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`middle`,anchor:{direction:`forward`,fallbackPosition:{x:436,y:200},kind:`route`,legId:`route-leg-220f44782704e593`,normalOffset:-10,orientation:`follow`,routeId:`dut-nleft-trunk-route`,t:.625},binding:{kind:`net-name`,netId:`net-dut-nleft`},id:`net-label-dut-nleft-trunk-route`,kind:`net-label`,locked:!1,netId:`net-dut-nleft`,rotation:0},{alignment:`middle`,anchor:{direction:`forward`,fallbackPosition:{x:0,y:0},kind:`route`,legId:`route-leg-ada2b726f49de050`,normalOffset:-14,orientation:`follow`,routeId:`dut-tail-m1s-route`,t:.9},binding:{kind:`net-name`,netId:`net-dut-tail`},id:`net-label-dut-tail-m1s-route`,kind:`net-label`,locked:!1,netId:`net-dut-tail`,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:345,y:315},kind:`object`,localOffset:{x:-25,y:35},objectId:`M1`},binding:{instanceId:`M1`,kind:`instance-reference`},id:`instance-label-M1`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:390,y:275},kind:`object`,localOffset:{x:20,y:-5},objectId:`M1`},binding:{instanceId:`M1`,kind:`instance-value`},id:`instance-value-M1`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:605,y:310},kind:`object`,localOffset:{x:35,y:30},objectId:`M2`},binding:{instanceId:`M2`,kind:`instance-reference`},id:`instance-label-M2`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:555,y:285},kind:`object`,localOffset:{x:-15,y:5},objectId:`M2`},binding:{instanceId:`M2`,kind:`instance-value`},id:`instance-value-M2`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:420,y:135},kind:`object`,localOffset:{x:30,y:-25},objectId:`M3`},binding:{instanceId:`M3`,kind:`instance-reference`},id:`instance-label-M3`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:370,y:165},kind:`object`,localOffset:{x:-20,y:5},objectId:`M3`},binding:{instanceId:`M3`,kind:`instance-value`},id:`instance-value-M3`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:520,y:140},kind:`object`,localOffset:{x:-30,y:-20},objectId:`M4`},binding:{instanceId:`M4`,kind:`instance-reference`},id:`instance-label-M4`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:570,y:170},kind:`object`,localOffset:{x:20,y:10},objectId:`M4`},binding:{instanceId:`M4`,kind:`instance-value`},id:`instance-value-M4`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:440,y:465},kind:`object`,localOffset:{x:-30,y:25},objectId:`M5`},binding:{instanceId:`M5`,kind:`instance-reference`},id:`instance-label-M5`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`start`,anchor:{fallbackPosition:{x:490,y:450},kind:`object`,localOffset:{x:20,y:10},objectId:`M5`},binding:{instanceId:`M5`,kind:`instance-value`},id:`instance-value-M5`,kind:`instance-value`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:335,y:465},kind:`object`,localOffset:{x:35,y:25},objectId:`M6`},binding:{instanceId:`M6`,kind:`instance-reference`},id:`instance-label-M6`,kind:`instance-label`,locked:!1,rotation:0},{alignment:`end`,anchor:{fallbackPosition:{x:275,y:450},kind:`object`,localOffset:{x:-25,y:10},objectId:`M6`},binding:{instanceId:`M6`,kind:`instance-value`},id:`instance-value-M6`,kind:`instance-value`,locked:!1,rotation:0}],connectivityEvidence:[{id:`connectivity-evidence-9f1ce905a5db8772`,kind:`name-claim`,name:`nleft`,netId:`net-dut-nleft`,owner:{annotationId:`net-label-dut-nleft-trunk-route`,kind:`net-label`},scope:`local`},{id:`connectivity-evidence-ca7bbcf380650530`,kind:`name-claim`,name:`tail`,netId:`net-dut-tail`,owner:{annotationId:`net-label-dut-tail-m1s-route`,kind:`net-label`},scope:`local`}],constraints:[],drafting:{objects:[]},id:`document-ota-5t`,instances:[{id:`M1`,mosBulkBinding:{netId:`net-cell-pin-pvss`,origin:`cell-default`},netlist:{binding:{definitionId:`external-subcircuit-e5ee3d17d0c7c89a`,kind:`external-subcircuit`},parameters:{l:`1u`,nf:`12`,w:`96u`}},placement:{mirror:`none`,position:{x:370,y:280},rotation:0},reference:`XM1`,symbolId:`nmos`},{id:`M2`,mosBulkBinding:{netId:`net-cell-pin-pvss`,origin:`cell-default`},netlist:{binding:{definitionId:`external-subcircuit-e5ee3d17d0c7c89a`,kind:`external-subcircuit`},parameters:{l:`1u`,nf:`12`,w:`96u`}},placement:{mirror:`horizontal`,position:{x:570,y:280},rotation:0},reference:`XM2`,symbolId:`nmos`},{id:`M3`,mosBulkBinding:{netId:`net-cell-pin-pvdd`,origin:`cell-default`},netlist:{binding:{definitionId:`external-subcircuit-27f716b14d59fc10`,kind:`external-subcircuit`},parameters:{l:`1u`,nf:`8`,w:`64u`}},placement:{mirror:`horizontal`,position:{x:390,y:160},rotation:0},reference:`XM3`,symbolId:`pmos`},{id:`M4`,mosBulkBinding:{netId:`net-cell-pin-pvdd`,origin:`cell-default`},netlist:{binding:{definitionId:`external-subcircuit-27f716b14d59fc10`,kind:`external-subcircuit`},parameters:{l:`1u`,nf:`8`,w:`64u`}},placement:{mirror:`none`,position:{x:550,y:160},rotation:0},reference:`XM4`,symbolId:`pmos`},{id:`M5`,mosBulkBinding:{netId:`net-cell-pin-pvss`,origin:`cell-default`},netlist:{binding:{definitionId:`external-subcircuit-e5ee3d17d0c7c89a`,kind:`external-subcircuit`},parameters:{l:`3u`,nf:`20`,w:`100u`}},placement:{mirror:`none`,position:{x:470,y:440},rotation:0},reference:`XM5`,symbolId:`nmos`},{id:`M6`,mosBulkBinding:{netId:`net-cell-pin-pvss`,origin:`cell-default`},netlist:{binding:{definitionId:`external-subcircuit-e5ee3d17d0c7c89a`,kind:`external-subcircuit`},parameters:{l:`3u`,nf:`6`,w:`60u`}},placement:{mirror:`horizontal`,position:{x:300,y:440},rotation:0},reference:`XM6`,symbolId:`nmos`},{id:`PVSS`,placement:{mirror:`none`,position:{x:290,y:540},rotation:270},symbolId:`port`},{id:`PIBIAS`,placement:{mirror:`none`,position:{x:290,y:360},rotation:90},symbolId:`port`},{id:`PVDD`,placement:{mirror:`none`,position:{x:310,y:100},rotation:0},symbolId:`port`},{id:`PVINN`,placement:{mirror:`none`,position:{x:610,y:280},rotation:180},symbolId:`port`},{id:`PVINP`,placement:{mirror:`none`,position:{x:330,y:280},rotation:0},symbolId:`port`},{id:`PVOUT`,placement:{mirror:`none`,position:{x:630,y:220},rotation:180},symbolId:`port`}],junctions:[{id:`junction-dut-vdd`,netId:`net-cell-pin-pvdd`,position:{x:380,y:100},role:`branch`},{id:`junction-dut-vout`,netId:`net-cell-pin-pvout`,position:{x:560,y:220},role:`branch`},{id:`junction-dut-nleft-a`,netId:`net-dut-nleft`,position:{x:380,y:210},role:`branch`},{id:`junction-dut-nleft-b`,netId:`net-dut-nleft`,position:{x:470,y:160},role:`branch`},{id:`junction-dut-tail`,netId:`net-dut-tail`,position:{x:480,y:340},role:`branch`},{id:`junction-canonical-a69a92ac5a85be8f`,netId:`net-cell-pin-pibias`,position:{x:290,y:400},role:`branch`},{id:`junction-canonical-3993d1302f152696`,netId:`net-cell-pin-pvss`,position:{x:290,y:490},role:`branch`},{id:`junction-canonical-0fddbcfe7d216a81`,netId:`net-cell-pin-pibias`,position:{x:380,y:440},role:`branch`}],layoutGroups:[],mosBulkDefaults:{nmosNetId:`net-cell-pin-pvss`,pmosNetId:`net-cell-pin-pvdd`},name:`ota_5t`,netlist:{formalParameters:[],name:`ota_5t`,terminals:[{direction:`passive`,id:`terminal-pvss`,interfaceInstanceIds:[`PVSS`],name:`vss`,netId:`net-cell-pin-pvss`},{direction:`input`,id:`terminal-pibias`,interfaceInstanceIds:[`PIBIAS`],name:`ibias`,netId:`net-cell-pin-pibias`},{direction:`passive`,id:`terminal-pvdd`,interfaceInstanceIds:[`PVDD`],name:`vdd`,netId:`net-cell-pin-pvdd`},{direction:`input`,id:`terminal-pvinn`,interfaceInstanceIds:[`PVINN`],name:`vinn`,netId:`net-cell-pin-pvinn`},{direction:`input`,id:`terminal-pvinp`,interfaceInstanceIds:[`PVINP`],name:`vinp`,netId:`net-cell-pin-pvinp`},{direction:`output`,id:`terminal-pvout`,interfaceInstanceIds:[`PVOUT`],name:`vout`,netId:`net-cell-pin-pvout`}]},nets:[{id:`net-cell-pin-pvss`,terminals:[{instanceId:`PVSS`,pinName:`P`},{instanceId:`M6`,pinName:`S`},{instanceId:`M5`,pinName:`S`},{instanceId:`M1`,pinName:`B`},{instanceId:`M2`,pinName:`B`},{instanceId:`M5`,pinName:`B`},{instanceId:`M6`,pinName:`B`}]},{id:`net-cell-pin-pibias`,terminals:[{instanceId:`PIBIAS`,pinName:`P`},{instanceId:`M6`,pinName:`G`},{instanceId:`M6`,pinName:`D`},{instanceId:`M5`,pinName:`G`}]},{id:`net-cell-pin-pvdd`,terminals:[{instanceId:`PVDD`,pinName:`P`},{instanceId:`M3`,pinName:`S`},{instanceId:`M4`,pinName:`S`},{instanceId:`M3`,pinName:`B`},{instanceId:`M4`,pinName:`B`}]},{id:`net-cell-pin-pvinn`,terminals:[{instanceId:`PVINN`,pinName:`P`},{instanceId:`M2`,pinName:`G`}]},{id:`net-cell-pin-pvinp`,terminals:[{instanceId:`PVINP`,pinName:`P`},{instanceId:`M1`,pinName:`G`}]},{id:`net-cell-pin-pvout`,terminals:[{instanceId:`PVOUT`,pinName:`P`},{instanceId:`M4`,pinName:`D`},{instanceId:`M2`,pinName:`D`}]},{id:`net-dut-nleft`,terminals:[{instanceId:`M3`,pinName:`D`},{instanceId:`M1`,pinName:`D`},{instanceId:`M3`,pinName:`G`},{instanceId:`M4`,pinName:`G`}]},{id:`net-dut-tail`,terminals:[{instanceId:`M5`,pinName:`D`},{instanceId:`M1`,pinName:`S`},{instanceId:`M2`,pinName:`S`}]}],noConnects:[],presentation:{cellSymbol:{minimumBodySize:{height:120,width:140},pinPlacements:[{offset:30,side:`north`,terminalId:`terminal-pvdd`},{offset:30,side:`west`,terminalId:`terminal-pvinn`},{offset:0,side:`east`,terminalId:`terminal-pvout`},{offset:0,side:`south`,terminalId:`terminal-pvss`},{offset:-20,side:`west`,terminalId:`terminal-pvinp`},{offset:-10,side:`north`,terminalId:`terminal-pibias`}]},compactness:`normal`,grid:10,styleProfileId:`razavi-textbook-v1`},revision:162,routes:[{id:`dut-vdd-port-route`,legs:[{id:`route-leg-a720db58bbd8e3ad`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-vdd`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvdd`,start:{instanceId:`PVDD`,kind:`terminal`,pinName:`P`}},{id:`dut-vdd-m3-route`,legs:[{id:`route-leg-e029990b3e5d06bc`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-vdd`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvdd`,start:{instanceId:`M3`,kind:`terminal`,pinName:`S`}},{id:`dut-vdd-m4-route`,legs:[{id:`route-leg-5b9805254e937a59`,mode:`manual`,to:{bendId:`route-bend-5b9805254e937a59`,kind:`bend`,position:{x:560,y:100}}},{id:`route-leg-5b9804254e9378a6`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-vdd`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvdd`,start:{instanceId:`M4`,kind:`terminal`,pinName:`S`}},{id:`dut-vout-port-route`,legs:[{id:`route-leg-6043a3e9d6720b4e`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-vout`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvout`,start:{instanceId:`PVOUT`,kind:`terminal`,pinName:`P`}},{id:`dut-vout-m4-route`,legs:[{id:`route-leg-ae091c386561f66a`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-vout`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvout`,start:{instanceId:`M4`,kind:`terminal`,pinName:`D`}},{id:`dut-vout-m2-route`,legs:[{id:`route-leg-109a650f1a292f40`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-vout`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvout`,start:{instanceId:`M2`,kind:`terminal`,pinName:`D`}},{id:`dut-vinp-route`,legs:[{id:`route-leg-a72f03f468a1d2f4`,mode:`manual`,to:{endpoint:{instanceId:`M1`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-cell-pin-pvinp`,start:{instanceId:`PVINP`,kind:`terminal`,pinName:`P`}},{id:`dut-vinn-route`,legs:[{id:`route-leg-d16ea816ee4bf8ce`,mode:`manual`,to:{endpoint:{instanceId:`M2`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-cell-pin-pvinn`,start:{instanceId:`PVINN`,kind:`terminal`,pinName:`P`}},{id:`dut-nleft-m3d-route`,legs:[{id:`route-leg-f449712ee4a17702`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-nleft-a`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-nleft`,start:{instanceId:`M3`,kind:`terminal`,pinName:`D`}},{id:`dut-nleft-m1d-route`,legs:[{id:`route-leg-4449fdaa3f37ea4c`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-nleft-a`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-nleft`,start:{instanceId:`M1`,kind:`terminal`,pinName:`D`}},{id:`dut-nleft-trunk-route`,legs:[{id:`route-leg-220f44782704e593`,mode:`manual`,to:{bendId:`route-bend-adb5e8be6b3344d6`,kind:`bend`,position:{x:470,y:210}}},{id:`route-leg-c5b2e6b4e8fd7635`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-nleft-b`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-nleft`,start:{junctionId:`junction-dut-nleft-a`,kind:`junction`}},{id:`dut-nleft-m3g-route`,legs:[{id:`route-leg-a7d85c5a0e43f8af`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-nleft-b`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-nleft`,start:{instanceId:`M3`,kind:`terminal`,pinName:`G`}},{id:`dut-nleft-m4g-route`,legs:[{id:`route-leg-5dee764c63230748`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-nleft-b`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-nleft`,start:{instanceId:`M4`,kind:`terminal`,pinName:`G`}},{id:`dut-tail-m5d-route`,legs:[{id:`route-leg-beabd8e3dedf141e`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-tail`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-tail`,start:{instanceId:`M5`,kind:`terminal`,pinName:`D`}},{id:`dut-tail-m1s-route`,legs:[{id:`route-leg-ada2b826f49de203`,mode:`manual`,to:{bendId:`route-bend-ada2b826f49de203`,kind:`bend`,position:{x:380,y:340}}},{id:`route-leg-ada2b726f49de050`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-tail`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-tail`,start:{instanceId:`M1`,kind:`terminal`,pinName:`S`}},{id:`dut-tail-m2s-route`,legs:[{id:`route-leg-a525c367f98f1f50`,mode:`manual`,to:{bendId:`route-bend-a525c367f98f1f50`,kind:`bend`,position:{x:560,y:340}}},{id:`route-leg-a525c467f98f2103`,mode:`manual`,to:{endpoint:{junctionId:`junction-dut-tail`,kind:`junction`},kind:`endpoint`}}],netId:`net-dut-tail`,start:{instanceId:`M2`,kind:`terminal`,pinName:`S`}},{id:`dut-vss-m5-route`,legs:[{id:`route-leg-1fd2cacc728a5fec`,mode:`manual`,to:{endpoint:{junctionId:`junction-canonical-3993d1302f152696`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pvss`,start:{instanceId:`M6`,kind:`terminal`,pinName:`S`}},{id:`dut-vss-port-route`,legs:[{id:`route-leg-9a243a8749f3f47b`,mode:`manual`,to:{endpoint:{instanceId:`PVSS`,kind:`terminal`,pinName:`P`},kind:`endpoint`}}],netId:`net-cell-pin-pvss`,start:{junctionId:`junction-canonical-3993d1302f152696`,kind:`junction`}},{id:`route-canonical-e161f2c6f556c327`,legs:[{id:`route-leg-6406fbb3dde68137`,mode:`manual`,to:{bendId:`route-bend-6406fbb3dde68137`,kind:`bend`,position:{x:480,y:490}}},{id:`route-leg-6406fab3dde67f84`,mode:`manual`,to:{endpoint:{instanceId:`M5`,kind:`terminal`,pinName:`S`},kind:`endpoint`}}],netId:`net-cell-pin-pvss`,start:{junctionId:`junction-canonical-3993d1302f152696`,kind:`junction`}},{id:`dut-ibias-port-route`,legs:[{id:`route-leg-df9387cdaaaab728`,mode:`manual`,to:{endpoint:{junctionId:`junction-canonical-a69a92ac5a85be8f`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pibias`,start:{instanceId:`PIBIAS`,kind:`terminal`,pinName:`P`}},{id:`dut-ibias-m6d-route`,legs:[{id:`route-leg-dfa853aaa4309a7e`,mode:`manual`,to:{endpoint:{instanceId:`M6`,kind:`terminal`,pinName:`D`},kind:`endpoint`}}],netId:`net-cell-pin-pibias`,start:{junctionId:`junction-canonical-a69a92ac5a85be8f`,kind:`junction`}},{id:`dut-ibias-m5g-route`,legs:[{id:`route-leg-7172d946242cfd98`,mode:`manual`,to:{bendId:`route-bend-9351f6029255a2bb`,kind:`bend`,position:{x:380,y:400}}},{id:`route-leg-a63007ca9d22b9cc`,mode:`manual`,to:{endpoint:{junctionId:`junction-canonical-0fddbcfe7d216a81`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pibias`,start:{junctionId:`junction-canonical-a69a92ac5a85be8f`,kind:`junction`}},{id:`dut-ibias-m6g-route`,legs:[{id:`route-leg-36accc90d5a60eab`,mode:`manual`,to:{endpoint:{junctionId:`junction-canonical-0fddbcfe7d216a81`,kind:`junction`},kind:`endpoint`}}],netId:`net-cell-pin-pibias`,start:{instanceId:`M6`,kind:`terminal`,pinName:`G`}},{id:`route-canonical-781ca20d250b5d82`,legs:[{id:`route-leg-77da2da4eeb4e9de`,mode:`manual`,to:{endpoint:{instanceId:`M5`,kind:`terminal`,pinName:`G`},kind:`endpoint`}}],netId:`net-cell-pin-pibias`,start:{junctionId:`junction-canonical-0fddbcfe7d216a81`,kind:`junction`}}],sourceStatus:`connectivity-modified`}],externalSubcircuitDefinitions:[{formalParameters:[{defaultValue:`1`,name:`w`},{defaultValue:`0.15`,name:`l`},{defaultValue:`1`,name:`nf`},{defaultValue:`1`,name:`m`}],id:`external-subcircuit-e5ee3d17d0c7c89a`,interfaceStatus:`declared`,name:`sky130_fd_pr__nfet_01v8`,terminals:[{direction:`passive`,id:`external-subcircuit-terminal-353df4da271bcc2b`,name:`D`},{direction:`passive`,id:`external-subcircuit-terminal-353df3da271bca78`,name:`G`},{direction:`passive`,id:`external-subcircuit-terminal-353df6da271bcf91`,name:`S`},{direction:`passive`,id:`external-subcircuit-terminal-353df5da271bcdde`,name:`B`}]},{formalParameters:[{defaultValue:`1`,name:`w`},{defaultValue:`0.15`,name:`l`},{defaultValue:`1`,name:`nf`},{defaultValue:`1`,name:`m`}],id:`external-subcircuit-27f716b14d59fc10`,interfaceStatus:`declared`,name:`sky130_fd_pr__pfet_01v8`,terminals:[{direction:`passive`,id:`external-subcircuit-terminal-7921a0096089118d`,name:`D`},{direction:`passive`,id:`external-subcircuit-terminal-79219f0960890fda`,name:`G`},{direction:`passive`,id:`external-subcircuit-terminal-79219e0960890e27`,name:`S`},{direction:`passive`,id:`external-subcircuit-terminal-79219d0960890c74`,name:`B`}]}],id:`project-native-ota-laboratory`,name:`SKY130 OTA — Open & Closed Loop`,schemaVersion:53,simulationFolders:[{id:`ota-op`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`01 Bias | Native Device OP
// 1. Adjust sources or device parameters on Canvas.
// 2. Click Run.
// 3. Open Operating Point for native model outputs; Measurements reports supply current.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
// net0 is the name the compiler prints for the unnamed Canvas IBIAS/XDUT.ibias Net.
save v(vout) v(net0) v('XDUT:tail') v('XDUT:nleft') i(VDD)
save p('XDUT:XM1:msky130_fd_pr__nfet_01v8',id) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vgs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vds) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vbs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gm) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gds) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',gmbs) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vth) p('XDUT:XM1:msky130_fd_pr__nfet_01v8',vdsat)
save p('XDUT:XM2:msky130_fd_pr__nfet_01v8',id) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',vgs) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',vds) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',vbs) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',gm) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',gds) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',gmbs) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',vth) p('XDUT:XM2:msky130_fd_pr__nfet_01v8',vdsat)
save p('XDUT:XM3:msky130_fd_pr__pfet_01v8',id) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vgs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vds) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vbs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gm) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gds) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',gmbs) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vth) p('XDUT:XM3:msky130_fd_pr__pfet_01v8',vdsat)
save p('XDUT:XM4:msky130_fd_pr__pfet_01v8',id) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',vgs) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',vds) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',vbs) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',gm) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',gds) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',gmbs) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',vth) p('XDUT:XM4:msky130_fd_pr__pfet_01v8',vdsat)
save p('XDUT:XM5:msky130_fd_pr__nfet_01v8',id) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',vgs) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',vds) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',vbs) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',gm) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',gds) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',gmbs) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',vth) p('XDUT:XM5:msky130_fd_pr__nfet_01v8',vdsat)
save p('XDUT:XM6:msky130_fd_pr__nfet_01v8',id) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',vgs) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',vds) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',vbs) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',gm) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',gds) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',gmbs) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',vth) p('XDUT:XM6:msky130_fd_pr__nfet_01v8',vdsat)
analysis bias op
postprocess(PYTHON,"report.py","ota-op")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`01 Bias | Native Device OP`,version:4},{id:`ota-dc`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`02 DC transfer
// 1. Edit the input sweep or sources on Canvas.
// 2. Click Run.
// 3. Plot output and tail against input voltage.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout) v('XDUT:tail')
alter instance("VINP") type="dc"
sweep input instance="VINP" parameter="dc" from=0.86 to=0.94 step=0.001
analysis transfer op
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`02 DC transfer`,version:4},{id:`ota-ac-tt`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`03 Open-loop AC | TT
// 1. Edit the frequency range or sources on Canvas; the folder requests its corner Profile.
// 2. Click Run.
// 3. Plot Gain in dB/phase; Measurements reports DC gain and first falling unity crossing.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
// AC is a small-signal response, not an output-swing test.
analysis frequency ac from=1 to=1G mode="dec" points=60
postprocess(PYTHON,"report.py","ota-ac")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`03 Open-loop AC | TT`,version:4},{id:`ota-ac-ff`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`04 Open-loop AC | FF
// 1. Edit the frequency range or sources on Canvas; the folder requests its corner Profile.
// 2. Click Run.
// 3. Plot Gain in dB/phase; Measurements reports DC gain and first falling unity crossing.
ground 0
include "models/library.inc" section=ff
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
// AC is a small-signal response, not an output-swing test.
analysis frequency ac from=1 to=1G mode="dec" points=60
postprocess(PYTHON,"report.py","ota-ac")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`04 Open-loop AC | FF`,version:4},{id:`ota-ac-ss`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`05 Open-loop AC | SS
// 1. Edit the frequency range or sources on Canvas; the folder requests its corner Profile.
// 2. Click Run.
// 3. Plot Gain in dB/phase; Measurements reports DC gain and first falling unity crossing.
ground 0
include "models/library.inc" section=ss
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
// AC is a small-signal response, not an output-swing test.
analysis frequency ac from=1 to=1G mode="dec" points=60
postprocess(PYTHON,"report.py","ota-ac")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`05 Open-loop AC | SS`,version:4},{id:`ota-tran`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`06 Open-loop input pulse
// 1. Edit the input pulse on Canvas or the time limits below.
// 2. Click Run.
// 3. Plot input/output and inspect the full-run output extrema.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout)
analysis step tran stop=6u step=2n maxstep=2n
postprocess(PYTHON,"report.py","ota-tran")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`06 Open-loop input pulse`,version:4},{id:`ota-noise`,input:{circuitBindings:[{documentId:`document-ota-5t-testbench`,emission:`top-level`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`07 Input and output noise
// 1. Edit frequency limits or circuit parameters on Canvas.
// 2. Click Run.
// 3. Plot native noise spectra and inspect the documented numerical integral.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
analysis spectrum noise out="vout" in="VINP" from=1 to=1G mode="dec" points=30
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`}],kind:`source`},name:`07 Input and output noise`,version:4},{id:`ota-closed`,input:{circuitBindings:[{documentId:`document-ota-5t`,emission:`subcircuit`,id:`circuit`,path:`circuit.spice`}],configPath:`experiment.json`,dependencies:[{id:`sky130-native-sections`,sha256:`64234ef53dfecb8dd6ea0094c05d65c071c0220563917b3113b78be146bc021c`,mountPath:`models/library.inc`}],entry:`run.cir`,files:[{path:`run.cir`,text:`08 Unity feedback | AC + Step
// 1. Edit the DUT on Canvas; edit sources, load and feedback in testbench.spice.
// 2. Click Run.
// 3. Plot closed-loop Gain and step; inspect the requested time-window measurements.
// Only the DUT comes from Canvas; the visible open-loop TB is not instantiated.
ground 0
include "models/library.inc" section=tt
include "circuit.spice"
include "testbench.spice"
control
abort always
options rawfile="ascii" strictsave=2 temp=27 reltol=1e-8 abstol=1e-12 vntol=1e-10
save v(vinp) v(vout) i(VDD)
analysis frequency ac from=1 to=1G mode="dec" points=60
analysis step tran stop=6u step=1n maxstep=1n
postprocess(PYTHON,"report.py","ota-closed")
endc
`},{path:`experiment.json`,text:`{
  "version": 2,
  "environment": {
    "profileId": "vacask-sky130-candidate"
  }
}
`},{path:`testbench.spice`,text:`// Text TB: preserve DUT port order vdd vss ibias vinn vinp vout.
// Connect vinn to vout for unity negative feedback.
// Voltage/current sources are native built-ins, not OSDI libraries.
load "capacitor.osdi"
model tb_voltage vsource
model tb_current isource
model tb_capacitor capacitor
VDD (vdd 0) tb_voltage dc=1.8
VINP (vinp 0) tb_voltage dc=0.9 mag=1 type="pulse" val0=0.9 val1=0.91 delay=1u rise=1n fall=1n width=2u period=5u
IBIAS (vdd ibias) tb_current dc=15u
XDUT (vdd 0 ibias vout vinp vout) ota_5t
CL (vout 0) tb_capacitor c=1p
`},{path:`report.py`,text:`"""Editable starter calculations, using this run's native ASCII outputs only.

No numpy dependency, hidden frontend evaluator, or ngspice subprocess. The
shared icm_reports.py helper reports results; it does not perform the math.
"""
from bisect import bisect_left
from math import isfinite, log10
from pathlib import Path
import sys

from icm_reports import report_measurement, report_plot


def read_ascii(path):
    lines = Path(path).read_text().splitlines()
    begin = lines.index("Variables:") + 1
    end = lines.index("Values:")
    names = [line.split()[1] for line in lines[begin:end]]
    fields = dict(line.split(":", 1) for line in lines[:begin-1] if ":" in line)
    width = int(fields["No. Variables"])
    count = int(fields["No. Points"])
    tokens = " ".join(lines[end+1:]).split()
    if len(names) != width or len(tokens) != count * (width + 1):
        raise ValueError("Incomplete native ASCII record")
    is_complex = "complex" in fields["Flags"]
    vectors = {name: [] for name in names}
    for row in range(count):
        offset = row * (width + 1)
        if int(tokens[offset]) != row:
            raise ValueError("Native point indices are not sequential")
        for name, token in zip(names, tokens[offset+1:offset+1+width]):
            value = complex(*map(float, token.split(","))) if is_complex else float(token)
            if not (isfinite(value.real) and isfinite(value.imag)):
                raise ValueError("Nonfinite native sample")
            vectors[name].append(value)
    return vectors


def sample(axis, values, target):
    """Linear interpolation between returned samples; no endpoint clamping."""
    if not axis or any(b <= a for a, b in zip(axis, axis[1:])):
        raise ValueError("Sample axis must be strictly increasing")
    if target < axis[0] or target > axis[-1]:
        raise ValueError("Measurement target is outside the returned samples")
    right = bisect_left(axis, target)
    if axis[right] == target:
        return values[right]
    left = right - 1
    return values[left] + (values[right] - values[left]) * (
        (target - axis[left]) / (axis[right] - axis[left])
    )


def window_values(axis, values, start, stop):
    window = [v for t, v in zip(axis, values) if start < t < stop]
    return window + [sample(axis, values, start), sample(axis, values, stop)]


def falling_crossing(axis, values, target):
    for i in range(1, len(values)):
        if values[i-1] > target >= values[i]:
            return axis[i-1] + (axis[i] - axis[i-1]) * (
                (target - values[i-1]) / (values[i] - values[i-1]))
    raise ValueError("No falling crossing in the returned samples")


def main():
    mode = sys.argv[1]
    if mode not in ("ac", "step", "rlc", "cs-ac", "cs-tran", "ota-op", "ota-ac", "ota-tran", "ota-closed"):
        raise ValueError("Unknown starter report mode")

    if mode in ("ac", "rlc", "cs-ac", "ota-ac", "ota-closed"):
        data = read_ascii("frequency.raw")
        frequency = [v.real for v in data["frequency"]]
        input_name, output_name = ("vinp", "vout") if mode.startswith("ota-") else ("in", "out")
        gain = [out / inp for inp, out in zip(data[input_name], data[output_name])]
        # Preserve the complex transfer. The common Plot UI supplies dB and phase
        # rather than representing already-logarithmic values as complex voltages.
        lines = ["Title: Voltage transfer", "Date: Current run", "Plotname: Gain",
                 "Flags: complex", "No. Variables: 2", f"No. Points: {len(gain)}",
                 "Variables:", "0 frequency notype", "1 Gain notype", "Values:"]
        for index, (freq, value) in enumerate(zip(frequency, gain)):
            lines.extend([f"{index} {freq:.17e},0", f" {value.real:.17e},{value.imag:.17e}"])
        Path("gain.raw").write_text("\\n".join(lines) + "\\n")
        report_plot("gain.raw", "ac", axis="frequency",
                    probes=[{"name": "Gain", "quantity": "transfer", "unit": "1"}])
        if mode == "ac":
            report_measurement("gain_at_fc", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1591.549431), "dB")
        elif mode == "cs-ac":
            report_measurement("gain_db_1khz", lambda: sample(
                frequency, [20 * log10(abs(v)) for v in gain], 1e3), "dB")
        elif mode in ("ota-ac", "ota-closed"):
            db = [20 * log10(abs(v)) for v in gain]
            report_measurement("dc_gain_db" if mode == "ota-ac" else "closed_gain_db",
                               lambda: sample(frequency, db, 1), "dB")
            if mode == "ota-ac":
                report_measurement("unity_gain_hz", lambda: falling_crossing(frequency, db, 0), "Hz")
        else:
            report_measurement("peak_gain_db", lambda: max(20 * log10(abs(v)) for v in gain), "dB")

    if mode in ("step", "rlc"):
        data = read_ascii("step.raw")
        if mode == "step":
            report_measurement("at_one_tau", lambda: sample(data["time"], data["out"], 200.05e-6), "V")
        else:
            report_measurement("peak_output", lambda: max(data["out"]), "V")
        report_measurement("final_value", lambda: sample(data["time"], data["out"], 1e-3), "V")

    if mode == "cs-tran":
        data = read_ascii("signal.raw")
        # Native outer sweeps concatenate sample groups. Preserve every returned
        # case as an explicit record, with its amplitude in the plot title. The
        # original multi-axis raw file remains available for independent inspection.
        start = 0
        for end in range(1, len(data["amplitude"]) + 1):
            if end < len(data["amplitude"]) and data["amplitude"][end] == data["amplitude"][start]:
                continue
            amplitude = data["amplitude"][start]
            time = data["time"][start:end]
            values = data["out"][start:end]
            index = start
            path = f"signal-{index}.raw"
            lines = [f"Title: Input amplitude {amplitude:g} V", "Date: Current run",
                     f"Plotname: Signal ({amplitude:g} V input)", "Flags: real",
                     "No. Variables: 3", f"No. Points: {len(time)}", "Variables:",
                     "0 time notype", "1 in notype", "2 out notype", "Values:"]
            for i, (t, inp, out) in enumerate(zip(time, data["in"][start:end], values)):
                lines.extend([f"{i} {t:.17e}", f" {inp:.17e}", f" {out:.17e}"])
            Path(path).write_text("\\n".join(lines) + "\\n")
            report_plot(path, "tran", axis="time", probes=[
                {"name": name, "quantity": "voltage", "unit": "V"} for name in ("in", "out")])
            def peak_to_peak():
                window = [v for t, v in zip(time, values) if 200e-6 < t < 400e-6]
                window.extend(sample(time, values, t) for t in (200e-6, 400e-6))
                return max(window) - min(window)
            report_measurement("output_pp", peak_to_peak, "V")
            start = end

    if mode == "ota-op":
        data = read_ascii("bias.raw")
        report_measurement("supply_current", lambda: -data["VDD:flow(br)"][0], "A")

    if mode in ("ota-tran", "ota-closed"):
        data = read_ascii("step.raw")
        if mode == "ota-tran":
            report_measurement("output_max", lambda: max(data["vout"]), "V")
            report_measurement("output_min", lambda: min(data["vout"]), "V")
        else:
            report_measurement("output_at_2us", lambda: sample(data["time"], data["vout"], 2e-6), "V")
            report_measurement("output_peak", lambda: max(window_values(data["time"], data["vout"], 1e-6, 3e-6)), "V")


if __name__ == "__main__":
    main()
`},{path:`icm_reports.py`,text:`import json as _icm_json
import math as _icm_math
from numbers import Real as _icm_Real

def report_measurement(name, evaluate, unit=""):
    if not isinstance(name, str) or not name or len(name) > 128:
        raise ValueError("Measurement name must contain 1-128 characters")
    if not isinstance(unit, str) or len(unit) > 64:
        raise ValueError("Measurement unit must be a string of at most 64 characters")
    report = {"name": name, "unit": unit}
    try:
        value = evaluate() if callable(evaluate) else evaluate
        if not isinstance(value, _icm_Real) or isinstance(value, bool):
            raise ValueError("Measurement must be a real numeric scalar")
        value = float(value)
        if not _icm_math.isfinite(value):
            raise ValueError("Measurement is not finite")
        report.update(status="available", value=value)
    except Exception as error:
        report.update(status="unavailable", detail=str(error)[:1024])
    print("ICM_MEASUREMENT_V1 " + _icm_json.dumps(report, allow_nan=False), flush=True)

import json as _icm_plot_json

def report_plot(path, analysis, axis=None, probes=(), plot_ordinal=0):
    report = {"artifactPath": path, "plotOrdinal": plot_ordinal,
              "analysis": analysis, "probes": list(probes)}
    if axis is not None:
        report["axis"] = axis
    print("ICM_PLOT_V1 " + _icm_plot_json.dumps(report, allow_nan=False), flush=True)
`}],kind:`source`},name:`08 Unity feedback | AC + Step`,version:4}],source:{dialect:`none`,entry:null,files:[],sourcePolicy:`copy`},structureRevision:85,symbolLibrary:{hash:`razavi-reference-v1`,id:`razavi-symbols`,version:`1`},topDocumentId:`document-ota-5t-testbench`}}];function Lt(e){let t=It.find(t=>t.id===e);if(!t)throw Error(`Unknown simulation example`);let n=r(JSON.stringify(t.source)),a=P(n,i(n,o)).project;return a.id=`simulation-example-${crypto.randomUUID()}`,a}function Rt({onOpen:e}){let t=Mt(),[n,r]=(0,Z.useState)(!1),[i,a]=(0,Z.useState)(``),o=async(i,o)=>{if(!n){r(!0);try{if(!await t.confirm({title:`Open ${o}?`,message:`This switches the entire Project, not just the current Cell. Unsaved changes will be checked before switching. Save any work you want to keep.`,acceptLabel:`Open example`}))return;await e(Lt(i))}catch{a(`Could not open this example.`)}finally{r(!1)}}};return(0,X.jsxs)(`div`,{className:`simulation-example-start`,children:[(0,X.jsx)(`p`,{children:`Simulate the current circuit, or define a circuit and sources in Code.`}),(0,X.jsx)(`div`,{className:`simulation-example-cards`,"aria-label":`Simulation examples`,role:`group`,children:It.map(e=>(0,X.jsxs)(`button`,{type:`button`,disabled:n,onClick:()=>void o(e.id,e.name),children:[(0,X.jsx)(`strong`,{children:e.name}),(0,X.jsx)(`span`,{children:e.description})]},e.id))}),i?(0,X.jsx)(`p`,{role:`alert`,children:i}):null]})}function zt(e,t,n=`vacask`){let r=n===`ngspice`?O(t):C(t),i=r.diagnostics.some(e=>e.severity===`error`),a=t.circuitBindings.filter(e=>r.paths.includes(e.path)),o=new Set,s=t=>{if(!o.has(t)){o.add(t);for(let n of e.documents.find(e=>e.id===t)?.instances??[])n.netlist?.binding?.kind===`subcircuit`&&s(n.netlist.binding.childDocumentId)}};a.forEach(e=>s(e.documentId));let c=r.statements.some(({statement:e})=>`tokens`in e?e.tokens[0]?.value===`alter`:e.kind===`control_command`&&/^(alter|altermod|alterparam)$/iu.test(e.command));return{documentIds:o,uncertain:i,label:i?`Circuit sources: check during Prepare`:a.length?`Canvas source: `+a.map(t=>`${e.documents.find(e=>e.id===t.documentId)?.name??t.documentId} (${t.emission===`subcircuit`?`subcircuit`:`top-level`})`).join(`, `):`Text circuit · no Canvas source`,paths:[...new Set(r.paths)].filter(e=>t.files.some(t=>t.path===e)||a.some(t=>t.path===e)),overrides:c}}function Bt({project:e,input:t,onSelectFile:n,activeDocumentId:r,engine:i}){let a=zt(e,t,i);return(0,X.jsxs)(`details`,{className:`simulation-source-context`,children:[(0,X.jsxs)(`summary`,{children:[t.entry,` · `,a.label]}),(0,X.jsx)(`div`,{children:a.paths.map(e=>(0,X.jsx)(`button`,{type:`button`,onClick:()=>n(e),children:e},e))}),!a.uncertain&&r&&!a.documentIds.has(r)?(0,X.jsx)(`p`,{children:`Current Canvas Cell is not referenced by this experiment.`}):null,(0,X.jsx)(`p`,{children:`Canvas sources are generated from the referenced Cells. Other wiring and sources belong to Code.`}),a.overrides?(0,X.jsx)(`p`,{children:`Code overrides circuit parameters for this experiment; Canvas values are unchanged.`}):null]})}function Vt(e,t){let n=O(t),r=[];for(let n of oe(e,t))for(let e of k(n))r.push({kind:`device-op`,label:`${n.reference} · ${e.slice(e.lastIndexOf(`[`)+1,-1).toUpperCase()} — ${e}`,expression:{kind:`vector`,vector:e}});for(let i of t.circuitBindings){if(!n.paths.includes(i.path))continue;let t=de(e,{format:`spice`,rootDocumentId:i.documentId});if(!t.ir)continue;let a=te(n,i,t.ir),o=we(e,i.documentId);for(let e of a){let t=e.callPath.length?`${e.callPath.join(`/`)} · `:``;for(let n of o.terminalCurrent)r.push({kind:`current`,label:t+n.label,expression:{...n.target,circuit:e}})}}let i=new Map,a=e=>{let t=e.toLowerCase();i.has(t)||i.set(t,e)},o=ue(e,t);for(let[e,t]of Object.entries(o))r.push({kind:`voltage`,label:`${t.replaceAll(`/`,` · `)} — ${e}`,expression:{kind:`vector`,vector:e}}),a(e);let s=0;for(let{statement:e}of n.statements)if(e.kind===`subckt_start`?s++:e.kind===`subckt_end`&&(s=Math.max(0,s-1)),!(s||e.kind!==`instance`)){for(let t of e.nodes)a(`v(${t})`);e.family===`voltage-source`&&a(`i(${e.name})`)}for(let e of i.values())o[e.toLowerCase()]||r.push({kind:e.startsWith(`v(`)?`voltage`:`current`,label:e,expression:{kind:`vector`,vector:e}});return r}var Ht=e=>e.entry?[e.entry]:(e.children??[]).flatMap(Ht);function Ut(e){let t=Mt(),n=(0,Z.useRef)(void 0),r=(0,Z.useRef)(void 0),[i,a]=(0,Z.useState)([]),o=e.folders?.folders??[{id:e.workspaceKey,name:e.workspaceKey,files:e.files}],s=e.folders?.activeId??e.workspaceKey,[c,l]=(0,Z.useState)({[s]:!0});(0,Z.useEffect)(()=>{if(r.current===s){r.current=void 0;return}if(!e.activePath){a([]);return}a([s+`/file/`+e.activePath]);let t=e.activePath.split(`/`).slice(0,-1);l(e=>{let n={...e,[s]:!0},r=s+`/source`;for(let e of t)r+=`/`+e,n[r]=!0;return n})},[s,e.activePath]);let u=o.map(t=>{let n=t.id===s?e.files:t.files??[],r={id:t.id+`/source`,name:`Source`,folderId:t.id,kind:`directory`,children:[],expanded:!0};for(let e of n){let n=r,i=e.path.split(`/`);for(let e of i.slice(0,-1)){let r=n.id+`/`+e,i=n.children.find(e=>e.id===r&&e.children);i||(i={id:r,name:e,folderId:t.id,kind:`directory`,children:[]},n.children.push(i)),n=i}n.children.push({id:t.id+`/file/`+e.path,name:i.at(-1),folderId:t.id,kind:`file`,file:e,entry:{kind:`source`,folderId:t.id,path:e.path}})}let i=r.children;if(i.sort((e,t)=>Number(!!t.children)-Number(!!e.children)||e.name.localeCompare(t.name)),t.id===s)for(let n of e.artifactGroups??[]){let e={id:t.id+`/`+n.key,name:n.label,folderId:t.id,kind:`directory`,children:[],tmp:!0};for(let r of n.artifacts){let i=ht(r);if(!i)continue;let a=e.children.find(e=>e.name===i);a||(a={id:e.id+`/`+i,name:i,folderId:t.id,kind:`directory`,children:[]},e.children.push(a)),a.children.push({id:t.id+`/`+n.key+`/`+r.id,name:r.name,folderId:t.id,kind:`artifact`,entry:{kind:`artifact`,groupKey:n.key,artifact:r}})}i.push(e)}return{id:t.id,name:t.name,...t.cellLabel?{cellLabel:t.cellLabel}:{},folderId:t.id,kind:`folder`,children:i,expanded:!1}}),d=new Map,f=e=>e.forEach(e=>{d.set(e.id,e),e.children&&(e.kind!==`folder`&&e.children.sort((e,t)=>Number(!!t.children)-Number(!!e.children)||e.name.localeCompare(t.name)),f(e.children))});f(u);let p=e=>c[e.id]??e.expanded??!1,m=[],h=e=>e.forEach(e=>{m.push(e),e.children&&p(e)&&h(e.children)});h(u);let g=i.filter(e=>d.has(e)),_=(e,t)=>{if(t.shiftKey&&n.current){let r=m.findIndex(e=>e.id===n.current),i=m.indexOf(e);if(r>=0){let e=m.slice(Math.min(r,i),Math.max(r,i)+1).map(e=>e.id);a(t.ctrlKey||t.metaKey?[...new Set([...g,...e])]:e);return}}n.current=e.id,a(t.ctrlKey||t.metaKey?g.includes(e.id)?g.filter(t=>t!==e.id):[...g,e.id]:[e.id])},v=(e,t=!p(e))=>l(n=>({...n,[e.id]:t})),y=t=>{t.entry?.kind===`source`?(e.onCloseArtifact?.(),e.onSelectFile(t.entry.path,t.folderId)):t.entry?.kind===`artifact`&&e.onSelectArtifact?.(t.entry.artifact)},b=(n,r,i)=>{let o=n?g.includes(n.id)?g:[n.id]:[];a(o);let c=o.map(e=>d.get(e)),u=[...new Map(c.flatMap(Ht).map(e=>[e.kind===`source`?`source/`+e.folderId+`/`+e.path:`artifact/`+e.artifact.id,e])).values()],f=[];if(u.length&&f.push({label:c.length>1?`Download selected (`+c.length+`)…`:`Download…`,disabled:!e.onDownloadSelection,run:()=>e.onDownloadSelection?.(u,c.some(e=>!!e.children))}),c.length===1&&n?.folderId===s&&(n.kind===`folder`||n.id===s+`/run`)&&f.push(...e.additionalActions??[]),c.length===1&&n?.file){if(f.push({label:`Open`,run:()=>y(n)},{label:`Copy contents`,run:()=>e.onCopyFile?.(n.file.path,n.folderId)}),n.file.kind===`authored`)for(let[t,r]of[[`rename`,`Rename…`],[`delete`,`Delete…`],[`entry`,`Use as run entry`]])f.push({label:r,run:()=>e.onFileAction?.(t,n.file.path,n.folderId)});n.file.draft&&f.push({label:`Discard draft`,run:()=>e.onFileAction?.(`discard`,n.file.path,n.folderId)})}if(e.folders){if(c.length<=1&&(!n||n.kind===`folder`||n.id.includes(`/source`))&&f.push({label:`New file…`,run:()=>{let t=n?.folderId??s;l(e=>({...e,[t]:!0})),e.onNewFile?.(t)}}),c.length===1&&n?.kind===`folder`)for(let[t,r]of[[`run`,`Run folder`],[`duplicate`,`Duplicate…`],[`rename`,`Rename…`],[`delete`,`Delete…`]])f.push({label:r,disabled:t===`run`&&e.folders.busy,run:()=>e.folders?.onAction(t,[n.folderId])});c.length>1&&c.every(e=>e.kind===`folder`)&&f.push({label:`Run selected folders (`+c.length+`)`,disabled:e.folders.busy,run:()=>e.folders?.onAction(`batch`,o)}),f.push({label:`New experiment…`,run:()=>e.folders?.onAction(`new`,[])})}f.push({label:`Collapse all`,run:()=>l(Object.fromEntries([...d.keys()].map(e=>[e,!1])))}),t.menu(r,i,f,n?.file?`Actions for `+n.file.path:`Folder actions`)},x=(n,i)=>{let a=t.edit?.folderId===n.folderId&&(n.kind===`folder`?t.edit.kind===`folder`:n.file&&t.edit.kind===`file`&&t.edit.path===n.file.path),o=n.kind===`folder`?n.folderId===s:n.entry?.kind===`source`?n.folderId===s&&n.entry.path===e.activePath&&!e.artifactPreview:n.entry?.kind===`artifact`&&n.entry.artifact.id===e.artifactPreview?.artifact.id;return(0,X.jsxs)(`div`,{className:`simulation-tree-node`,role:`none`,"aria-label":n.tmp?n.name+` temporary files`:void 0,children:[(0,X.jsxs)(`div`,{className:`simulation-tree-row`+(g.includes(n.id)?` is-selected`:``)+(o?` is-active`:``),style:{"--tree-depth":i},onContextMenu:e=>{e.preventDefault(),e.stopPropagation(),b(n,e.clientX,e.clientY)},children:[n.children?(0,X.jsx)(`button`,{type:`button`,className:`simulation-tree-chevron`,tabIndex:-1,"aria-label":`Toggle `+n.name,"aria-expanded":p(n),onClick:e=>{e.stopPropagation(),v(n)},children:(0,X.jsx)(`svg`,{viewBox:`0 0 16 16`,"aria-hidden":`true`,children:(0,X.jsx)(`path`,{d:p(n)?`m4 6 4 4 4-4`:`m6 4 4 4-4 4`})})}):(0,X.jsx)(`span`,{className:`simulation-tree-chevron`}),a?(0,X.jsx)(Pt,{}):(0,X.jsxs)(`button`,{type:`button`,role:`treeitem`,"aria-level":i+1,"aria-selected":g.includes(n.id),"aria-expanded":n.children?p(n):void 0,"data-tree-row":n.kind,"data-node-id":n.id,"data-folder-id":n.folderId,"data-file-path":n.file?.path,"aria-label":n.kind===`folder`?`Folder `+n.name:n.name,"aria-current":o?`page`:void 0,title:n.cellLabel??n.file?.path??n.name,"aria-description":n.cellLabel,onClick:t=>{_(n,t),!t.ctrlKey&&!t.metaKey&&!t.shiftKey&&(n.kind===`folder`?(n.folderId!==s&&(r.current=n.folderId),e.folders?.onSelect(n.folderId)):n.children?v(n):y(n))},onKeyDown:t=>{if((t.key===`ArrowLeft`||t.key===`ArrowRight`)&&(t.preventDefault(),n.children&&v(n,t.key===`ArrowRight`)),(t.key===`F2`||t.key===`Delete`)&&(t.preventDefault(),n.kind===`folder`?e.folders?.onAction(t.key===`F2`?`rename`:`delete`,[n.folderId]):n.file?.kind===`authored`&&e.onFileAction?.(t.key===`F2`?`rename`:`delete`,n.file.path,n.folderId)),t.key===`ContextMenu`||t.shiftKey&&t.key===`F10`){t.preventDefault();let e=t.currentTarget.getBoundingClientRect();b(n,e.left,e.bottom)}},children:[(0,X.jsx)(`span`,{className:`simulation-tree-icon`,"aria-hidden":`true`,children:(0,X.jsx)(`svg`,{viewBox:`0 0 16 16`,children:(0,X.jsx)(`path`,{d:n.children?`M2 4h4l2 2h6v7H2z`:n.file?.kind===`generated`?`m8 2 5 6-5 6-5-6z`:`M4 2h5l3 3v9H4z M9 2v4h3`})})}),(0,X.jsx)(`span`,{className:`simulation-file-name`,children:n.name}),n.tmp?(0,X.jsx)(`small`,{children:`tmp`}):null,n.file?.dirty?(0,X.jsx)(`span`,{className:`simulation-file-state`,title:`Unsaved`,children:`●`}):n.file?.draft?(0,X.jsx)(`span`,{className:`simulation-file-state`,title:`Saved draft`,children:`◌`}):null]})]}),n.children&&p(n)?(0,X.jsxs)(`div`,{role:`group`,"aria-label":n.name+` files`,children:[n.kind===`folder`&&t.edit?.kind===`file`&&t.edit.folderId===n.folderId&&!t.edit.path?(0,X.jsx)(`div`,{className:`simulation-tree-row`,style:{"--tree-depth":i+1},children:(0,X.jsx)(Pt,{})}):null,n.children.map(e=>x(e,i+1))]}):null]},n.id)};return(0,X.jsxs)(`div`,{className:`simulation-folder-tree`,role:`tree`,"aria-label":`Simulation folders`,"aria-multiselectable":`true`,onContextMenu:e=>{e.preventDefault(),b(void 0,e.clientX,e.clientY)},onClick:e=>{e.target===e.currentTarget&&a([])},onKeyDown:e=>{if(!((e.ctrlKey||e.metaKey)&&[`s`,`w`].includes(e.key.toLowerCase()))&&(e.stopPropagation(),!(e.target instanceof HTMLInputElement||e.target instanceof HTMLSelectElement)&&((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`a`&&(e.preventDefault(),a(m.map(e=>e.id))),e.key===`Escape`&&(e.preventDefault(),a([])),[`ArrowUp`,`ArrowDown`,`Home`,`End`].includes(e.key)))){e.preventDefault();let t=[...e.currentTarget.querySelectorAll(`[data-node-id]`)],n=t.indexOf(document.activeElement),r=e.key===`Home`?0:e.key===`End`?t.length-1:Math.max(0,Math.min(t.length-1,n+(e.key===`ArrowDown`?1:-1)));t[r]?.focus();let i=d.get(t[r]?.dataset.nodeId??``);i&&_(i,e)}},children:[e.folders?(0,X.jsx)(`button`,{type:`button`,"data-workspace-new-folder":`true`,onClick:()=>e.folders?.onAction(`new`,[]),children:`+ New experiment`}):null,t.edit?.kind===`folder`&&!t.edit.folderId?(0,X.jsx)(Pt,{}):null,u.map(e=>x(e,0))]})}var Wt=(0,Z.createContext)(null);function Gt(e){let[t,n]=(0,Z.useState)(null),r=Mt(),i=(0,Z.useId)(),a=()=>e.files.filter(t=>t.kind===`generated`||t.path===e.entryPath).map(e=>e.path),[o,s]=(0,Z.useState)(!!e.folders),[c,l]=(0,Z.useState)({}),u=c[e.workspaceKey]??a(),d=t=>l(n=>({...n,[e.workspaceKey]:typeof t==`function`?t(n[e.workspaceKey]??a()):t})),[f,p]=(0,Z.useState)(()=>{try{return Math.max(110,Math.min(420,Number(localStorage.getItem(`icm.code.files-width`))||240))}catch{return 240}}),[m,h]=(0,Z.useState)(38),[g,_]=(0,Z.useState)(!1);(0,Z.useEffect)(()=>{e.activePath&&d(t=>t.includes(e.activePath)?t:[...t,e.activePath])},[e.activePath,e.workspaceKey]),(0,Z.useEffect)(()=>{r.edit&&s(!0)},[r.edit]),(0,Z.useEffect)(()=>{try{localStorage.setItem(`icm.code.files-width`,String(f))}catch{}},[f]);let v=u.filter(t=>e.files.some(e=>e.path===t)),y=(t,n)=>{(!n||n===e.folders?.activeId)&&d(e=>e.includes(t)?e:[...e,t]),e.onCloseArtifact?.(),e.onSelectFile(t,n),r.closeMenu()},b=t=>{let n=v.filter(e=>e!==t);d(n),e.activePath===t&&e.onSelectFile(n.at(-1)??``)},x=()=>{d([]),e.onSelectFile(``),e.onCloseArtifact?.()},S=(t,n,i)=>r.menu(n,i,[{label:`Close`,run:()=>t===null?e.onCloseArtifact?.():b(t)},{label:`Close others`,disabled:v.length+Number(!!e.artifactPreview)<=1,run:()=>{d(t===null?[]:[t]),e.onSelectFile(t??``),t!==null&&e.onCloseArtifact?.()}},{label:`Close all`,run:x}],`Editor tab actions`),ee=e=>({onContextMenu:t=>{t.preventDefault(),t.stopPropagation(),S(e,t.clientX,t.clientY)},onKeyDown:t=>{if(t.key===`ContextMenu`||t.shiftKey&&t.key===`F10`){t.preventDefault(),t.stopPropagation();let n=t.currentTarget.getBoundingClientRect();S(e,n.left,n.bottom)}}});return(0,X.jsxs)(`section`,{className:`simulation-code-workspace${e.maximized?` is-maximized`:``}`,"aria-label":`Simulation Code workspace`,onKeyDown:t=>{t.defaultPrevented||((t.ctrlKey||t.metaKey)&&t.key.toLowerCase()===`s`&&(t.preventDefault(),t.stopPropagation(),e.onSave()),(t.ctrlKey||t.metaKey)&&t.key.toLowerCase()===`w`&&(t.preventDefault(),t.stopPropagation(),e.artifactPreview?e.onCloseArtifact?.():e.activePath&&b(e.activePath)))},children:[(0,X.jsxs)(`header`,{className:`simulation-code-toolbar simulation-taskbar`,children:[(0,X.jsx)(`button`,{type:`button`,"aria-expanded":o,"aria-controls":i,onClick:()=>s(!o),children:`Explorer`}),(0,X.jsx)(`div`,{className:`simulation-code-actions`,children:e.actions}),e.toolbarEnd]}),(0,X.jsxs)(`div`,{className:`simulation-code-source-area`,children:[o?(0,X.jsxs)(`aside`,{id:i,className:`simulation-code-files`,style:{width:f},"aria-label":`Simulation files`,children:[(0,X.jsx)(Ut,{...e,onSelectFile:y}),e.history]}):null,o?(0,X.jsx)(`div`,{className:`workspace-files-resizer`,role:`separator`,tabIndex:0,"aria-label":`Resize simulation files`,"aria-orientation":`vertical`,"aria-valuemin":110,"aria-valuemax":420,"aria-valuenow":f,onDoubleClick:()=>p(240),onKeyDown:e=>{(e.key===`ArrowLeft`||e.key===`ArrowRight`)&&(e.preventDefault(),e.stopPropagation(),p(t=>Math.max(110,Math.min(420,t+(e.key===`ArrowRight`?10:-10)))))},onPointerDown:e=>{let t=e.currentTarget,n=t.parentElement.getBoundingClientRect(),r=Math.max(110,Math.min(420,n.width-180));t.setPointerCapture(e.pointerId);let i=e=>p(Math.max(110,Math.min(r,e.clientX-n.left))),a=()=>{t.removeEventListener(`pointermove`,i),t.removeEventListener(`pointerup`,a),t.removeEventListener(`pointercancel`,a),t.removeEventListener(`lostpointercapture`,a)};t.addEventListener(`pointermove`,i),t.addEventListener(`pointerup`,a),t.addEventListener(`pointercancel`,a),t.addEventListener(`lostpointercapture`,a)}}):null,(0,X.jsxs)(`div`,{className:`simulation-code-document`,children:[(0,X.jsxs)(`div`,{className:`simulation-code-document-header`,children:[(0,X.jsxs)(`div`,{className:`simulation-code-tabs`,role:`tablist`,"aria-label":`Open simulation files`,children:[e.artifactPreview?(0,X.jsxs)(`div`,{className:`simulation-code-tab simulation-artifact-tab`,...ee(null),children:[(0,X.jsxs)(`button`,{type:`button`,role:`tab`,"aria-selected":`true`,children:[e.artifactPreview.artifact.name,(0,X.jsx)(`span`,{children:` tmp`})]}),(0,X.jsx)(`button`,{type:`button`,"aria-label":`Close ${e.artifactPreview.artifact.name}`,onClick:e.onCloseArtifact,children:`×`})]}):null,v.map(t=>{let n=e.files.find(e=>e.path===t);return(0,X.jsxs)(`div`,{className:`simulation-code-tab`,...ee(t),children:[(0,X.jsxs)(`button`,{type:`button`,role:`tab`,"aria-selected":!e.artifactPreview&&e.activePath===t,onClick:()=>{e.onCloseArtifact?.(),e.onSelectFile(t)},title:t,children:[t===e.configPath?`Configuration`:t.split(`/`).at(-1),n.kind===`generated`?` ◇`:``,n.dirty?` ●`:n.draft?` ◌`:``]}),(0,X.jsx)(`button`,{type:`button`,"aria-label":`Close ${t}`,onClick:()=>b(t),children:`×`})]},t)})]}),(0,X.jsx)(`div`,{className:`simulation-code-document-actions`,hidden:!e.activePath||!!e.artifactPreview,ref:n})]}),e.sourceContext,(0,X.jsxs)(`div`,{className:`simulation-code-document-content`,children:[(0,X.jsx)(`div`,{hidden:!e.activePath||!!e.artifactPreview,className:`workspace-editor-content`,children:(0,X.jsx)(Wt.Provider,{value:t,children:e.children})}),e.artifactPreview?(0,X.jsxs)(`section`,{className:`simulation-artifact-editor`,"aria-label":`File preview`,children:[(0,X.jsxs)(`header`,{children:[(0,X.jsxs)(`span`,{children:[`Read-only · tmp`,e.artifactPreview.truncated?` · First 64 KB`:``]}),(0,X.jsx)(`button`,{type:`button`,disabled:e.artifactBusy!==void 0,onClick:()=>e.onDownloadArtifact?.(e.artifactPreview.artifact),children:`Download`})]}),(0,X.jsx)(`pre`,{children:pt(e.artifactPreview)})]}):e.activePath?null:(0,X.jsx)(`p`,{className:`workspace-empty-editor`,children:`Select a file to edit. Closing tabs does not delete files.`})]})]})]}),(0,X.jsx)(`div`,{className:`simulation-code-output-resizer`,role:`separator`,"aria-label":`Resize code results`,"aria-orientation":`horizontal`,tabIndex:0,"aria-valuemin":15,"aria-valuemax":75,"aria-valuenow":m,onKeyDown:e=>{(e.key===`ArrowUp`||e.key===`ArrowDown`)&&(e.preventDefault(),e.stopPropagation(),h(t=>Math.max(15,Math.min(75,t+(e.key===`ArrowUp`?5:-5)))))},onPointerDown:e=>{let t=e.currentTarget,n=t.parentElement.getBoundingClientRect();t.setPointerCapture(e.pointerId);let r=e=>h(Math.max(15,Math.min(75,(n.bottom-e.clientY)/n.height*100))),i=()=>{t.removeEventListener(`pointermove`,r),t.removeEventListener(`pointerup`,i),t.removeEventListener(`pointercancel`,i),t.removeEventListener(`lostpointercapture`,i)};t.addEventListener(`pointermove`,r),t.addEventListener(`pointerup`,i),t.addEventListener(`pointercancel`,i),t.addEventListener(`lostpointercapture`,i)}}),(0,X.jsxs)(`section`,{className:`simulation-code-output`,style:{flexBasis:e.maximized?`auto`:g?`32px`:`${m}%`},"aria-label":`Code output`,children:[(0,X.jsxs)(`header`,{className:`simulation-code-output-tabs`,children:[(0,X.jsx)(`div`,{role:`tablist`,"aria-label":`Code output view`,children:[`specs`,`console`].map(t=>(0,X.jsx)(`button`,{type:`button`,role:`tab`,"aria-selected":t===e.outputPane,onClick:()=>{e.onSelectOutputPane(t),_(!1)},children:{console:`Console`,specs:`Specs`}[t]},t))}),(0,X.jsx)(`span`,{className:`simulation-code-output-spacer`}),(0,X.jsx)(`button`,{type:`button`,"aria-label":g?`Expand code output`:`Collapse code output`,onClick:()=>_(!g),children:g?`⌃`:`⌄`}),e.onToggleMaximize?(0,X.jsx)(`button`,{type:`button`,"aria-label":e.maximized?`Restore results`:`Maximize results`,onClick:()=>{_(!1),e.onToggleMaximize?.()},children:e.maximized?`⧉`:`□`}):null]}),g?null:(0,X.jsx)(`div`,{className:`simulation-code-output-content`,role:`tabpanel`,children:e.outputPane===`console`?e.console:e.results})]}),e.status?(0,X.jsx)(`footer`,{className:`simulation-code-status`,children:e.status}):null]})}var Kt=Je.define(),qt=W.define({combine:e=>e[0]??!0}),Jt=W.define({combine:e=>e[0]??[]}),Yt=u;function Xt(e){let t=e.selection.main.head,n=e.doc.toString(),r=w(`editor`,n,e.facet(qt));if(r.comments.some(e=>t>=e.start&&t<=e.end))return null;let i=e.doc.lineAt(t),a=r.statements.find(e=>e.sourceRef.start.offset<=t&&(e.sourceRef.end.offset>=t||e.sourceRef.end.line===i.number));if(!a)return null;let o=y(n,a.tokens),s=o[0]?.value,c=u(n.slice(0,a.sourceRef.start.offset),e.facet(qt))?`control`:`circuit`,l=s?_(s,c):void 0,d=l?.parameters??[],f=o.slice(1);if(s===`analysis`&&c===`control`&&o[2]){let e=_(`analysis ${o[2].value}`,c);e&&(l=e,d=[{label:`name`},{label:`type`,choices:[`op`,`ac`,`tran`,`noise`]},...e.parameters??[]])}else if(!l&&c===`circuit`&&a.tokens[1]?.value===`(`){let t=x([{text:n,entry:e.facet(qt)},...e.facet(Jt).map(e=>({text:e,entry:!1}))]).models.get(o[2]?.value??``),r=o.find(e=>/^type\s*=/u.test(e.value))?.value.split(`=`)[1]?.trim().replace(/^"|"$/gu,``);d=[{label:`(ordered nodes)`},{label:`master`},...ee(t,r)],l={name:s,context:c,signature:`name (nodes) master name=value ...`,summary:`Instance node order comes from its master. Source AC uses mag/phase alongside its selected transient type.`,section:`cir-instance`,group:`Sources & loads`,parameters:d}}if(!l||!d.length)return null;let p=d.filter(e=>!e.key&&!e.repeat),m=d.find(e=>e.repeat),h=new Set,g=f.map((e,t)=>{if(t<p.length)return p[t];let n=/^([^=\s]+)\s*=/u.exec(e.value)?.[1];return n&&h.add(n),d.find(e=>e.key===n&&e.key!==void 0)??m??{label:`name=value`}});g.push(...p.slice(f.length),...d.filter(e=>e.key&&!h.has(e.key))),m&&g.push(m);let v=f.findIndex(e=>t>=e.from&&t<=e.to),b=f.at(-1);return v<0&&b&&/=$/u.test(b.value)&&t>=b.to&&/^\s*$/u.test(n.slice(b.to,t))&&(v=f.length-1),{line:i,help:l,tokens:f,index:v<0?f.length:v,parameters:g}}var Zt=class extends R{text;constructor(e){super(),this.text=e}eq(e){return this.text===e.text}toDOM(){let e=document.createElement(`span`);return e.className=`simulation-parameter-ghost`,e.textContent=this.text,e.setAttribute(`aria-hidden`,`true`),e.contentEditable=`false`,e}ignoreEvent(){return!0}},Qt=He.define({create:()=>!1,update(e,t){t.selection&&t.startState.doc.lineAt(t.startState.selection.main.head).number!==t.state.doc.lineAt(t.state.selection.main.head).number&&(e=!1),t.docChanged&&t.newDoc.lines!==t.startState.doc.lines&&(e=!1);for(let n of t.effects)n.is(Kt)&&(e=n.value);return e}}),$t=z.decorations.compute([`doc`,`selection`,Qt],e=>{if(e.field(Qt))return ke.none;let t=Xt(e);if(!t)return ke.none;let n=t.parameters.slice(t.tokens.length);if(!n.length)return ke.none;let r=`  `+n.map(e=>e.optional?`[${e.label}]`:`‹${e.choices?.join(`|`)??e.label}›`).join(`  `);return ke.set([ke.widget({widget:new Zt(r),side:1}).range(t.line.to)])});function en(e,t,n,r){let i=e.state.doc.lineAt(e.state.selection.main.head),a=n??i.from,o=r??i.to,s=S(t,e.state.doc.toString(),e.state.facet(qt));e.dispatch({changes:{from:a,to:o,insert:s},selection:{anchor:a+(t.primitive?s.indexOf(`()`)+1:s.length)},effects:Kt.of(!1),userEvent:`input.complete`}),e.focus()}function tn(e){let t=G(e);return!Xt(e.state)||e.state.field(Qt,!1)?t:(e.dispatch({effects:Kt.of(!0)}),!0)}var nn=[Qt,$t,V.of([{key:`Escape`,run:tn},{key:`Tab`,run(e){let t=Xt(e.state);if(!t||e.state.field(Qt))return!1;let n=t.tokens[t.index];if(!n)return t.parameters[t.index]?.optional?(e.dispatch({effects:Kt.of(!0)}),!0):t.index<t.parameters.length;let r=t.tokens[t.index+1];if(r)e.dispatch({selection:{anchor:r.from,head:r.to}});else if(t.index+1<t.parameters.length)e.dispatch({changes:{from:n.to,insert:` `},selection:{anchor:n.to+1}});else return!1;return!0}},{key:`Shift-Tab`,run(e){let t=Xt(e.state),n=t?.tokens[t.index-1];return!n||e.state.field(Qt)?!1:(e.dispatch({selection:{anchor:n.from,head:n.to}}),!0)}}])],rn=K.define({name:`vacask`,startState:()=>({blockComment:!1,longString:null}),token(e,t){if(t.longString)return e.match(`>>>${t.longString}`)?t.longString=null:e.skipToEnd(),`string`;if(t.blockComment)return e.match(`*/`)?t.blockComment=!1:e.next(),`comment`;if(e.eatSpace())return null;if(e.match(`//`))return e.skipToEnd(),`comment`;if(e.match(`/*`))return t.blockComment=!0,`comment`;let n=e.match(/^<<<([A-Za-z0-9_]+)/u);if(Array.isArray(n))return t.longString=n[1],e.skipToEnd(),`string`;if(e.match(/^"(?:[^"\\]|\\.)*"/u))return`string`;if(e.match(/^'(?:[^']|'')*'/u))return`variableName`;if(e.match(/^(?:0[xX][0-9a-fA-F]+|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+|[a-zA-Z]+)?)/u))return`number`;let r=e.match(/^[@$a-zA-Z_][\w$]*/u);return Array.isArray(r)?[`analysis`,`sweep`,`parameters`,`model`,`subckt`,`ends`,`include`,`load`,`ground`,`global`,`control`,`endc`,`save`,`options`,`alter`,`var`,`clear`,`abort`,`@if`,`@else`,`@end`].includes(r[0])?`keyword`:e.match(/^\s*=/u,!1)?`propertyName`:`variableName`:e.match(/^[{}()[\]]/u)?`bracket`:e.match(/^[=+*/^<>!?:;,\-]/u)?`operator`:(e.next(),null)},languageData:{commentTokens:{line:`//`,block:{open:`/*`,close:`*/`}}}});function an(e,t=[],n){let r=e.state.doc.toString(),i=e.state.facet(qt),a=w(`completion`,r,i),o=e.state.doc.lineAt(e.pos);if(i&&o.number===1||a.comments.some(t=>e.pos>=t.start&&e.pos<=t.end))return null;let s=e.matchBefore(/[\w$]+/u),c=o.text.slice(0,e.pos-o.from),l=/^\s*[\w$]*$/u.test(c),u=Xt(e.state);if(!l&&u){let a=u.parameters[u.index];if(!a)return null;let o=u.tokens[u.index],s=o?.value.indexOf(`=`)??-1,c=o&&s>=0?o.from+s+1+(r.slice(o.from+s+1,e.pos).match(/^\s*/u)?.[0].length??0):void 0,l=e=>a.key&&c===void 0?`${a.key}=${e}`:e;if(a.choices)return{from:c??o?.from??e.pos,options:a.choices.map(e=>({label:l(e),type:`enum`}))};if(a.symbols){let s=x([{text:r,entry:i},...t.map(e=>({text:e,entry:!1}))]),u=a.symbols===`vector`?n?.()??{}:{},d=new Map,f=(e,t)=>{let n=a.symbols===`vector`?JSON.stringify(w(`selector`,`save ${e}`).statements[0]?.tokens.map(e=>[e.kind,e.value])):e;d.has(n)||d.set(n,{label:e,type:`variable`,...t?{detail:t}:{}})};if(a.symbols===`vector`){f(`default`),f(`full`);for(let[e,t]of Object.entries(u))f(e,t),e.startsWith(`v(`)&&f(`d${e}`,`${t} · AC phasor`);for(let e of s.nodes)f(`v(${T(e)})`),f(`dv(${T(e)})`,`AC phasor`);for(let[e,t]of s.instances){let n=s.models.get(t??``);(n===`vsource`||n===`inductor`)&&(f(`i(${T(e)})`,`Native branch flow`),f(`di(${T(e)})`,`AC branch phasor`))}}else if(a.symbols===`node`)for(let e of s.nodes)f(l(a.key?JSON.stringify(e):T(e)));else for(let[e,t]of s.instances)a.key===`in`&&![`vsource`,`isource`].includes(s.models.get(t??``)??``)||f(l(JSON.stringify(e)));return{from:c??o?.from??e.pos,options:[...d.values()]}}let d=u.parameters.slice(u.tokens.length).filter(e=>e.key);return d.length?{from:o?.from??e.pos,options:d.map(e=>({label:`${e.key}=`,type:`property`,detail:e.label}))}:null}if(!l||!e.explicit&&!s)return null;let d=Yt(r.slice(0,o.from),i)?`control`:`circuit`;return{from:s?.from??e.pos,options:m.filter(e=>e.context===d).map(e=>({label:e.name,type:`keyword`,detail:e.signature,info:e.summary,apply:(t,n,r,i)=>en(t,e,r,i)})),validFor:/^[\w$]*$/u}}var on=Ne((e,t)=>{let n=e.state.doc.toString(),r=e.state.doc.lineAt(t),i=e.state.facet(qt),a=w(`hover`,n,i);if(i&&r.number===1||a.comments.some(e=>t>=e.start&&t<=e.end))return null;let o=[...r.text.matchAll(/[a-zA-Z_][\w]*/gu)].find(e=>r.from+e.index<=t&&r.from+e.index+e[0].length>=t);if(!o)return null;let s=Yt(n.slice(0,r.from),i)?`control`:`circuit`,c=_(o[0],s)??(r.text.trimStart().startsWith(`analysis `)?_(`analysis ${o[0]}`,s):void 0);return c?{pos:r.from+o.index,end:r.from+o.index+o[0].length,above:!0,create(){let e=document.createElement(`div`);e.className=`simulation-code-help`;let t=document.createElement(`code`);t.textContent=c.signature;let n=document.createElement(`p`);n.textContent=c.summary;let r=document.createElement(`a`);return r.href=f+c.section+`.md`,r.target=`_blank`,r.rel=`noopener noreferrer`,r.textContent=`VACASK reference`,e.append(t,n,r),{dom:e}}}:null});function sn(e){return e.replace(/\r\n?/gu,`
`)}function cn(e,t){let n=0,r=0;for(;n<t&&r<e.length;)r+=e[r]===`\r`&&e[r+1]===`
`?2:1,n++;return r}function ln(e,t){let n=0,r=0;for(;r<Math.min(t,e.length);)r+=e[r]===`\r`&&e[r+1]===`
`?2:1,n++;return n}function un(e,t){let n=/\r\n|\r|\n/u.exec(e)?.[0]??`
`,r=e;for(let i of[...t].sort((e,t)=>t.from-e.from))r=r.slice(0,cn(e,i.from))+sn(i.text).replace(/\n/gu,n)+r.slice(cn(e,i.to));return r}var dn=Je.define(),fn=Je.define();function pn(e,t){let n=[];return t.changes.iterChanges((e,t,r,i,a)=>n.push({from:e,to:t,text:a.toString()})),un(e,n)}var mn=He.define({create:()=>``,update(e,t){let n=t.effects.filter(e=>e.is(dn));if(n.length)return n.at(-1).value;let r=t.effects.filter(e=>e.is(fn)).at(-1)?.value;if(r!==void 0){let e=0;return t.newDoc.toString().replace(/\n/gu,()=>{let t=r[e++];return t===`c`?`\r
`:t===`r`?`\r`:`
`})}return t.docChanged?pn(e,t):e}}),hn=Pe.of(e=>e.docChanged?[fn.of((e.startState.field(mn).match(/\r\n|\r|\n/gu)??[]).map(e=>e===`\r
`?`c`:e===`\r`?`r`:`n`).join(``))]:[]);function gn({control:e,language:t=`native`,actions:n=[],onChoose:r,onClose:i}){let[a,o]=(0,Z.useState)(``),[s,c]=(0,Z.useState)(0),l=(0,Z.useRef)(null),u=a.trim().toLowerCase().split(/\s+/u),d=e=>u.every(t=>e.toLowerCase().includes(t)),f=(t===`ngspice`?N.filter(e=>e.context===`deck`||e.context===`control`).map(e=>({...e,context:e.context===`deck`?`circuit`:`control`,group:e.group??`ngspice`})):m).filter(()=>t!==`json`).filter(t=>t.context===(e?`control`:`circuit`)).filter(e=>d(`${e.name} ${e.summary} ${e.keywords}`)),p=[...n.filter(e=>d(`${e.label} ${e.keywords}`)).map(e=>({key:e.id,label:e.label,detail:``,group:`Signals`,run:e.run})),...f.map(e=>({key:`${e.context}:${e.name}`,label:e.name,detail:e.signature,group:e.group,run:()=>r(e)}))];(0,Z.useEffect)(()=>{let e=e=>{!l.current?.contains(e.target)&&!e.target.closest?.(`[data-simulation-helper-trigger]`)&&i(!1)};return document.addEventListener(`pointerdown`,e),()=>document.removeEventListener(`pointerdown`,e)},[i]);let h=e=>{p[e]&&(p[e].run(),i(!1))};return(0,Z.useEffect)(()=>{l.current?.querySelector(`[aria-selected="true"]`)?.scrollIntoView({block:`nearest`})},[s,a]),(0,X.jsxs)(`div`,{ref:l,className:`simulation-helper-list`,role:`dialog`,"aria-label":`Insert / Helper`,onKeyDown:e=>{e.stopPropagation(),e.key===`Escape`&&(e.preventDefault(),i()),e.key===`ArrowDown`&&(e.preventDefault(),c(e=>Math.min(e+1,p.length-1))),e.key===`ArrowUp`&&(e.preventDefault(),c(e=>Math.max(0,e-1))),e.key===`Enter`&&(e.preventDefault(),h(s))},children:[(0,X.jsx)(`input`,{autoFocus:!0,"aria-label":`Search commands or purpose`,autoComplete:`off`,placeholder:`Search commands or purpose… / 搜索用途`,value:a,onChange:e=>{o(e.currentTarget.value),c(0)}}),(0,X.jsxs)(`div`,{className:`simulation-helper-options`,role:`listbox`,"aria-label":`Helpers`,children:[p.map((e,t)=>(0,X.jsxs)(`div`,{children:[p[t-1]?.group!==e.group&&(0,X.jsx)(`div`,{className:`simulation-helper-group`,children:e.group}),(0,X.jsxs)(`button`,{type:`button`,role:`option`,"aria-selected":s===t,onMouseEnter:()=>c(t),onClick:()=>h(t),children:[(0,X.jsx)(`span`,{children:e.label}),(0,X.jsx)(`small`,{children:e.detail})]})]},e.key)),!p.length&&(0,X.jsx)(`p`,{children:`No matching helper. You can keep writing native VACASK.`})]})]})}var _n=Me.define();function vn(e){let t=(0,Z.useContext)(Wt),n=(0,Z.useRef)(null),[r,i]=(0,Z.useState)(!1),[a,o]=(0,Z.useState)(!1),[s,c]=(0,Z.useState)(``);(0,Z.useEffect)(()=>{i(!1),n.current=null},[e.path,e.historyKey]);let l=(0,Z.useRef)(null),u=(0,Z.useRef)(null),d=(0,Z.useRef)(void 0),f=(0,Z.useRef)(e);f.current=e;let p=(0,Z.useRef)(e.text),m=(0,Z.useRef)(`${e.path}\u0000${e.historyKey}`),h=(0,Z.useRef)(new Map),g=(0,Z.useRef)(()=>U.create()),_=(0,Z.useRef)(new je),v=()=>yn(f,p),y=JSON.stringify(e.relatedSources);(0,Z.useLayoutEffect)(()=>{if(!l.current)return;g.current=(e,t=0)=>U.create({doc:sn(e),selection:{anchor:Math.min(t,sn(e).length)},extensions:[et(),Ae(),Re(),B(),Ie(),mn.init(()=>e),hn,Qe(),Ge(),Ze(H),dt(),_.current.of(v()),z.contentAttributes.of({"aria-label":`Simulation source editor`,spellcheck:`false`,"data-simulation-code-input":`true`}),V.of([{key:`Mod-s`,run:()=>(f.current.onSave?.(),!0)},{key:`Mod-Enter`,run:()=>(f.current.onRun?.(),!0)},...We.map(e=>{let t=e.run;return t!==$e&&t!==Xe?e:{...e,run:e=>(t(e)||f.current.onHistoryBoundary?.(t===$e?`undo`:`redo`),!0)}}),...Le,...Ue,...Fe,...it,Be]),U.changeFilter.of(e=>{if(!e.docChanged||e.annotation(_n))return!0;let t=pn(e.startState.field(mn),e);return f.current.acceptChange?.(t)===!1?(f.current.onRejectedChange?.(),!1):!f.current.readOnly}),z.updateListener.of(e=>{if(n.current?.path===f.current.path&&e.docChanged&&(n.current.offset=e.changes.mapPos(n.current.offset)),e.docChanged&&(p.current=e.state.field(mn),e.transactions.some(e=>e.docChanged&&!e.annotation(_n))&&f.current.onChange(p.current)),(e.selectionSet||e.docChanged)&&f.current.onCursor?.(cn(p.current,e.state.selection.main.head)),e.selectionSet||e.docChanged){let t=f.current.mode===`json`?null:f.current.mode===`ngspice`?ct(e.state):Xt(e.state);c(t?.parameters[t.index]?.label??``);let n=e.state.doc.lineAt(e.state.selection.main.head).text.trim();o(/^[\p{L}]{2,}$/u.test(n)&&!(f.current.mode===`ngspice`?at:an)(new qe(e.state,e.state.selection.main.head,!0))?.options.some(e=>e.label.toLowerCase().startsWith(n.toLowerCase())))}})]}),p.current=f.current.text;let e=new z({parent:l.current,state:g.current(p.current)});return u.current=e,()=>{u.current?.destroy(),u.current=null}},[]),(0,Z.useLayoutEffect)(()=>{let t=u.current;if(!t)return;let n=`${e.path}\u0000${e.historyKey}`;if(n!==m.current){h.current.set(m.current,{state:t.state,scroll:t.scrollSnapshot()});let r=m.current.split(`\0`)[0]===e.path,i=r?t.state.selection.main.head:0,a=h.current.get(n),o=a?.state.field(mn)===e.text,s=o?a.scroll:r&&t.state.field(mn)===e.text?t.scrollSnapshot():void 0,c=t.hasFocus;p.current=e.text;let y=o?a.state:g.current(e.text,i);t.destroy(),t=new z({parent:l.current,state:y,...s?{scrollTo:s}:{}}),u.current=t,t.dispatch({effects:_.current.reconfigure(v())});let b=e.reveal?.focus===!1&&e.reveal.requestId!==d.current;(c||!r&&!b)&&t.focus(),f.current.onCursor?.(cn(e.text,t.state.selection.main.head));for(let t of h.current.keys())t!==n&&t.split(`\0`)[0]===e.path&&h.current.delete(t);m.current=n}else e.text!==p.current&&(p.current=e.text,t.dispatch({changes:{from:0,to:t.state.doc.length,insert:sn(e.text)},effects:dn.of(e.text),annotations:[_n.of(!0),Y.addToHistory.of(!1)]}))},[e.text,e.path,e.historyKey]),(0,Z.useLayoutEffect)(()=>{u.current?.dispatch({effects:_.current.reconfigure(v())})},[e.mode,e.entry,e.readOnly,e.generated,e.diagnostics,y]),(0,Z.useEffect)(()=>{let t=u.current;if(!t||!e.reveal)return;d.current=e.reveal.requestId;let n=ln(p.current,e.reveal.sourceOffset);t.dispatch({selection:{anchor:n},scrollIntoView:!0}),e.reveal.focus!==!1&&t.focus()},[e.reveal?.requestId]);let b=(0,Z.useRef)(void 0);(0,Z.useEffect)(()=>{let t=u.current;if(!t||!e.declarationRequest||e.generated||!e.entry||b.current===e.declarationRequest)return;b.current=e.declarationRequest;let n=t.state.field(mn),r=e.mode===`ngspice`?(()=>{let e=n.indexOf(`
`)<0?n.length:n.indexOf(`
`)+1,t=(e&&n[e-1]!==`
`?`
`:``)+`.param variable=1
`;return{text:n.slice(0,e)+t+n.slice(e),anchor:e+t.length-1,changes:[{from:e,insert:t}]}})():Tt(n,!0),{from:i,insert:a}=r.changes[0];t.dispatch({changes:{from:ln(n,i),insert:a},selection:{anchor:ln(r.text,r.anchor)},effects:[dn.of(r.text),Kt.of(!1)],userEvent:`input.complete`}),t.dispatch({selection:t.state.selection,userEvent:`select`}),t.focus()},[e.declarationRequest,e.path]),(0,Z.useEffect)(()=>{let t=u.current;if(!t||!e.saveRequest||e.generated||e.mode===`json`)return;let r=(e.mode===`ngspice`?wt:A)(t.state.doc.toString(),n.current?.session===e.saveRequest.session&&n.current.path===e.path?n.current.offset:t.state.selection.main.head,e.saveRequest.vectors,!!e.entry,e.saveRequest.directives);if(!r.ok){e.onHelperError?.(r.error.message);return}let i=r.anchor;t.dispatch(...r.changes.map(e=>({changes:e,sequential:!0})),{selection:{anchor:i},scrollIntoView:!0,sequential:!0}),n.current={session:e.saveRequest.session,path:e.path,offset:i}},[e.saveRequest?.id]);let x=(0,X.jsxs)(`div`,{className:`simulation-code-helper-toolbar`,style:e.mode===`json`&&!e.helperActions?.length?{visibility:`hidden`}:void 0,children:[(0,X.jsx)(`button`,{type:`button`,title:e.generated?`Shared Cell parameters: edit DC/AC/waveforms and mapped expressions. Changes affect every Folder using this Cell. Use Design variable (.param) for Folder-local declarations. · Ctrl+Space`:`Insert / Helper · Ctrl+Space`,"data-simulation-helper-trigger":!0,"aria-expanded":r||!!e.helperContent,onClick:()=>{e.helperContent?e.onCloseHelperContent?.():i(e=>!e)},children:`Helper`}),a&&!r&&!e.helperContent&&(0,X.jsx)(`button`,{className:`simulation-find-helper`,onClick:()=>i(!0),children:`Find a helper…`}),e.picking&&(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`small`,{children:e.picking.label}),(0,X.jsx)(`button`,{onClick:e.picking.onStop,children:`Done`})]})]});return(0,X.jsxs)(`div`,{className:`simulation-code-editor-shell`,children:[t?(0,At.createPortal)(x,t):x,s&&(0,X.jsx)(`small`,{className:`simulation-code-argument-hint`,"aria-live":`polite`,children:s}),e.helperContent??(r&&(0,X.jsx)(gn,{language:e.mode??`native`,control:(e.mode===`ngspice`?(e,t)=>rt(e):Yt)(u.current?.state.doc.sliceString(0,u.current.state.selection.main.head)??``,!!e.entry),actions:[...e.helperActions??[],...e.mode===`json`?[]:[{id:`spec-limit`,label:`Spec acceptance rule…`,keywords:`spec expected limit pass failed 验收 指标`,run:()=>{let t=u.current;if(!t||e.readOnly)return;let n=t.state.doc.lineAt(t.state.selection.main.head),r=n.text.trim()?`
`:``,i=n.text.trim()?n.to:n.from,a=t.state.languageDataAt(`commentTokens`,i)[0]?.line??`*`,o=`${r}${a} @spec measurement <= 1 unit=V`,s=i+r.length+`${a} @spec `.length;t.dispatch({changes:{from:i,insert:o},selection:{anchor:s,head:s+11}}),t.focus()}}]],onClose:(e=!0)=>{i(!1),e&&u.current?.focus()},onChoose:t=>{let n=u.current;if(!n||e.readOnly||e.mode===`json`)return;if(t.name===`parameters`&&e.onParameterDeclaration){e.onParameterDeclaration();return}let r=n.state.doc.lineAt(n.state.selection.main.head);/^\s*[.\p{L}\w]*$/u.test(r.text)||n.dispatch({changes:{from:r.to,insert:`
`},selection:{anchor:r.to+1}}),e.mode===`ngspice`?ot(n,{...t,context:t.context===`circuit`?`deck`:`control`}):en(n,t)}})),(0,X.jsx)(`div`,{ref:l,className:`simulation-code-editor`,onKeyDownCapture:t=>{if(t.key===`Escape`&&e.picking){t.preventDefault(),t.stopPropagation(),e.picking.onStop();return}if(t.key===`Escape`&&e.mode!==`json`&&u.current&&(e.mode===`ngspice`?tt:tn)(u.current)){t.preventDefault(),t.stopPropagation();return}if(!t.ctrlKey||t.code!==`Space`||t.altKey||t.nativeEvent.isComposing)return;let n=u.current;if(!n)return;if(t.preventDefault(),t.stopPropagation(),e.mode===`json`){e.helperActions?.length?i(!0):q(n);return}n.dispatch({effects:Kt.of(!1)});let r=n.state.doc.lineAt(n.state.selection.main.head).text.trim().toLowerCase();/^[.\p{L}\w]+$/u.test(r)&&!(e.mode===`ngspice`?at:an)(new qe(n.state,n.state.selection.main.head,!0))?.options.some(e=>e.label.toLowerCase().startsWith(r))?i(!0):q(n)},onKeyDown:e=>e.stopPropagation()})]})}function yn(e,t){let n=e.current;return[...n.mode===`json`?[J()]:[qt.of(!!n.entry),Jt.of(n.relatedSources??[]),n.mode===`ngspice`?lt:rn,n.mode===`ngspice`?nt:nn,Ve({override:[t=>(e.current.mode===`ngspice`?at:an)(t,e.current.relatedSources,e.current.signalNames)],activateOnTypingDelay:350}),z.updateListener.of(t=>{let n=Ke(t.startState)?.label,r=Ke(t.state)?.label;if(!t.view.hasFocus){e.current.onFocusSignal?.(null);return}if(r&&r!==n&&e.current.onFocusSignal?.(r),n&&!r&&e.current.onFocusSignal?.(null),!r&&t.selectionSet){let n=t.state.selection.main.head,r=t.state.doc.lineAt(n),i=[...r.text.matchAll(/\bd?v\((?:'[^']*(?:''[^']*)*'|[^\s)]+)\)/gu)].find(e=>r.from+e.index<=n&&n<=r.from+e.index+e[0].length);e.current.onFocusSignal?.(i?.[0]??null)}}),ze.define(t=>{let n=t=>{let n=(t.target.closest?.(`.cm-tooltip-autocomplete li`))?.querySelector(`.cm-completionLabel`)?.textContent;n&&e.current.onFocusSignal?.(n)},r=()=>e.current.onFocusSignal?.(null);return t.dom.addEventListener(`mouseover`,n),t.dom.addEventListener(`mouseleave`,r),t.contentDOM.addEventListener(`blur`,r),{destroy(){t.dom.removeEventListener(`mouseover`,n),t.dom.removeEventListener(`mouseleave`,r),t.contentDOM.removeEventListener(`blur`,r),r()}}}),n.mode===`ngspice`?st:on],U.readOnly.of(!!n.readOnly),z.editable.of(!n.readOnly),ut(n=>{let r=e.current,i=t.current,a=r.mode===`json`?[]:[...(r.mode===`ngspice`?he({id:r.path,path:r.path,text:i,hash:``,encoding:`utf-8`},r.entry):h(r.path,i,r.entry)).diagnostics,...Ee(r.path,i)],o=r.mode===`json`?Ye()(n):[];if(r.generated)for(let e of i.matchAll(/<([A-Za-z][A-Za-z0-9_]*)>/g))i.slice(i.lastIndexOf(`
`,e.index)+1,e.index).trimStart().startsWith(`//`)||o.push({from:ln(i,e.index),to:ln(i,e.index+e[0].length),severity:`error`,message:`Enter ${e[1]}. This incomplete value can be saved, but cannot run.`,source:`MISSING_REQUIRED_PARAMETER`});for(let e of r.validateText?.(i)??[])o.push({from:ln(i,e.from),to:ln(i,e.to),severity:`error`,message:e.message,source:e.code});for(let e of[...a,...r.diagnostics??[]]){if(`path`in e&&e.path&&e.path!==r.path||!e.sourceRef)continue;let t=ln(i,e.sourceRef.start.offset),n=ln(i,e.sourceRef.end.offset);o.push({from:t,to:Math.max(t,n),severity:e.severity===`info`?`info`:e.severity,message:e.message,source:e.code})}return o},{delay:350})]}function bn(e,t,n){if(!n)return{input:t.input,libraries:[]};let r=ge(e,t,n);return r.ok?{input:{...t.input,files:r.files,dependencies:r.dependencies},libraries:r.profile.modelSymbols??[]}:{input:t.input,libraries:[],notice:`Profile model choices unavailable: `+(`diagnostics`in r?r.diagnostics.map(e=>e.message).join(`; `):r.error.message)}}function xn(e,t,n=[]){let r=C(t),i=[];for(let r of M(e,t,n))for(let e of re(r))i.push({kind:`device-op`,label:`${e.reference} · ${e.parameter} (model-native) — ${e.save}`,expression:{kind:`vector`,vector:e.save}});for(let n of t.circuitBindings){if(!r.paths.includes(n.path))continue;let t=de(e,{format:`spice`,rootDocumentId:n.documentId});if(!t.ir)continue;let a=g(r,n,t.ir).list(),o=we(e,n.documentId);for(let e of a){let t=e.callPath.length?`${e.callPath.join(`/`)} · `:``;for(let n of o.terminalCurrent)i.push({kind:`current`,label:t+n.label,expression:{...n.target,circuit:e}})}}let a=b(e,t),o=new Set;for(let[e,t]of Object.entries(a)){let n=`v(${T(e)})`;i.push({kind:`voltage`,label:`${t.replaceAll(`/`,` · `)} — ${e}`,expression:{kind:`vector`,vector:n}}),o.add(n)}for(let e of D(t))o.has(e.save)||i.push({kind:e.quantity,label:e.save,expression:{kind:`vector`,vector:e.save}});return i}function Sn({choices:e,kind:t,notice:n,onAdd:r,onClose:i}){let[a,o]=(0,Z.useState)(``),[s,c]=(0,Z.useState)([]),l=(0,Z.useRef)(null),u=()=>{let e=l.current?.closest(`.simulation-code-document`)?.querySelector(`[data-simulation-helper-trigger]`);i(),e?.focus()};(0,Z.useEffect)(()=>{let e=e=>{!l.current?.contains(e.target)&&!e.target.closest?.(`[data-simulation-helper-trigger]`)&&i()};return document.addEventListener(`pointerdown`,e),()=>document.removeEventListener(`pointerdown`,e)},[i]);let d=e.filter(e=>e.kind===t&&e.label.toLowerCase().includes(a.toLowerCase())),f=e=>{let t=JSON.stringify(e.expression);s.includes(t)||r(e.label,e.expression)&&c(e=>[...e,t])};return(0,X.jsxs)(`div`,{ref:l,className:`simulation-helper-list simulation-probe-picker`,role:`dialog`,"aria-label":`Save signal`,onKeyDown:e=>{e.stopPropagation(),e.key===`Escape`&&(e.preventDefault(),u())},children:[(0,X.jsxs)(`header`,{className:`simulation-probe-picker-header`,children:[(0,X.jsxs)(`strong`,{children:[`Save `,t]}),(0,X.jsx)(`button`,{onClick:u,children:`Done`})]}),n&&(0,X.jsx)(`p`,{role:`status`,children:n}),(0,X.jsx)(`input`,{autoFocus:!0,value:a,onChange:e=>o(e.currentTarget.value),"aria-label":`Search signal`,autoComplete:`off`,placeholder:`Search signal or enter an exact native vector…`}),(0,X.jsx)(`div`,{className:`simulation-helper-options`,children:d.map((e,t)=>(0,X.jsxs)(`button`,{"aria-disabled":s.includes(JSON.stringify(e.expression)),onMouseDown:e=>e.preventDefault(),onClick:()=>f(e),children:[e.label,s.includes(JSON.stringify(e.expression))&&(0,X.jsx)(`small`,{children:`Added`})]},t))}),a.trim()&&(0,X.jsxs)(`button`,{onMouseDown:e=>e.preventDefault(),onClick:()=>f({label:a.trim(),kind:t,expression:{kind:`vector`,vector:a.trim()}}),children:[`Use native vector: `,a.trim()]})]})}function Cn({kind:e}){return(0,X.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 20 20`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,focusable:`false`,children:e===`save`?(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`path`,{d:`M4 3h10l3 3v11H3V3h1Z`}),(0,X.jsx)(`path`,{d:`M6 3v5h7V3M6 17v-6h8v6`})]}):e===`run`?(0,X.jsx)(`path`,{d:`m6 3 10 7-10 7V3Z`}):e===`stop`?(0,X.jsx)(`rect`,{x:`5`,y:`5`,width:`10`,height:`10`,rx:`1`}):e===`saved`?(0,X.jsx)(`path`,{d:`m4 10 4 4 8-8`}):e===`saving`?(0,X.jsx)(`path`,{d:`M16 10a6 6 0 1 1-6-6`}):(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7`}),(0,X.jsx)(`path`,{d:`M10 6v5m0 3h.01`})]})})}async function wn(e,t,n){let r=[];for(let i of new Set(e)){let e=await n(i,t);if(!e.ok)return e;r.push(e.folder),t=e.revision}return{ok:!0,folders:r,revision:t}}function Tn(e,t,n=!1){if(t!==e.input.configPath||t===e.input.entry||n||e.input.drafts?.some(e=>e.path===t))return!0;let r=s(e);return!r.ok||r.authority!==`code`}function En(...e){try{return ae(...e)}catch(t){console.error(`Circuit source projection failed`,t);let n=e[1].documentId;return{ok:!1,diagnostics:[{code:`SIMULATION_SOURCE_PROJECTION_FAILED`,severity:`error`,documentId:n,objectIds:[],primary:l(n,`document`,n),message:`The Circuit source could not be generated (${t instanceof Error?t.message:String(t)})`}]}}}var Q=(e,t)=>({code:e,message:t,stage:`input`,recovery:`fix-input`}),Dn=(0,Z.forwardRef)(function(e,t){let n=t=>{let n=e.capabilities?ve(t,e.capabilities):void 0;return n?.ok?n.engine:Te(t)??`vacask`},r=n(e.folder),i=Mt(),a=(0,Z.useRef)(e);a.current=e;let o,c=``;try{o=window.sessionStorage,c=o.getItem(`icm.working-copy.v1`)??``}catch{}let l=(0,Z.useMemo)(()=>xe(o,c,e.project.id),[o,c,e.project.id]),u=(0,Z.useMemo)(()=>{let t=l.read();for(let n of e.project.simulationFolders)for(let r of n.input.drafts??[]){let i=`${n.id}\u0000${r.path}`;t.has(i)||t.set(i,{base:r.base,text:r.text,committed:e.project.structureRevision,...r.binding?{binding:r.binding}:{}})}return{current:t}},[l]),[f,m]=(0,Z.useState)(0),[h,g]=(0,Z.useState)(!0);(0,Z.useEffect)(()=>{g(l.write(u.current))},[l,f]);let[_,v]=(0,Z.useState)({}),y=(e,t)=>{let n=u.current.get(`${e.id}\u0000${t}`);return Tn(e,t,!!n&&n.text!==n.base)},b=_[e.folder.id]??e.folder.input.entry,x=y(e.folder,b)?b:e.folder.input.entry,S=(t,n=e.folder.id)=>{v(e=>({...e,[n]:t})),n!==e.folder.id&&e.folders?.onSelect(n)},[ee,C]=(0,Z.useState)(!1),[w,te]=(0,Z.useState)(!1),[re,ae]=(0,Z.useState)(!1),D=(0,Z.useRef)(!1),[O,ce]=(0,Z.useState)(),[k,ue]=(0,Z.useState)(``),[de,fe]=(0,Z.useState)(),pe=()=>{S(e.folder.input.entry),fe(crypto.randomUUID()),e.onProblem(void 0)},[me,N]=(0,Z.useState)(),he=(0,Z.useRef)(crypto.randomUUID()),ge=(0,Z.useRef)(0),_e=()=>{he.current=crypto.randomUUID(),e.pickNetsActive&&e.onPickNetsChange?.(!1),e.pickTerminalsActive&&e.onPickTerminalsChange?.(!1),R(void 0)},ye=(0,Z.useRef)(!1),Ce=(0,Z.useRef)({net:e.pickedNet?.sequence,terminal:e.pickedTerminal?.sequence}),P=e.folder.input,I=s(e.folder),Ee=I.ok&&I.authority===`legacy-config`,De=(0,Z.useMemo)(()=>(r===`ngspice`?ie:d)(e.project,{...P,files:P.files.map(t=>({...t,text:u.current.get(`${e.folder.id}\u0000${t.path}`)?.text??t.text}))}),[e.project,P,f,r]),[L,R]=(0,Z.useState)(),z=(0,Z.useMemo)(()=>{let t={...e.folder,input:{...P,files:P.files.map(t=>({...t,text:u.current.get(`${e.folder.id}\u0000${t.path}`)?.text??t.text}))}};return L&&r!==`ngspice`?bn(e.project,t,e.capabilities?.profiles):{input:t.input,libraries:[]}},[e.project,P,f,L,e.capabilities,e.folder,r]),ke=(0,Z.useMemo)(()=>L?r===`ngspice`?Vt(e.project,z.input):xn(e.project,z.input,z.libraries):[],[e.project,L,z,r]),B=P.circuitBindings.find(e=>e.emission===`top-level`),Ae=(0,Z.useMemo)(()=>B?we(e.project,B.documentId):void 0,[e.project,B]),je=(t,n)=>{let i=(t,n)=>{let i=P.circuitBindings.some(e=>e.path===x)||x.endsWith(`.json`)?P.entry:x,a=u.current.get(`${e.folder.id}\u0000${i}`)?.text??P.files.find(e=>e.path===i)?.text??``,o=(r===`ngspice`?wt:A)(a,i===x?ge.current:0,t,i===P.entry,n);return o.ok?(i!==x&&S(i),e.onProblem(void 0),N({id:crypto.randomUUID(),session:he.current,vectors:t,...n?{directives:n}:{}}),!0):(e.onProblem(Q(o.error.code,o.error.message)),!1)};if(n.kind===`vector`)return/[\r\n;]/u.test(n.vector)?(e.onProblem(Q(`SIMULATION_VECTOR_INVALID`,`Enter a vector, not a command.`)),!1):i([n.vector]);if(n.kind===`current`){let t={...P,files:P.files.map(t=>({...t,text:u.current.get(`${e.folder.id}\u0000${t.path}`)?.text??t.text}))},a=r===`ngspice`?{input:t,libraries:[]}:bn(e.project,{...e.folder,input:t},e.capabilities?.profiles),o=(r===`ngspice`?oe:M)(e.project,a.input,a.libraries).find(e=>e.documentId===n.documentId&&e.instanceId===n.instanceId&&JSON.stringify(e.occurrence)===JSON.stringify(n.occurrence)&&e.circuit.bindingId===n.circuit.bindingId&&JSON.stringify(e.circuit.callPath)===JSON.stringify(n.circuit.callPath)),s=o?r===`ngspice`?se(o,n.pinName):j(o,n.pinName):{ok:!1,message:`The selected device no longer has a reachable native occurrence`};return s.ok?i(s.vectors,s.directives):(e.onProblem(Q(`SIMULATION_NATIVE_CURRENT_UNAVAILABLE`,s.message)),!1)}if(n.kind!==`voltage`)return e.onProblem(Q(`SIMULATION_NATIVE_EXPRESSION_REQUIRED`,`Author derived output expressions in native Code; selecting an acquisition does not create a parallel JSON output.`)),!1;let a=ne(e.project,{...P,files:P.files.map(t=>({...t,text:u.current.get(`${e.folder.id}\u0000${t.path}`)?.text??t.text}))},n,r);return a.ok?i([a.save]):(e.onProblem(Q(`SIMULATION_SIGNAL_UNRESOLVED`,a.message)),!1)},Me=t=>{if(!B)return;if(t.length!==1){e.onProblem(Q(`SIMULATION_SIGNAL_UNRESOLVED`,`This pick has no unique signal. Choose a mapped Net or terminal, or select the signal from Helper.`));return}let n=t[0];je(n.label,{...n.target,circuit:{bindingId:B.id,callPath:[]}})};(0,Z.useEffect)(()=>{!e.pickedNet||e.pickedNet.sequence===Ce.current.net||(Ce.current.net=e.pickedNet.sequence,e.pickNetsActive&&Ae&&Me(Se(e.project,Ae.voltage,e.pickedNet)))},[e.pickedNet]),(0,Z.useEffect)(()=>{!e.pickedTerminal||e.pickedTerminal.sequence===Ce.current.terminal||(Ce.current.terminal=e.pickedTerminal.sequence,e.pickTerminalsActive&&Ae&&Me(F(Ae.terminalCurrent,e.pickedTerminal)))},[e.pickedTerminal]);let Ne=(0,Z.useMemo)(()=>P.circuitBindings.map(t=>({binding:t,result:En(e.project,t,P,r)})),[e.project,P,r]);(0,Z.useEffect)(()=>{ce(void 0),R(void 0),he.current=crypto.randomUUID()},[e.folder.id]);let V=(0,Z.useRef)(void 0);(0,Z.useEffect)(()=>{let t=e.selectedCircuitObject,n=t?JSON.stringify([t.documentId,t.instanceId]):void 0,r=V.current!==n;if(V.current=n,t&&!(!r&&_[e.folder.id]!==void 0))for(let{binding:n,result:r}of Ne){if(!r.ok)continue;let i=r.source.instances.find(e=>e.documentId===t.documentId&&e.instanceId===t.instanceId);if(!i)continue;let a=u.current.get(`${e.folder.id}\u0000${n.path}`);if(a&&a.text!==r.source.text)return;S(n.path),ce({sourceOffset:i.startOffset,requestId:crypto.randomUUID(),focus:!1});return}},[e.selectedCircuitObject?.documentId,e.selectedCircuitObject?.instanceId,e.folder.id]);let H=[...P.files,...Ne.map(({binding:e,result:t})=>({path:e.path,text:t.ok?t.source.text:t.diagnostics.map(e=>`* ${e.code}: ${e.message}`).join(`
`)}))],U=(0,Z.useRef)({folderId:e.folder.id,files:H,drafts:u});U.current={folderId:e.folder.id,files:H,drafts:u};let W=t=>`${e.folder.id}\u0000${t}`,Pe=H.find(e=>e.path===x),G=Ne.find(e=>e.binding.path===x)?.result,K=u.current.get(W(x)),q=K&&K.base!==(Pe?.text??``),Fe=K?.text??Pe?.text??``;(0,Z.useEffect)(()=>{let e=!0;return ue(``),Oe(Fe).then(t=>{e&&ue(t)}),()=>{e=!1}},[Fe]);let Ie=[...u.current].filter(([t,n])=>{let r=e.project.simulationFolders.find(e=>t.startsWith(`${e.id}\u0000`));return!r||n.text===n.base?!1:!r.input.drafts?.some(e=>e.path===t.slice(r.id.length+1)&&e.base===n.base&&e.text===n.text)}),Le=Ie.length>0,Re=[...u.current].some(([t,n])=>t.startsWith(`${e.folder.id}\u0000`)&&n.text!==n.base);(0,Z.useEffect)(()=>ae(!1),[Fe,e.folder.id]);let ze=Ie.some(([t])=>t.startsWith(`${e.folder.id}\u0000`));(0,Z.useEffect)(()=>e.onDirty(Le),[Le,e.folder.id]),(0,Z.useEffect)(()=>e.onActiveDirty(ze),[ze,e.folder.id]),(0,Z.useEffect)(()=>{for(let e of H){let t=u.current.get(W(e.path));t&&t.text===t.base&&t.base!==e.text&&u.current.delete(W(e.path))}},[e.project]);let J=async(t,r,i)=>{if(ye.current)return{ok:!1};ye.current=!0,C(!0);try{let o=i??a.current.project.structureRevision,s=r?a.current.project.simulationFolders.find(e=>e.id===r):a.current.folder;if(!s)return e.onProblem(Q(`SIMULATION_FOLDER_MISSING`,`Selected folder ${r} no longer exists`)),{ok:!1};let c=s.id,l=[...u.current].filter(([e,n])=>e.startsWith(`${c}\u0000`)&&n.text!==n.base&&(t===void 0||e===`${c}\u0000${t}`)),d=[],f=[];for(let[t,r]of l){let i=t.slice(s.id.length+1);if(r.binding){let t=En(a.current.project,r.binding,s.input,n(s));if(!t.ok||t.source.text!==r.base)return e.onProblem(Q(`SOURCE_DRAFT_CONFLICT`,`${i} changed on Canvas. Your draft is retained; copy it or discard it before editing the current Circuit.`)),{ok:!1};let o=E(t.source,r.text);if(!o.ok)return e.onProblem(Q(o.code,o.message)),{ok:!1};f.push({path:i,textDigest:await Oe(r.base),text:r.text})}else{if((s.input.files.find(e=>e.path===i)?.text??``)!==r.base)return e.onProblem(Q(`SOURCE_DRAFT_CONFLICT`,`${i} was edited elsewhere. Your draft is retained; copy it or discard it to load the current file.`)),{ok:!1};d.push({path:i,text:r.text})}}if(d.length||f.length){let t=await e.files.handle({action:`update`,owner:{kind:`project-folder`,folderId:s.id},expectedRevision:o,writes:d,circuitEdits:f});if(!t.ok)return e.onProblem(t.error),{ok:!1};if(!(`source`in t))return{ok:!1};o=t.source.revision;let n=new Map(d.map(e=>[e.path,e.text]));s={...s,input:{...s.input,files:[...s.input.files.filter(e=>!n.has(e.path)),...d]}}}for(let[e,t]of l){let n=u.current.get(e);n===t?u.current.delete(e):n&&u.current.set(e,{...n,base:t.text,committed:o})}return e.onProblem(void 0),m(e=>e+1),{ok:!0,folder:s,revision:o}}finally{ye.current=!1,C(!1)}};(0,Z.useImperativeHandle)(t,()=>({flush:J,flushFolders:e=>wn(e,a.current.project.structureRevision,(e,t)=>J(void 0,e,t)),save:async()=>{let t=await J();for(let t of a.current.project.simulationFolders){let n=[...u.current].filter(([e,n])=>e.startsWith(`${t.id}\u0000`)&&n.base!==n.text);if(!n.length)continue;let r={kind:`project-folder`,folderId:t.id},i=await e.files.handle({action:`list`,owner:r});if(!i.ok||!(`source`in i))return i.ok||e.onProblem(i.error),!1;let a=await e.files.handle({action:`update`,owner:r,expectedRevision:i.source.revision,drafts:n.map(([e,n])=>({path:e.slice(t.id.length+1),base:n.base,text:n.text,...n.binding?{binding:n.binding}:{}}))});if(!a.ok)return e.onProblem(a.error),!1}return t.ok||e.onProblem(Q(`SOURCE_DRAFT_SAVED`,`Saved unfinished code as a draft. Circuit values are unchanged; finish or discard the draft before Run.`)),!0},reveal:async t=>{if(t.scope===`model-source`){let n=e.project.modelSources?.find(e=>e.id===t.sourceId&&e.revision===t.revision),r=n?.files.find(e=>e.path===t.path);if(r&&await Oe(r.text)===t.textDigest&&a.current.project===e.project){a.current.onOpenModelSource?.(n.id,t);return}e.onProblem(Q(`SOURCE_LOCATION_STALE`,`The shared model changed. Prepare again to locate its current source.`));return}let n=e.folder.id,r=u.current.get(W(t.path))?.text??H.find(e=>e.path===t.path)?.text;if(r===void 0||await Oe(r)!==t.textDigest||U.current.folderId!==n||(U.current.drafts.current.get(`${n}\u0000${t.path}`)?.text??U.current.files.find(e=>e.path===t.path)?.text)!==r){e.onProblem(Q(`SOURCE_LOCATION_STALE`,`This diagnostic belongs to older source. Prepare again to locate the current text.`));return}S(t.path),ce({sourceOffset:t.startOffset,requestId:crypto.randomUUID()})},discard:()=>{u.current.clear(),l.write(u.current),m(e=>e+1)}}));let Be=t=>{let n=u.current.get(W(x));u.current.set(W(x),{base:n?.base??Pe?.text??``,text:t,committed:n?.committed??e.project.structureRevision,...n?.binding?{binding:n.binding}:G?.ok?{binding:G.source.binding}:{}}),m(e=>e+1)},Ve=[...new Set([...H.map(e=>e.path),...[...u.current.keys()].filter(t=>t.startsWith(`${e.folder.id}\u0000`)).map(t=>t.slice(e.folder.id.length+1))])],He=(e,t,n)=>{if(/^[\\/]|[\\\u0000-\u001f]/u.test(e)||e.split(`/`).some(e=>!e||e===`.`||e===`..`))return`Use a relative file path without . or .. segments.`;let r=a.current.project.simulationFolders.find(e=>e.id===t);if(e!==n&&(r?.input.files.some(t=>t.path===e)||r?.input.circuitBindings.some(t=>t.path===e)||u.current.has(`${t}\u0000${e}`)))return`A file with this path already exists.`},Ue=(t,i)=>{let a=u.current.get(`${t}\u0000${i}`);if(a)return a.text;let o=e.project.simulationFolders.find(e=>e.id===t),s=o?.input.files.find(e=>e.path===i);if(s)return s.text;let c=o?.input.circuitBindings.find(e=>e.path===i);if(!c)return``;let l=En(e.project,c,o?.input,o?n(o):r);return l.ok?l.source.text:l.diagnostics.map(e=>`// ${e.message}`).join(`
`)},We=async()=>{if(!D.current){D.current=!0,te(!0);try{let e=await J();ae(!e.ok)}catch(t){ae(!0),e.onProblem(Q(`SOURCE_APPLY_FAILED`,t instanceof Error?t.message:`Save failed; drafts retained.`))}finally{D.current=!1,te(!1)}}},Ge=async(t,n=!1)=>{if(t.length===1&&!n){let n=t[0];if(n.kind===`source`){let t=be(Ue(n.folderId,n.path),n.path.split(`/`).at(-1));t.status===`failed`&&e.onProblem(Q(`SOURCE_EXPORT_FAILED`,t.message))}else e.onDownloadArtifact?.(n.artifact);return}let r=await yt(e.files,t.map(t=>t.kind===`artifact`?{kind:`artifact`,path:`${t.groupKey}/${(ht(t.artifact)??mt(t.artifact)).toLowerCase()}/${t.artifact.name}`,artifact:t.artifact}:{kind:`text`,path:`${e.project.simulationFolders.find(e=>e.id===t.folderId)?.name??t.folderId}/source/${t.path}`,text:Ue(t.folderId,t.path)}));if(!r.ok){e.onProblem(r.error);return}let i=URL.createObjectURL(new Blob([r.bytes],{type:`application/zip`})),a=document.createElement(`a`);a.href=i,a.download=`${e.folder.name}-selected-files.zip`,a.click(),setTimeout(()=>URL.revokeObjectURL(i),0)},Y=w||ee?`saving`:re?`failed`:Re?`dirty`:`saved`,Ke=Y===`saving`?`Applying source…`:Y===`saved`?`Source applied to current project; not a cloud save`:Y===`failed`?`Apply failed; drafts retained. Retry save.`:`Save source to current project`,qe=()=>{Y!==`saving`&&Y!==`saved`&&We()};return(0,X.jsxs)(Gt,{onSave:qe,workspaceKey:e.folder.id,folders:e.folders?{...e.folders,folders:e.folders.folders.map(t=>{let n=e.project.simulationFolders.find(e=>e.id===t.id),r=new Set([...(t.files??[]).map(e=>e.path),...[...u.current.keys()].filter(e=>e.startsWith(`${t.id}\u0000`)).map(e=>e.slice(t.id.length+1))]);return{...t,files:[...r].filter(e=>y(n,e)).map(e=>{let r=u.current.get(`${t.id}\u0000${e}`),i=!!r&&r.text!==r.base;return{path:e,kind:n.input.circuitBindings.some(t=>t.path===e)?`generated`:`authored`,draft:i,dirty:i&&!n.input.drafts?.some(t=>t.path===e&&t.base===r.base&&t.text===r.text)}})}})}:void 0,additionalActions:e.additionalActions??[],...e.artifactGroups?{artifactGroups:e.artifactGroups}:{},...e.artifactPreview?{artifactPreview:e.artifactPreview}:{},...e.artifactBusy?{artifactBusy:e.artifactBusy}:{},...e.onSelectArtifact?{onSelectArtifact:e.onSelectArtifact}:{},...e.onCloseArtifact?{onCloseArtifact:e.onCloseArtifact}:{},...e.onDownloadArtifact?{onDownloadArtifact:e.onDownloadArtifact}:{},onDownloadSelection:(e,t)=>void Ge(e,t),files:Ve.filter(t=>y(e.folder,t)).map(e=>({path:e,kind:P.circuitBindings.some(t=>t.path===e)?`generated`:`authored`,dirty:!!u.current.get(W(e))&&u.current.get(W(e)).text!==u.current.get(W(e)).base&&!P.drafts?.some(t=>t.path===e&&t.text===u.current.get(W(e)).text&&t.base===u.current.get(W(e)).base),draft:!!u.current.get(W(e))&&u.current.get(W(e)).text!==u.current.get(W(e)).base})),activePath:x,sourceContext:(0,X.jsx)(Bt,{engine:r,project:e.project,activeDocumentId:e.activeDocumentId,input:{...P,files:P.files.map(t=>({...t,text:u.current.get(`${e.folder.id}\u0000${t.path}`)?.text??t.text}))},onSelectFile:S}),onSelectFile:S,onFileAction:async(t,n,r=e.folder.id)=>{let o={kind:`project-folder`,folderId:r},s=`${r}\u0000${n}`;if(t===`discard`){let t=await e.files.handle({action:`list`,owner:o});if(!t.ok||!(`source`in t))return;let r=await e.files.handle({action:`update`,owner:o,expectedRevision:t.source.revision,drafts:(t.source.drafts??[]).filter(e=>e.path!==n)});if(!r.ok){e.onProblem(r.error);return}u.current.delete(s),l.write(u.current),m(e=>e+1),e.onProblem(void 0);return}if(t===`delete`&&!await i.confirm({title:`Delete ${n}?`,message:`This removes the file and its draft. Undo restores it. References to this file may need repair.`}))return;let c=t===`rename`?(await i.name({kind:`file`,folderId:r,path:n,label:`Relative file path`,initial:n,validate:e=>He(e,r,n)}))?.name:n;if(!c||t===`rename`&&c===n)return;let d=await e.files.handle({action:`list`,owner:o});if(!d.ok||!(`source`in d)){d.ok||e.onProblem(d.error);return}let f=a.current.project.simulationFolders.find(e=>e.id===r),p=f?.input.files.find(e=>e.path===n),h=u.current.get(s),g=p??(h?{path:n,text:``}:void 0);if(!f||!g)return;if(h&&h.base!==g.text){e.onProblem(Q(`SOURCE_CONFLICT`,`File changed elsewhere; draft retained.`));return}let y=h?.text??g.text,b=await e.files.handle({action:`update`,owner:o,expectedRevision:d.source.revision,...t===`rename`?{removes:[n],writes:[{path:c,text:y}],...n===f.input.entry?{entry:c}:{},...n===f.input.configPath?{configPath:c}:{}}:t===`delete`?{removes:[n]}:{entry:n,writes:[{path:n,text:y}]}});b.ok?(u.current.delete(s),l.write(u.current),m(e=>e+1),(_[r]===n||r===e.folder.id&&x===n)&&v(e=>({...e,[r]:t===`delete`?``:c})),e.onProblem(void 0)):e.onProblem(b.error)},entryPath:P.entry,configPath:P.configPath,onCopyFile:(t,n=e.folder.id)=>{navigator.clipboard.writeText(Ue(n,t)).catch(()=>e.onProblem(Q(`SOURCE_COPY_FAILED`,`Clipboard access is unavailable. Select the code to copy, or export the current file.`)))},onNewFile:async(t=e.folder.id)=>{let n=(await i.name({kind:`file`,folderId:t,label:`Relative file path`,initial:`stimulus.cir`,validate:e=>He(e,t)}))?.name;n&&(u.current.set(`${t}\u0000${n}`,{base:``,text:`* New source
`,committed:a.current.project.structureRevision}),S(n,t),m(e=>e+1))},actions:(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`button`,{className:`simulation-action-button`,"data-save-state":Y,"aria-label":`Save source`,"aria-description":Ke,title:`${Ke} · Ctrl+S`,disabled:Y===`saving`||Y===`saved`,"aria-busy":Y===`saving`,onClick:qe,children:(0,X.jsx)(Cn,{kind:Y===`dirty`?`save`:Y})}),e.actions]}),toolbarEnd:e.toolbarEnd,console:e.console,results:e.results,history:e.history,outputPane:e.outputPane,onSelectOutputPane:e.onSelectOutputPane,maximized:e.maximized,onToggleMaximize:e.onToggleMaximize,status:!h||q||e.status||Ee?(0,X.jsxs)(X.Fragment,{children:[Ee?(0,X.jsx)(`span`,{title:`This existing experiment still uses version-1 JSON bindings and measurements. Convert through Helper after moving its electrical intent into Code.`,children:`Legacy configuration · migration required for Code-only execution`}):null,h?null:(0,X.jsx)(`span`,{role:`alert`,children:`Draft recovery unavailable — save or export before leaving.`}),q?(0,X.jsxs)(X.Fragment,{children:[(0,X.jsx)(`span`,{role:`alert`,children:`Changed elsewhere — draft retained.`}),(0,X.jsx)(`button`,{onClick:()=>{u.current.delete(W(x)),m(e=>e+1)},children:`Discard local draft`})]}):e.status]}):null,children:[G?.ok&&e.onOpenModelSource?(0,X.jsx)(`div`,{className:`simulation-model-owners`,"aria-label":`Shared model sources`,children:G.source.modelSnapshots?.map(t=>(0,X.jsxs)(`button`,{type:`button`,onClick:()=>e.onOpenModelSource?.(t.id),children:[`Open model `,t.entry,` · applied version `,t.revision,t.draft?` · draft pending`:``]},t.id))}):null,(0,X.jsx)(vn,{onCursor:e=>{ge.current=e},onHelperError:t=>e.onProblem(Q(`SIMULATION_SAVE_EDIT_INVALID`,t)),helperContent:L?(0,X.jsx)(Sn,{choices:ke,notice:z.notice,kind:L,onAdd:je,onClose:()=>R(void 0)},`${e.folder.id}:${L}`):void 0,onCloseHelperContent:()=>R(void 0),picking:e.pickNetsActive||e.pickTerminalsActive?{label:e.pickNetsActive?`Picking voltage`:`Picking current`,onStop:()=>{e.onPickNetsChange?.(!1),e.onPickTerminalsChange?.(!1)}}:void 0,signalNames:()=>Object.fromEntries(Object.entries(De).map(([e,t])=>[r===`ngspice`?e:`v(${T(e)})`,t.label])),onFocusSignal:t=>{let n=t?r===`ngspice`?t.toLowerCase():p(t):void 0;e.onPreviewSignal?.(n?De[n]?.targets[0]??null:null)},saveRequest:me,declarationRequest:de,onParameterDeclaration:pe,relatedSources:H.map(t=>u.current.get(`${e.folder.id}\u0000${t.path}`)?.text??t.text),helperActions:[{id:`design-variable`,label:`Design variable (parameters)…`,keywords:`parameter declaration 参数 变量`,run:pe},...Ee?[{id:`convert-native`,label:`Convert legacy experiment to native Code…`,keywords:`migrate configuration experiment.json 迁移`,run:async()=>{let t=await J();if(!t.ok)return;let n=le(a.current.project,t.folder);if(!n.ok){e.onProblem(Q(`SIMULATION_NATIVE_MIGRATION_REQUIRED`,n.message));return}let r=await e.files.handle({action:`update`,owner:{kind:`project-folder`,folderId:t.folder.id},expectedRevision:t.revision,writes:n.folder.input.files.filter(e=>e.path===n.folder.input.configPath)});r.ok||e.onProblem(r.error)}}]:[],{id:`save-device-op`,label:`Save device operating point…`,keywords:`MOS gm gds vth id 工作点`,run:()=>{_e(),R(`device-op`)}},{id:`save-voltage`,label:`Save voltage…`,keywords:`probe voltage 电压 信号 看输出`,run:()=>{_e(),R(`voltage`)}},{id:`save-current`,label:`Save terminal current…`,keywords:`probe current 电流 MOS 端口`,run:()=>{_e(),R(`current`)}},...B?[{id:`pick-net`,label:e.pickNetsActive?`Stop picking Nets`:`Pick Net on Canvas`,keywords:`probe 电压 画布`,run:()=>{_e(),e.onPickNetsChange?.(!e.pickNetsActive)}},{id:`pick-current`,label:e.pickTerminalsActive?`Stop picking current`:`Pick current on Canvas`,keywords:`probe 电流 画布`,run:()=>{_e(),e.onPickTerminalsChange?.(!e.pickTerminalsActive)}}]:[]],path:x,text:Fe,historyKey:`${e.folder.id}:${K?.committed??e.project.structureRevision}`,mode:x.endsWith(`.json`)?`json`:r===`ngspice`?`ngspice`:`native`,entry:x===P.entry,generated:!!G,validateText:e=>{if(!G?.ok)return[];let t=E(G.source,e);return!t.ok&&t.range?[{...t.range,message:t.message,code:t.code}]:[]},reveal:O,diagnostics:e.diagnostics?.filter(e=>e.source?.path===x&&e.source.textDigest===k).map(e=>({code:e.code,message:e.message,severity:e.severity,path:e.source.path,sourceRef:e.sourceRef??{fileId:x,start:{offset:e.source.startOffset,line:e.source.line,column:e.source.column},end:{offset:e.source.endOffset,line:e.source.line,column:e.source.column}}})),readOnly:G?.ok===!1,acceptChange:e=>{let t=G?.ok?G.source:void 0;if(!t)return!0;if(q)return!1;let n=E(t,e);return n.ok||n.code===`SIMULATION_PARAMETER_INVALID`},onRejectedChange:()=>e.onProblem(Q(`SIMULATION_CIRCUIT_STRUCTURE_LOCKED`,`Circuit topology, references and model identity are Canvas-owned. Edit mapped values/expressions and native source parameters here. Use Helper → Design variable (parameters) to add declarations in ${P.entry}; those declarations belong to this Folder, while Circuit parameter edits affect every Folder using this Cell.`)),onChange:Be,onSave:()=>void We(),onRun:e.onRun,onHistoryBoundary:e.onHistoryBoundary})]})}),On=[`a`,`f`,`p`,`n`,`µ`,`m`,``,`k`,`M`,`G`,`T`,`P`,`E`],kn=new Set([`V`,`A`,`s`,`Hz`,`F`,`H`,`Ω`,`W`,`S`]),An=e=>String(Number(e.toPrecision(7)));function jn(e,t,n){let r=n===`Ohm`||n===`ohm`?`Ω`:n,i=e??(t?.kind===`range`?t.maximum:t?.value)??0,a=0;if(kn.has(r)&&i!==0){let e=Math.floor(Math.log10(Math.abs(i))/3)*3;a=e>=-18&&e<=18?e:0,Math.abs(Number((i/10**a).toPrecision(7)))>=1e3&&e>=-18&&e<=18&&a<18&&(a+=3)}[e,...t?.kind===`range`?[t.minimum,t.maximum]:t?.kind===`target`?[t.value,t.tolerance]:t?[t.value]:[]].some(e=>e!==null&&e!==0&&(!Number.isFinite(e/10**a)||e/10**a==0))&&(a=0);let o=e=>!r&&e!==0&&(Math.abs(e)>=1e6||Math.abs(e)<.001)?Number(e.toPrecision(7)).toExponential():An(e/10**a);return{result:e===null?`—`:o(e),condition:t?t.kind===`limit`?`${t.operator} ${o(t.value)}`:t.kind===`range`?`[${o(t.minimum)}, ${o(t.maximum)}]`:`${o(t.value)} ± ${o(t.tolerance)}`:`—`,unit:r?`${kn.has(r)?On[a/3+6]:``}${r}`:``}}function Mn({latex:e,display:t}){let[n,r]=(0,Z.useState)(),i={latex:e,display:t,profileId:c},a=n?.latex===e&&n.display===t?n.result:me(i);if((0,Z.useEffect)(()=>{let n=!0;return pe({latex:e,display:t,profileId:c}).then(i=>{n&&r({latex:e,display:t,result:i})},()=>{}),()=>{n=!1}},[e,t]),!a?.ok)return(0,X.jsx)(`span`,{children:e});let o=a.artifact;return(0,X.jsx)(`img`,{alt:e,src:`data:image/svg+xml,${encodeURIComponent(o.svg)}`,style:{width:`${o.width/100}em`,height:`${o.height/100}em`,verticalAlign:`${(o.baseline-o.height)/100}em`}})}function Nn(e){switch(e.kind){case`text`:return e.value;case`math`:return(0,X.jsx)(Mn,{...e});case`span`:{let t=Pn(e.children);switch(e.style){case`bold`:return(0,X.jsx)(`strong`,{children:t});case`italic`:return(0,X.jsx)(`em`,{children:t});case`subscript`:return(0,X.jsx)(`sub`,{children:t});case`superscript`:return(0,X.jsx)(`sup`,{children:t});case`overbar`:return(0,X.jsx)(`span`,{style:{textDecoration:`overline`},children:t})}}}}function Pn(e){return e.map((e,t)=>(0,X.jsx)(Z.Fragment,{children:Nn(e)},t))}function Fn({document:e}){return(0,X.jsx)(X.Fragment,{children:Pn(e.runs)})}function In(e){let t=e.report?.results??[],n={pass:0,failed:0,"not-evaluated":0,unconstrained:0};for(let e of t)n[e.judgment]++;let r={pass:`Pass`,failed:`Failed`,"not-evaluated":`Not evaluated`,unconstrained:`Measured only`},i=t.filter(e=>e.expected||e.judgment!==`unconstrained`),a=t.filter(e=>!e.expected&&e.judgment===`unconstrained`);function o(e){let t=new Map;for(let n of e){let e=n.group??``,r=t.get(e)??[];r.push(n),t.set(e,r)}let n={failed:0,"not-evaluated":1,pass:2,unconstrained:3},r=[...t.keys()].some(Boolean);return(0,X.jsx)(`div`,{className:`simulation-spec-table-scroll`,tabIndex:0,role:`region`,"aria-label":`Measurement table`,children:(0,X.jsxs)(`table`,{children:[(0,X.jsx)(`thead`,{children:(0,X.jsxs)(`tr`,{children:[(0,X.jsx)(`th`,{children:`Spec`}),(0,X.jsx)(`th`,{children:`Sim result`}),(0,X.jsx)(`th`,{children:`Expected`}),(0,X.jsx)(`th`,{children:`Judgment`})]})}),[...t].map(([e,t])=>(0,X.jsxs)(`tbody`,{children:[r?(0,X.jsx)(`tr`,{className:`simulation-spec-group`,children:(0,X.jsx)(`th`,{colSpan:4,scope:`rowgroup`,children:e||`Ungrouped`})}):null,t.sort((e,t)=>n[e.judgment]-n[t.judgment]).map(s)]},e))]})})}function s(t){let n=jn(t.value,t.expected,t.unit);return(0,X.jsxs)(`tr`,{"data-judgment":t.judgment,children:[(0,X.jsx)(`th`,{scope:`row`,children:(0,X.jsxs)(`button`,{type:`button`,onClick:()=>e.onSource(t.source),title:`${t.name} · ${t.source.path}:${t.source.line} · occurrence ${t.occurrence}`,children:[t.label?(0,X.jsx)(Fn,{document:t.label}):t.name,t.occurrence>1?` · #${t.occurrence}`:``]})}),(0,X.jsxs)(`td`,{className:`simulation-spec-number`,title:t.value===null?void 0:`${t.value} ${t.unit||`(unit not declared)`}`,children:[n.result,t.value!==null&&n.unit?(0,X.jsxs)(X.Fragment,{children:[` `,(0,X.jsx)(`span`,{className:`simulation-spec-unit`,children:n.unit})]}):null]}),(0,X.jsxs)(`td`,{className:`simulation-spec-number`,title:t.expected?`${L(t.expected)} ${t.unit||`(unit not declared)`}`:`No acceptance condition`,children:[n.condition,t.expected&&n.unit?(0,X.jsxs)(X.Fragment,{children:[` `,(0,X.jsx)(`span`,{className:`simulation-spec-unit`,children:n.unit})]}):null]}),(0,X.jsxs)(`td`,{children:[(0,X.jsx)(`span`,{title:t.detail,children:r[t.judgment]}),t.judgment===`not-evaluated`?(0,X.jsx)(`small`,{children:t.detail}):null]})]},t.id)}return(0,X.jsxs)(`section`,{className:`simulation-spec-results`,"aria-label":`Specification results`,children:[e.stale?(0,X.jsx)(`p`,{className:`simulation-spec-stale`,children:`Previous run · input has changed`}):null,t.length?(0,X.jsxs)(X.Fragment,{children:[(0,X.jsxs)(`p`,{className:`simulation-spec-summary`,children:[n.pass,` Pass · `,n.failed,` Failed ·`,` `,n[`not-evaluated`],` Not evaluated`,n.unconstrained?` · ${n.unconstrained} without spec`:``]}),i.length?(0,X.jsxs)(`section`,{"aria-label":`Acceptance and issues`,children:[(0,X.jsx)(`h4`,{children:`Acceptance and issues`}),o(i)]}):null,a.length?(0,X.jsxs)(`details`,{className:`simulation-spec-other`,children:[(0,X.jsxs)(`summary`,{children:[`Other measurements (`,a.length,`)`]}),o(a)]}):null]}):(0,X.jsx)(`p`,{className:`simulation-empty-result`,children:e.hasRun?`Results available in Explorer. No specification report or measurements were recorded.`:`Run your code to evaluate specifications. Raw and CSV results will appear in Explorer.`})]})}var Ln={"fix-input":`Review the highlighted input and apply the correction.`,reprepare:`The input changed. Prepare it again before running.`,"retry-same-request":`The response is uncertain. Refresh this run; do not start a duplicate.`,"retry-after":`Keep the current work and try again after the service recovers.`,reauthorize:`Reconnect the simulation session, then continue with the same Project.`,"not-retryable":`This run will not be retried automatically. Preserve its files before starting another.`};function Rn({problem:e,onFocus:t,onSource:n}){let r=e=>({documentId:e.documentId,hierarchyPath:e.hierarchyPath.map(e=>({...e})),kind:e.kind,objectId:e.objectId,...e.endpoint===void 0?{}:{endpoint:e.endpoint},...e.sourceRef===void 0?{}:{sourceRef:e.sourceRef}});return(0,X.jsxs)(`section`,{className:`simulation-problem`,"aria-label":`Simulation problem`,children:[(0,X.jsxs)(`header`,{children:[(0,X.jsx)(`strong`,{children:e.code}),(0,X.jsxs)(`small`,{children:[e.stage,` · `,e.recovery]})]}),(0,X.jsx)(`p`,{children:e.message}),(0,X.jsx)(`p`,{children:Ln[e.recovery]}),e.retryAfterMs===void 0?null:(0,X.jsxs)(`small`,{children:[`Try again after `,Math.ceil(e.retryAfterMs/1e3),` s.`]}),e.diagnostics?.length?(0,X.jsx)(`ul`,{children:e.diagnostics.map((e,i)=>(0,X.jsxs)(`li`,{children:[(0,X.jsxs)(`span`,{children:[(0,X.jsx)(`strong`,{children:e.code}),` `,e.message,e.field?(0,X.jsx)(`small`,{children:e.field}):null]}),e.primary&&t?(0,X.jsx)(`button`,{type:`button`,onClick:()=>t(r(e.primary)),children:`Show`}):null,e.source&&n?(0,X.jsx)(`button`,{type:`button`,onClick:()=>n(e.source),children:`Show code`}):null]},`${e.code}:${i}`))}):null]})}async function zn(e,t,n,r){if(!Array.isArray(n)||!Number.isSafeInteger(e.line)||e.line<1)return;let i=n.filter(t=>t&&typeof t.path==`string`&&(e.file===t.path||e.file.endsWith(`/`+t.path)));if(i.length!==1||!Array.isArray(i[0].segments))return;let o=0;for(let n=1;n<e.line;n++){let e=t.indexOf(`
`,o);if(e<0)return;o=e+1}let s=i[0].segments.filter(e=>e&&typeof e.startOffset==`number`&&typeof e.endOffset==`number`&&Number.isSafeInteger(e.startOffset)&&Number.isSafeInteger(e.endOffset)&&e.startOffset>=0&&e.endOffset<=t.length&&o>=e.startOffset&&o<e.endOffset);if(s.length!==1)return;let c=s[0],l=c?.origin;if(l?.kind!==`model-source`||!Number.isSafeInteger(l.startOffset))return;let u=a.array().max(256).safeParse(r);if(!u.success)return;let d=u.data.find(e=>e.id===l.sourceId&&e.revision===l.revision),f=d?.files.find(e=>e.path===l.path);if(!f||!d)return;let p=l.startOffset+o-c.startOffset;if(p<0||p>=f.text.length)return;let m=f.text.slice(0,p);return{scope:`model-source`,sourceId:d.id,revision:d.revision,path:f.path,textDigest:await Oe(f.text),startOffset:p,endOffset:p,line:m.split(`
`).length,column:p-m.lastIndexOf(`
`)}}var Bn=class{cached=new Map;async read(e,t){if(!t.resultPreview)return{ok:!0,run:t};if(!t.catalog){let n=await e.catalog(t.id);n&&(t={...t,catalog:n})}let n=t.artifacts.map(e=>e.id).join(`:`),r=this.cached.get(n);if(r)return{ok:!0,run:{...t,...r,resultPreview:!1}};let i={};try{for(let n of t.artifacts){if(![`result.json`,`outputs.json`,`specs.json`].includes(n.name))continue;let t=await gt(e,n);if(!t.ok)return t;let r=JSON.parse(t.content.text);n.name===`result.json`?i.result=v.parse(r):i.outputData=n.name===`specs.json`?{schemaVersion:1,analyses:[],diagnostics:[],...i.outputData,specs:I.parse(r)}:{...De.parse(r),...i.outputData?.specs?{specs:i.outputData.specs}:{}}}if(!i.result&&!i.outputData)throw Error(`Missing result artifacts`);return this.cached.set(n,i),this.cached.size>5&&this.cached.delete(this.cached.keys().next().value),{ok:!0,run:{...t,...i,resultPreview:!1}}}catch{return{ok:!1,error:{code:`SIMULATION_DETAILS_INVALID`,message:`Full result files are unavailable or invalid. The run receipt and other artifacts remain accessible.`,stage:`read`,recovery:`retry-after`}}}}};function Vn(e){return e.state===`finished`?`specs`:`console`}function $(e,t){return{code:e,message:t,stage:`input`,recovery:`fix-input`}}function Hn(e){return(0,X.jsx)(Nt,{children:(0,X.jsx)(Wn,{...e})},e.project.id)}function Un(e){return e.state===`finished`?e.outcome??e.state:e.state}function Wn(e){let t=Mt(),{session:n,project:r,open:i}=e,[a,o]=(0,Z.useState)(()=>e.runHistory?.snapshot()??[]);(0,Z.useEffect)(()=>{let t=e.runHistory;return o(t?.snapshot()??[]),t?.subscribe(()=>o(t.snapshot()))},[e.runHistory]);let c=r.simulationFolders.find(t=>t.id===e.selectedFolderId),l=(0,Z.useRef)(e.selectedFolderId);l.current=e.selectedFolderId;let[u,d]=(0,Z.useState)(),[f,p]=(0,Z.useState)(),[m,h]=(0,Z.useState)(),g=(0,Z.useRef)(new Map),_=m?g.current.get(m.id):void 0,[v,y]=(0,Z.useState)(),b=(0,Z.useRef)(new Set),x=(0,Z.useRef)(new Map),S=(0,Z.useRef)(new Bn),[ee,C]=(0,Z.useState)(),[w,T]=(0,Z.useState)(!1),[te,ne]=(0,Z.useState)(!1),[re,ie]=(0,Z.useState)(!1),[ae,E]=(0,Z.useState)(!1),oe=(0,Z.useRef)(!1);(0,Z.useEffect)(()=>{e.maximized||E(!1)},[e.maximized]);let se=()=>{ae?(E(!1),oe.current&&e.maximized&&e.onToggleMaximized(),oe.current=!1):(oe.current=!e.maximized,e.maximized||e.onToggleMaximized(),E(!0))},D=(0,Z.useRef)(new Map),O=(0,Z.useRef)(new Map),k=(0,Z.useRef)(null);(0,Z.useEffect)(()=>(e.onSourceBuffer?.({dirty:te,flush:async()=>!k.current||await k.current.save()}),()=>e.onSourceBuffer?.(null)),[te,c?.id,e.onSourceBuffer]);let[le,A]=(0,Z.useState)(`specs`),[ue,de]=(0,Z.useState)(),[j,M]=(0,Z.useState)(),pe=(0,Z.useRef)(0),me=()=>{pe.current+=1,de(void 0),M(e=>e?.startsWith(`preview:`)?void 0:e)},[N]=(0,Z.useState)(()=>St()),he=(0,Z.useRef)(new Set),[ge,ve]=(0,Z.useState)([]),[xe,Se]=(0,Z.useState)(!0),we=(0,Z.useRef)(null);(0,Z.useEffect)(()=>{let e=e=>{let t=e.target;we.current?.contains(t)||we.current?.removeAttribute(`open`)};return document.addEventListener(`pointerdown`,e),()=>document.removeEventListener(`pointerdown`,e)},[]),(0,Z.useEffect)(()=>{let e=!1;return N.list(r.id).then(t=>{!e&&t.ok&&ve(t.value)}),()=>{e=!0}},[N,r.id,i,a]),(0,Z.useEffect)(()=>()=>{N.close()},[N]);let Te=(0,Z.useRef)(e.selectedFolderId);(0,Z.useEffect)(()=>{if(Te.current===e.selectedFolderId)return;Te.current=e.selectedFolderId;let t=e.selectedFolderId?O.current.get(e.selectedFolderId):void 0;p(t?.prepared),h(t?.run),C(void 0),me()},[e.selectedFolderId]);let P=(0,Z.useRef)(!1),F=(0,Z.useRef)(!0);(0,Z.useEffect)(()=>(F.current=!0,()=>{F.current=!1}),[]);let I=e=>{F.current&&(!(e.ok&&`batch`in e)&&(c?.id??null)!==l.current||e.ok&&`run`in e&&D.current.get(e.run.preparedId)?.folderId!==l.current||(e.ok?`batch`in e?(y(e.batch),C(void 0)):`run`in e?(c&&O.current.set(c.id,{...O.current.get(c.id),run:e.run}),h(e.run),C(void 0),(e.run.result||e.run.error||[`finished`,`cancelled`,`lost`].includes(e.run.state))&&A(Vn(e.run))):`prepared`in e?(c&&O.current.set(c.id,{...O.current.get(c.id),prepared:e.prepared}),p(e.prepared),C(void 0),me(),A(`console`)):`capabilities`in e&&(d(e.capabilities),C(void 0)):(C(e.error),c&&A(`console`))))};(0,Z.useEffect)(()=>{i&&!u&&n.handle({operation:`capabilities`}).then(I)},[i,n]),(0,Z.useEffect)(()=>{if(!m||he.current.has(m.id))return;let e=!1,t,r=async()=>{let i,a=await n.handle({operation:`read`,runId:m.id});if(a.ok&&`run`in a&&a.run.resultPreview&&[`finished`,`cancelled`,`lost`].includes(a.run.state)){let e=await S.current.read(n.files,a.run);e.ok?a=e:i=e.error}e||(I(a),i&&C(i),a.ok&&`run`in a&&[`running`,`cancelling`].includes(a.run.state)&&(t=setTimeout(r,500)))};return r(),()=>{e=!0,clearTimeout(t)}},[m?.id,n,r]),(0,Z.useEffect)(()=>{if(!v||![`running`,`cancelling`].includes(v.state))return;let e=!1,t,r=async()=>{let i=await n.handle({operation:`read-batch`,batchId:v.id});if(!e&&(I(i),!(!i.ok||!(`batch`in i)))){for(let e of i.batch.items){if(!e.runId||b.current.has(e.runId)||![`finished`,`failed`,`cancelled`,`lost`].includes(e.state))continue;let t=await n.handle({operation:`read`,runId:e.runId});!t.ok||!(`run`in t)||(b.current.add(e.runId),x.current.set(e.runId,{prepared:e.prepared,run:t.run}),O.current.set(e.folderId,{prepared:e.prepared,run:t.run}),e.folderId===l.current&&(p(e.prepared),h(t.run),A(Vn(t.run))))}[`running`,`cancelling`].includes(i.batch.state)&&(t=setTimeout(r,500))}};return r(),()=>{e=!0,clearTimeout(t)}},[v?.id,v?.state,n,r]);let Ee=async(e,t=!1)=>{if(P.current)return;let r=await k.current?.flush();if(!r?.ok)return;let i=s(r.folder);if(i.ok&&i.config.runPlan.mode===`sweep`){await L(i.config.runPlan.axes,e,r,t);return}P.current=!0,T(!0),C(void 0);try{let i=await n.handle({operation:`prepare`,source:{kind:`project-folder`,folderId:c.id,expectedStructureRevision:r.revision}});if(i.ok&&`prepared`in i&&D.current.set(i.prepared.id,{...ft(r.folder),prepared:structuredClone(i.prepared)}),I(i),t&&i.ok&&`prepared`in i&&F.current&&l.current===r.folder.id){let e=i.prepared.artifacts.find(e=>e.name===`prepared.cir`);e&&await B(e)}e&&i.ok&&`prepared`in i&&F.current&&I(await n.handle({operation:`start`,preparedId:i.prepared.id,digest:i.prepared.digest}))}finally{P.current=!1,F.current&&T(!1)}},De=async e=>{if(!P.current){if(new Set(e).size<2){C($(`SIMULATION_BATCH_SELECTION_REQUIRED`,`Select at least two saved folders to run as a batch`));return}P.current=!0,T(!0),C(void 0),b.current.clear();try{let t=await k.current?.flushFolders(e);if(!t?.ok)return;let r=t.folders,i=await n.handle({operation:`prepare-batch`,expectedStructureRevision:t.revision,items:r.map(e=>({id:e.id,folderId:e.id}))});if(I(i),!i.ok||!(`batch`in i))return;for(let e of i.batch.items){let t=r.find(t=>t.id===e.folderId);t&&(D.current.set(e.prepared.id,{...ft(t),prepared:structuredClone(e.prepared)}),O.current.set(t.id,{prepared:e.prepared}))}I(await n.handle({operation:`start-batch`,batchId:i.batch.id}))}finally{P.current=!1,F.current&&T(!1)}}},L=async(e,t,r,i=!1)=>{if(!(P.current||!c)){P.current=!0,T(!0),C(void 0),b.current.clear(),x.current.clear();try{let a=await n.handle({operation:`prepare-sweep`,folderId:c.id,expectedStructureRevision:r.revision,axes:[...e]});if(I(a),!a.ok||!(`batch`in a))return;for(let e of a.batch.items)D.current.set(e.prepared.id,{...ft(r.folder),prepared:structuredClone(e.prepared),folderName:e.label??r.folder.name});if(t)I(await n.handle({operation:`start-batch`,batchId:a.batch.id}));else{let e=a.batch.items[0];if(e&&(await R(e),i&&F.current&&l.current===r.folder.id)){let t=e.prepared.artifacts.find(e=>e.name===`prepared.cir`);t&&await B(t)}}}finally{P.current=!1,F.current&&T(!1)}}},R=async t=>{if(!t.runId){let e=D.current.get(t.prepared.id);p(t.prepared),h(void 0),C(void 0),me(),A(`console`),e&&O.current.set(t.folderId,{prepared:t.prepared});return}let r=x.current.get(t.runId);if(!r){let e=await n.handle({operation:`read`,runId:t.runId});if(!e.ok||!(`run`in e)){I(e);return}r={prepared:t.prepared,run:e.run},x.current.set(t.runId,r)}t.folderId!==l.current&&e.onSelectFolderId(t.folderId),p(r.prepared),h(r.run),A(Vn(r.run))},z=async e=>{M(`download:${e.id}`);let t=await gt(n.files,e);if(M(void 0),!t.ok){C(t.error);return}let r=be(t.content.text,e.name);r.status===`failed`&&C($(`ARTIFACT_DOWNLOAD_FAILED`,r.message))},ke=async(e,t)=>{let r=e=>C($(`MODEL_LOCATION_UNAVAILABLE`,e)),i=e.artifacts.filter(e=>e.sourcePath&&(e.sourcePath===t.file||t.file.endsWith(`/`+e.sourcePath))),a=e.artifacts.find(e=>e.name===`source-map.json`),o=e.artifacts.find(e=>e.name===`model-sources.json`);if(i.length!==1||!a||!o){r(`This diagnostic has no unique model mapping. Inspect the retained run artifacts.`);return}try{let e=await Promise.all([i[0],a,o].map(e=>gt(n.files,e)));if(e.some(e=>!e.ok)){r(`The original model evidence is unavailable. Inspect this run's retained artifacts.`);return}let s=e.map(e=>e.ok?e.content.text:``),c=await zn(t,s[0],JSON.parse(s[1]),JSON.parse(s[2]));if(!c){r(`This line is outside an exact model span. Inspect its source artifact.`);return}E(!1),await k.current?.reveal(c)}catch{r(`The saved mapping is unreadable. Inspect the original artifacts.`)}},B=async e=>{let t=++pe.current;M(`preview:${e.id}`);let r=await xt(n.files,e);if(t===pe.current){if(M(t=>t===`preview:${e.id}`?void 0:t),!r.ok){C(r.error);return}de(r.content)}},Ae=async(e,t)=>{M(`bundle:${e}`);let r=await _t(n.files,t);if(M(void 0),!r.ok){C(r.error);return}let i=URL.createObjectURL(new Blob([r.bytes],{type:`application/zip`})),a=document.createElement(`a`);a.href=i,a.download=`simulation-${e}.zip`,a.click(),setTimeout(()=>URL.revokeObjectURL(i),0)},je=async()=>{if(!m||!c||!q||c.id!==q.folderId)return;M(`archive:save`);let e=await bt(n.files,{projectId:r.id,presentation:{folderId:q.folderId,folderName:q.folderName,analysisLabel:q.analysisLabel,outputs:q.outputs,...q.rootDocumentId?{rootDocumentId:q.rootDocumentId}:{}},prepared:q.prepared,run:m});if(!e.ok){M(void 0),C(e.error);return}let t=a.find(e=>e.id===m.id),i=t?.memoryArchive?{ok:!0,value:t.memoryArchive}:t?.archive?await N.read(t.archive.id):void 0;if(i&&(!i.ok||!i.value)){M(void 0),C($(`SIMULATION_ARCHIVE_UNAVAILABLE`,`The existing run archive could not be read; its evidence has not been replaced`));return}let o=await N.save({...i?.value??{...e.value,id:`run-${m.id}`,..._?{projectFile:_}:{}},retention:`saved`});if(M(void 0),!o.ok){C($(`SIMULATION_ARCHIVE_STORAGE_FAILED`,o.code===`quota-exceeded`?`Browser storage is full; export the complete run ZIP instead`:`Browser result archives are unavailable; export the complete run ZIP instead`));return}ve(e=>[o.value,...e.filter(e=>e.id!==o.value.id)].slice(0,10))},Me=async t=>{M(`archive:open:${t}`);let i=a.find(e=>e.archive?.id===t)?.memoryArchive,o=i?{ok:!0,value:i}:await N.read(t);if(!o.ok||!o.value){M(void 0),C($(`SIMULATION_ARCHIVE_UNAVAILABLE`,`The selected browser archive is no longer available`));return}let s=await vt(n.files,o.value);if(M(void 0),!s.ok){C(s.error);return}let l={...o.value.presentation,prepared:s.value.prepared};o.value.projectFile&&g.current.set(s.value.run.id,o.value.projectFile),D.current.set(s.value.prepared.id,l),he.current.add(s.value.run.id),O.current.set(o.value.presentation.folderId,{prepared:s.value.prepared,run:s.value.run}),o.value.presentation.folderId!==c?.id&&r.simulationFolders.some(e=>e.id===o.value.presentation.folderId)&&e.onSelectFolderId(o.value.presentation.folderId),p(s.value.prepared),h(s.value.run),C(void 0),A(Vn(s.value.run))},Ne=async t=>{if(!(await N.delete(t)).ok){C($(`SIMULATION_ARCHIVE_DELETE_FAILED`,`The browser archive could not be removed`));return}ve(e=>e.filter(e=>e.id!==t)),e.runHistory?.forgetArchive(t)},V=v&&[`running`,`cancelling`].includes(v.state),H=m&&[`running`,`cancelling`].includes(m.state)||V,U=v?.items.filter(e=>[`finished`,`failed`,`cancelled`,`lost`].includes(e.state)).length??0,W=ye(c?.id,a,m,ge),Pe=w?`Preparing…`:v?`Batch ${v.state} · ${U}/${v.items.length}`:W?Un(W):f?`Deck prepared`:`No run yet`,G=m?.inputStatus===`changed`?`Result belongs to an earlier Project revision. Run again to use the current circuit.`:``,K=ee??m?.error,q=m?D.current.get(m.preparedId):void 0,Fe=new Set(q?.prepared.artifacts.map(e=>e.id)??[]),Ie=[{key:`run`,label:`Run`,description:`Execution output`,artifacts:m?.artifacts.filter(e=>!Fe.has(e.id))??[]}],Le=m?.artifacts??f?.artifacts??[],Re=m?.artifacts.find(e=>e.name===`executed.cir`),ze=[{label:`Download complete run…`,disabled:!m||!!j,run:()=>void Ae(`run`,m?.artifacts??[])},{label:`Download project + results…`,disabled:!m||!_||!!j,run:async()=>{if(!m||!_)return;M(`bundle:project`);let e=await yt(n.files,[{kind:`text`,path:`project.icproj.json`,text:_},...m.artifacts.map(e=>({kind:`artifact`,path:`results/${e.name}`,artifact:e}))]);if(M(void 0),!e.ok){C(e.error);return}let t=URL.createObjectURL(new Blob([e.bytes],{type:`application/zip`})),r=document.createElement(`a`);r.href=t,r.download=`project-with-results.zip`,r.click(),setTimeout(()=>URL.revokeObjectURL(t),1e3)}},{label:`Archive current run (latest 30 saved)`,disabled:!m||!!j,run:()=>void je()},{label:`Preview input netlist…`,disabled:w||H,run:()=>void Ee(!1,!0)},{label:`View executed netlist…`,disabled:!Re||j!==void 0,run:()=>{Re&&B(Re)}},{label:`Export diagnostic bundle…`,disabled:Le.length===0||j!==void 0,run:()=>void Ae(`diagnostics`,Le)}],[J,Be]=(0,Z.useState)();(0,Z.useEffect)(()=>{J&&J===c?.id&&(Be(void 0),Ee(!0))},[J,c?.id]);let Ve=async(i,a)=>{if(i===`batch`){await De(a);return}let o=r.simulationFolders.find(e=>e.id===a[0]);if(i===`run`&&o){e.onSelectFolderId(o.id),Be(o.id);return}if(i===`delete`&&o){if(await t.confirm({title:`Delete folder ${o.name}?`,message:`This removes its source files and saved drafts from the Project. Undo restores the folder; archived results are kept.`})){if(k.current&&!await k.current.save())return;e.onDeleteFolder(o.id,n.currentProject()?.structureRevision)}return}if(k.current&&!await k.current.save())return;let s=u;if(i===`new`&&!s){let e=await n.handle({operation:`capabilities`});e.ok&&`capabilities`in e&&(s=e.capabilities,d(s))}let c=n.currentProject();if(!c)return;let l=c.simulationFolders.find(e=>e.id===o?.id);if(i===`export`&&l){be(JSON.stringify(l,null,2)+`
`,`${l.name}.simulation.json`);return}let f=await t.name({kind:`folder`,...i===`rename`&&l?{folderId:l.id}:{},label:i===`rename`?`Folder name`:`New simulation folder name`,...i===`new`&&s?.profiles.length?{profiles:s.profiles.map(e=>({id:e.id,name:e.label??e.id})),profileFor:e=>{let t=n.currentProject()??c,r=fe(s.profiles,e?{project:t,documentId:e}:void 0);return r.ok?r.profileId:void 0}}:{},...i===`new`?{cellSelection:{initial:e.activeDocumentId,options:c.documents.map(({id:e,name:t})=>({id:e,name:t})),validate:e=>n.currentProject()?.documents.some(t=>t.id===e)?void 0:`Select an existing Cell for this experiment.`}}:{},validate:e=>n.currentProject()?.simulationFolders.some(t=>(i!==`rename`||t.id!==l?.id)&&t.name.toLocaleLowerCase(`en-US`)===e.toLocaleLowerCase(`en-US`))?`Simulation folder name already exists: ${e}`:void 0,initial:i===`rename`?l?.name??``:i===`duplicate`?`${l?.name} copy`:`Simulation ${c.simulationFolders.length+1}`});if(!f)return;let p={id:i===`rename`&&l?l.id:`simulation-folder-${crypto.randomUUID()}`,name:f.name},m=n.currentProject();if(!m)return;let h=m.simulationFolders.find(e=>e.id===l?.id);if(l&&!h)return;let g;if(h)g={...structuredClone(h),...p};else{if(!f.documentId||!m.documents.some(e=>e.id===f.documentId)){C($(`SIMULATION_STARTER_INVALID`,`The selected Cell no longer exists. Select a Cell and create the experiment again.`));return}let e=s?.profiles.find(e=>e.id===f.profileId)??s?.profiles[0],t=e?_e(e,s?.rawfileCollection):`vacask`;if(!t){C($(`SIMULATION_ENGINE_UNAVAILABLE`,`The selected Profile does not declare an execution dialect.`));return}let n=ce(m,{...p,mode:`circuit`,documentId:f.documentId,profileId:e?.id??`vacask-sky130-candidate`,engine:t,template:`op`});if(!n.ok){C($(`SIMULATION_STARTER_INVALID`,n.message));return}g=n.folder}let _=e.onSaveFolder(g,m.structureRevision);_.status===`rejected`?C(_.problem):e.onSelectFolderId(g.id)},He=()=>void Ve(`new`,[]),Ue=async e=>{if(e.kind===`log`){A(`console`);return}let t=c?.input.files.find(t=>t.path===e.path);if(!t||t.text.split(/\r?\n/)[e.line-1]!==e.text){C($(`SPEC_SOURCE_CHANGED`,`This specification belongs to an earlier source snapshot. Open that run's executed source.`)),A(`console`);return}let n=t.text.split(`
`).slice(0,e.line-1).reduce((e,t)=>e+t.length+1,0);E(!1),await k.current?.reveal({scope:`authored`,path:e.path,textDigest:await Oe(t.text),startOffset:n,endOffset:n+e.text.length,line:e.line,column:1})},We=(0,X.jsxs)(`details`,{className:`simulation-run-history`,children:[(0,X.jsx)(`summary`,{children:`Run history`}),` `,(0,X.jsxs)(`label`,{children:[(0,X.jsx)(`input`,{type:`checkbox`,checked:xe,onChange:e=>Se(e.target.checked)}),`All Project folders`]}),ge.some(e=>(xe||e.folderId===c?.id)&&!a.some(t=>t.archive?.id===e.id))?(0,X.jsxs)(`section`,{className:`simulation-archive-list`,"aria-label":`Saved folder results`,children:[(0,X.jsx)(`strong`,{children:`Saved and cached results · this browser`}),(0,X.jsx)(`ul`,{children:ge.filter(e=>(xe||e.folderId===c?.id)&&!a.some(t=>t.archive?.id===e.id)).map(e=>(0,X.jsxs)(`li`,{children:[(0,X.jsxs)(`span`,{children:[e.retention===`cache`?`Auto · `:`Saved · `,e.origin===`agent`?`Agent · `:``,e.folderName,` · `,Un(Ce(e)),` `,`· `,new Date(e.createdAt).toLocaleString()]}),(0,X.jsx)(`button`,{type:`button`,disabled:j!==void 0,onClick:()=>void Me(e.id),children:`Open result`}),(0,X.jsx)(`button`,{type:`button`,"aria-label":`Delete result ${e.id}`,onClick:()=>void Ne(e.id),children:`Delete`})]},e.id))})]}):null,a.some(e=>xe||e.presentation.folderId===c?.id)?(0,X.jsxs)(`section`,{className:`simulation-archive-list`,"aria-label":`Project runs`,children:[(0,X.jsx)(`strong`,{children:`Project runs · automatically archived in this browser`}),(0,X.jsx)(`ul`,{children:a.filter(e=>xe||e.presentation.folderId===c?.id).map(e=>(0,X.jsxs)(`li`,{children:[(0,X.jsxs)(`span`,{children:[e.owner===`agent`?`Agent`:`You`,` ·`,` `,e.presentation.folderName,` ·`,` `,e.presentation.analysisLabel,` · `,Un(e),e.error?(0,X.jsx)(`small`,{role:`status`,children:e.error}):null]}),(0,X.jsx)(`button`,{type:`button`,disabled:!e.archive||j!==void 0,onClick:()=>e.archive&&void Me(e.archive.id),children:`Open result`})]},e.id))})]}):null]}),Ge=(0,X.jsx)(`section`,{className:`simulation-results-dock`,"aria-label":`Simulation results`,children:(0,X.jsxs)(`div`,{className:`simulation-results-body`,children:[m&&he.current.has(m.id)?(0,X.jsx)(`p`,{children:`Viewing a saved input snapshot, not a new run of the current source.`}):null,le===`specs`?(0,X.jsx)(In,{report:m?.outputData?.specs,hasRun:!!m?.result,stale:re||m?.inputStatus===`changed`,onSource:Ue}):null,le===`console`?(0,X.jsxs)(`div`,{className:`simulation-console-view`,children:[m?.state===`lost`?(0,X.jsx)(`p`,{children:`The executor response is unknown. Inspect its evidence before starting another run.`}):null,q?.prepared.warnings.map((e,t)=>(0,X.jsx)(`p`,{children:e},t)),m?.resultPreview?(0,X.jsx)(`p`,{children:`The on-screen result is bounded; exported artifacts contain the complete data.`}):null,K?(0,X.jsx)(Rn,{problem:K,onSource:e=>{E(!1),k.current?.reveal(e)},...e.onFocusDiagnostic?{onFocus:e.onFocusDiagnostic}:{}}):null,m?.result?(0,X.jsxs)(X.Fragment,{children:[e.onOpenModelSource&&m.artifacts.some(e=>e.name===`model-sources.json`)?m.result.diagnostics.filter(e=>e.location).map((e,t)=>(0,X.jsxs)(`button`,{type:`button`,onClick:()=>void ke(m,e.location),children:[`Open model source at `,e.location.file,`:`,e.location.line]},t)):null,(0,X.jsxs)(`pre`,{children:[m.result.diagnostics.map(e=>e.text).join(`
`),`
`,m.result.log]})]}):null,!K&&!m?.result?(0,X.jsx)(`p`,{className:`simulation-empty-result`,children:`Simulator diagnostics will appear here.`}):null]}):null]})}),Y=(0,X.jsxs)(`div`,{className:`simulation-task-actions`,children:[H?(0,X.jsx)(`button`,{className:`simulation-stop-button simulation-action-button`,"aria-label":V?`Cancel batch`:`Cancel run`,title:V?`Cancel batch`:`Cancel run`,disabled:v?.state===`cancelling`||m?.state===`cancelling`,onClick:()=>{V?n.handle({operation:`cancel-batch`,batchId:v.id}).then(I):m&&n.handle({operation:`cancel`,runId:m.id}).then(I)},children:(0,X.jsx)(Cn,{kind:`stop`})}):c?(0,X.jsxs)(`button`,{className:`simulation-action-button simulation-run-button`,"aria-busy":w,disabled:w,onClick:()=>void Ee(!0),"aria-label":`Run`,title:`Run ${c.name} / ${c.input.entry}`,"aria-description":`Run ${c.name} / ${c.input.entry}`,children:[(0,X.jsx)(Cn,{kind:w?`saving`:`run`}),(0,X.jsx)(`span`,{className:`simulation-run-target`,children:c.name})]}):(0,X.jsx)(`button`,{className:`simulation-setup-button`,onClick:He,children:`Manual setup`}),(0,X.jsx)(`span`,{className:`simulation-status-chip simulation-status-${v?.state??W?.state??(f?`prepared`:`idle`)}`,role:`status`,children:re?`Source changed`:Pe}),v?(0,X.jsxs)(`details`,{ref:we,className:`simulation-batch-menu`,onToggle:e=>{e.currentTarget.open&&we.current?.focus()},children:[(0,X.jsx)(`summary`,{"aria-label":`Batch queue: ${v.state}, ${U} of ${v.items.length} finished`,title:`Batch queue`,children:(0,X.jsx)(`span`,{"aria-hidden":`true`,children:`≡`})}),(0,X.jsxs)(`div`,{className:`simulation-batch-menu-popover`,children:[(0,X.jsxs)(`header`,{children:[(0,X.jsxs)(`strong`,{children:[`Batch · `,v.state]}),(0,X.jsxs)(`span`,{children:[U,`/`,v.items.length]})]}),(0,X.jsx)(`div`,{className:`simulation-batch-menu-items`,children:v.items.map(e=>{let t=r.simulationFolders.find(t=>t.id===e.folderId);return(0,X.jsxs)(`button`,{type:`button`,"data-state":e.state,disabled:e.state===`queued`,onClick:()=>void R(e),children:[(0,X.jsx)(`span`,{children:e.label??t?.name??e.folderId}),(0,X.jsx)(`small`,{children:e.state})]},e.id)})}),V?null:(0,X.jsx)(`button`,{type:`button`,onClick:()=>y(void 0),children:`Dismiss`})]})]}):null]}),Ke=(0,X.jsxs)(X.Fragment,{children:[e.agentGuidance&&c?(0,X.jsx)(kt,{...e.agentGuidance}):null,(0,X.jsxs)(`div`,{className:`simulation-window-actions`,children:[(0,X.jsx)(`button`,{className:`simulation-minimize-button`,onClick:e.onMinimize,"aria-label":`Minimize simulation`,title:`Minimize simulation`,children:(0,X.jsx)(`span`,{className:`simulation-minimize-glyph`,"aria-hidden":`true`})}),(0,X.jsx)(`button`,{className:`simulation-maximize-button`,onClick:e.onToggleMaximized,"aria-label":e.maximized?`Restore simulation panel`:`Maximize simulation`,title:e.maximized?`Restore simulation panel`:`Maximize simulation`,children:e.maximized?`↙`:`□`}),(0,X.jsx)(`button`,{className:`simulation-close-button`,onClick:async()=>{await t.confirm({title:`Exit Simulation?`,message:`Unsaved source drafts and temporary run files will be discarded. An active run will be cancelled.`,acceptLabel:`Exit Simulation`})&&(k.current?.discard(),e.onExit())},"aria-label":`Exit simulation`,children:`×`})]})]});return(0,X.jsxs)(`section`,{hidden:!i,className:`spice-simulation-surface${e.maximized?` maximized`:``}`,"aria-label":`Analog simulation`,onKeyDown:e=>{e.stopPropagation(),e.key===`Escape`&&we.current?.open&&we.current.removeAttribute(`open`)},children:[c?null:(0,X.jsxs)(`header`,{className:`simulation-taskbar`,children:[e.agentGuidance?(0,X.jsx)(`strong`,{className:`simulation-start-title`,children:`Simulation`}):Y,Ke]}),c?(0,X.jsx)(Dn,{ref:k,capabilities:u,diagnostics:K?.diagnostics,project:r,activeDocumentId:e.activeDocumentId,folder:c,selectedCircuitObject:e.selectedCircuitObject,...e.onPreviewSignal?{onPreviewSignal:e.onPreviewSignal}:{},files:n.files,...e.pickedNet===void 0?{}:{pickedNet:e.pickedNet},...e.pickedTerminal===void 0?{}:{pickedTerminal:e.pickedTerminal},pickNetsActive:e.pickNetsActive??!1,pickTerminalsActive:e.pickTerminalsActive??!1,onPickNetsChange:t=>e.onPickNetsChange?.(t),onPickTerminalsChange:t=>e.onPickTerminalsChange?.(t),actions:Y,toolbarEnd:Ke,status:G,onDirty:ne,onActiveDirty:ie,onProblem:C,console:Ge,results:Ge,history:We,artifactGroups:Ie,artifactPreview:ue,artifactBusy:j,onSelectArtifact:e=>void B(e),onCloseArtifact:me,onDownloadArtifact:e=>void z(e),outputPane:le,onSelectOutputPane:A,maximized:ae,onToggleMaximize:se,onRun:()=>void Ee(!0),additionalActions:ze,folders:{folders:r.simulationFolders.map(e=>({...e,configPath:e.input.configPath,cellLabel:e.input.circuitBindings.length?`Cell: `+[...new Set(e.input.circuitBindings.map(e=>r.documents.find(t=>t.id===e.documentId)?.name??`Missing (${e.documentId})`))].join(`, `):`No Canvas Cell`,files:[...e.input.files.map(e=>({path:e.path,kind:`authored`})),...e.input.circuitBindings.map(e=>({path:e.path,kind:`generated`}))]})),activeId:c.id,busy:w||!!H,onSelect:e.onSelectFolderId,onAction:(e,t)=>void Ve(e,t)},onHistoryBoundary:e.onHistoryBoundary,onOpenModelSource:e.onOpenModelSource}):(0,X.jsxs)(`div`,{className:`simulation-start-workspace`,children:[e.agentGuidance?(0,X.jsx)(Ot,{...e.agentGuidance,onManualSetup:He}):null,t.edit?.kind===`folder`?(0,X.jsx)(Pt,{}):null,!r.simulationFolders.length&&e.onOpenExample?(0,X.jsxs)(`details`,{className:`simulation-start-examples`,children:[(0,X.jsx)(`summary`,{children:`Explore examples`}),(0,X.jsx)(Rt,{onOpen:e.onOpenExample})]}):null]})]})}export{Hn as SpiceSimulationSurface};