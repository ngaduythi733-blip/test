@echo off
rem Launch Analog Canvas with the Flask host.
cd /d "%~dp0"
python app.py %*
