#!/usr/bin/env python3
"""Analog Canvas - local web host (Flask).

Serves the pre-built editor from ./web and falls back to index.html for
client-side routes such as /editor. Hosted-only backend endpoints under
/api/ return 404 so the editor uses its local-only fallback.

Install and run:
    pip install -r requirements.txt
    python app.py

Then open http://127.0.0.1:8000/editor
"""

import argparse
import mimetypes
import os
import threading
import webbrowser

from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, "web")

for _ext, _type in {
    ".js": "text/javascript",
    ".mjs": "text/javascript",
    ".css": "text/css",
    ".json": "application/json",
    ".webmanifest": "application/manifest+json",
    ".wasm": "application/wasm",
    ".svg": "image/svg+xml",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".map": "application/json",
}.items():
    mimetypes.add_type(_type, _ext)

app = Flask(__name__, static_folder=None)


def _cache_control(path):
    if path.startswith("/assets/"):
        return "public, max-age=31536000, immutable"
    if path in ("/", "/index.html", "/sw.js", "/manifest.webmanifest"):
        return "no-cache"
    return None


@app.after_request
def _apply_cache_headers(response):
    value = _cache_control(request.path)
    if value:
        response.headers["Cache-Control"] = value
    return response


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path):
    if path.startswith("api/"):
        return jsonify(error="not_found"), 404

    target = os.path.join(WEB_DIR, path)
    if path and os.path.isfile(target):
        return send_from_directory(WEB_DIR, path)

    # SPA fallback: extension-less routes render the app shell.
    if not path or "." not in os.path.basename(path):
        return send_from_directory(WEB_DIR, "index.html")

    return jsonify(error="not_found"), 404


def main():
    parser = argparse.ArgumentParser(description="Serve Analog Canvas locally with Flask.")
    parser.add_argument("--port", type=int, default=8000, help="port to listen on (default 8000)")
    parser.add_argument("--host", default="127.0.0.1", help="interface to bind (default 127.0.0.1)")
    parser.add_argument("--no-browser", action="store_true", help="do not open a browser automatically")
    args = parser.parse_args()

    if not os.path.isfile(os.path.join(WEB_DIR, "index.html")):
        raise SystemExit("ERROR: web/index.html not found next to app.py")

    url = "http://%s:%d/editor" % (args.host, args.port)
    print("Analog Canvas is served from: %s" % WEB_DIR)
    print("Open: %s" % url)
    print("Press Ctrl+C to stop.")
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    app.run(host=args.host, port=args.port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
